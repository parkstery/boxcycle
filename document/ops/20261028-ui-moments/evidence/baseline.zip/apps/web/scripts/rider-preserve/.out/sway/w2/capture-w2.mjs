// W2 흔들림 비교 캡처. 실행: apps/web 에서 node scripts/rider-preserve/.out/sway/w2/capture-w2.mjs [phase|rear|all]
import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";

const here = path.dirname(fileURLToPath(import.meta.url));
const BASE = "http://localhost:5050/scripts/rider-preserve/rider-perf-bench.html";
const PHASE_CLIP = { x: 578, y: 282, width: 134, height: 124 };
const REAR_CLIP_FILE = path.join(here, "rear-clip.json");

const stage = process.argv[2] || "all";
const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

function paeth(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  if (pb <= pc) return b;
  return c;
}

function decodePng(buf) {
  if (!buf.subarray(0, 8).equals(SIG)) throw new Error("not png");
  let o = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idat = [];
  while (o + 8 <= buf.length) {
    const len = buf.readUInt32BE(o);
    o += 4;
    const type = buf.toString("ascii", o, o + 4);
    o += 4;
    const data = buf.subarray(o, o + len);
    o += len + 4;
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === "IDAT") idat.push(data);
    else if (type === "IEND") break;
  }
  if (bitDepth !== 8 || (colorType !== 6 && colorType !== 2)) {
    throw new Error(`unsupported png bit=${bitDepth} color=${colorType}`);
  }
  const bpp = colorType === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * bpp;
  const out = Buffer.alloc(height * stride);
  let i = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[i++];
    const row = y * stride;
    for (let x = 0; x < stride; x++) {
      const v = raw[i++];
      const left = x >= bpp ? out[row + x - bpp] : 0;
      const up = y > 0 ? out[row - stride + x] : 0;
      const ul = y > 0 && x >= bpp ? out[row - stride + x - bpp] : 0;
      let recon = v;
      if (filter === 1) recon = (v + left) & 255;
      else if (filter === 2) recon = (v + up) & 255;
      else if (filter === 3) recon = (v + Math.floor((left + up) / 2)) & 255;
      else if (filter === 4) recon = (v + paeth(left, up, ul)) & 255;
      else if (filter !== 0) throw new Error(`bad filter ${filter}`);
      out[row + x] = recon;
    }
  }
  return { width, height, bpp, data: out };
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(zlib.crc32(body) >>> 0);
  return Buffer.concat([len, body, crc]);
}

function encodePng(img) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(img.width, 0);
  ihdr.writeUInt32BE(img.height, 4);
  ihdr[8] = 8;
  ihdr[9] = img.bpp === 4 ? 6 : 2;
  const stride = img.width * img.bpp;
  const raw = Buffer.alloc(img.height * (stride + 1));
  for (let y = 0; y < img.height; y++) {
    raw[y * (stride + 1)] = 0;
    img.data.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  return Buffer.concat([SIG, chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]);
}

function toRgba(img) {
  if (img.bpp === 4) return img;
  const data = Buffer.alloc(img.width * img.height * 4);
  for (let i = 0, j = 0; i < img.data.length; i += 3, j += 4) {
    data[j] = img.data[i];
    data[j + 1] = img.data[i + 1];
    data[j + 2] = img.data[i + 2];
    data[j + 3] = 255;
  }
  return { width: img.width, height: img.height, bpp: 4, data };
}

function readPng(file) {
  return toRgba(decodePng(fs.readFileSync(file)));
}

function pairAndDiff(offFile, onFile, pairFile, diffFile) {
  const off = readPng(offFile);
  const on = readPng(onFile);
  if (off.width !== on.width || off.height !== on.height) {
    throw new Error(`size mismatch ${offFile} ${on.width}x${off.height} vs ${on.width}x${on.height}`);
  }
  const { width, height } = off;
  const pair = Buffer.alloc(width * 2 * height * 4);
  const diff = Buffer.alloc(width * height * 4);
  let sum = 0;
  let max = 0;
  let hot = 0;
  const bands = [0, 0, 0];
  const bandN = height / 3;
  for (let y = 0; y < height; y++) {
    const band = Math.min(2, Math.floor(y / bandN));
    for (let x = 0; x < width; x++) {
      const i = (y * width + x) * 4;
      const dst = (y * width * 2 + x) * 4;
      const dstR = (y * width * 2 + width + x) * 4;
      pair[dst] = off.data[i];
      pair[dst + 1] = off.data[i + 1];
      pair[dst + 2] = off.data[i + 2];
      pair[dst + 3] = 255;
      pair[dstR] = on.data[i];
      pair[dstR + 1] = on.data[i + 1];
      pair[dstR + 2] = on.data[i + 2];
      pair[dstR + 3] = 255;
      let pix = 0;
      for (let c = 0; c < 3; c++) {
        const d = Math.min(255, Math.abs(on.data[i + c] - off.data[i + c]) * 8);
        diff[i + c] = d;
        pix += d;
        if (d > max) max = d;
      }
      diff[i + 3] = 255;
      sum += pix / 3;
      bands[band] += pix / 3;
      if (pix / 3 >= 16) hot += 1;
    }
  }
  fs.writeFileSync(pairFile, encodePng({ width: width * 2, height, bpp: 4, data: pair }));
  fs.writeFileSync(diffFile, encodePng({ width, height, bpp: 4, data: diff }));
  const n = width * height;
  return {
    meanAbsX8: Number((sum / n).toFixed(2)),
    maxAbsX8: max,
    hotPx: hot,
    bandMeanX8: bands.map((v) => Number((v / (n / 3)).toFixed(2))),
  };
}

function stitchHorizontal(files, outFile) {
  const imgs = files.map(readPng);
  const height = imgs[0].height;
  const width = imgs[0].width;
  for (const img of imgs) {
    if (img.width !== width || img.height !== height) throw new Error("strip size mismatch");
  }
  const data = Buffer.alloc(width * imgs.length * height * 4);
  for (let n = 0; n < imgs.length; n++) {
    for (let y = 0; y < height; y++) {
      const src = y * width * 4;
      const dst = (y * width * imgs.length + n * width) * 4;
      imgs[n].data.copy(data, dst, src, src + width * 4);
    }
  }
  fs.writeFileSync(outFile, encodePng({ width: width * imgs.length, height, bpp: 4, data }));
}

function loadRearClip() {
  const raw = JSON.parse(fs.readFileSync(REAR_CLIP_FILE, "utf8"));
  return { x: raw.x, y: raw.y, width: raw.w ?? raw.width, height: raw.h ?? raw.height };
}

async function openShot(browser, dpr) {
  const ctx = await browser.newContext({
    viewport: { width: 1280, height: 800 },
    deviceScaleFactor: dpr,
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("console", (m) => {
    if (m.type() === "error") errors.push(m.text());
  });
  page.on("pageerror", (e) => errors.push(String(e)));
  return { ctx, page, errors };
}

async function gotoReady(page, qs, errors) {
  const url = `${BASE}?${qs}`;
  for (let attempt = 0; ; attempt++) {
    try {
      await page.goto(url, { waitUntil: "load", timeout: 60000 });
      await page.waitForFunction(() => window.__rtwBench?.state().loadState === "ready", null, {
        timeout: 90000,
      });
      break;
    } catch (error) {
      if (attempt >= 2) throw error;
      errors.length = 0;
      console.log("retry", url, String(error).slice(0, 180));
    }
  }
  const status = await page.locator("#status").innerText();
  return { url, status };
}

const browser = await chromium.launch({ headless: true });
const log = [];
try {
  if (stage === "phase" || stage === "all") {
    const ctxPack = await openShot(browser, 4);
    try {
      for (const phase of [0, 90, 180, 270]) {
        for (const sway of ["off", "on"]) {
          const page = await ctxPack.ctx.newPage();
          const errors = [];
          page.on("console", (m) => {
            if (m.type() === "error") errors.push(m.text());
          });
          page.on("pageerror", (e) => errors.push(String(e)));
          const qs = new URLSearchParams({
            animate: "0",
            swayHold: "1",
            riders: "1",
            zoom: "22",
            pitch: "78",
            bearing: "0",
            phase: String(phase),
            riderModel: "rider14",
          });
          if (sway === "off") qs.set("sway", "0");
          const ready = await gotoReady(page, qs, errors);
          if (!ready.status.includes("swayHold=1")) throw new Error(`swayHold missing: ${ready.status}`);
          await page.waitForTimeout(2000);
          await page.addStyleTag({ content: "#panel{display:none!important}" });
          await page.waitForTimeout(200);
          const file = path.join(here, `phase-${phase}-${sway}.png`);
          await page.screenshot({ path: file, clip: PHASE_CLIP });
          log.push({ kind: "phase", phase, sway, file, url: ready.url, status: ready.status, errors });
          console.log("phase", phase, sway, errors.length ? `errors=${errors.length}` : "ok");
          await page.close();
        }
        const off = path.join(here, `phase-${phase}-off.png`);
        const on = path.join(here, `phase-${phase}-on.png`);
        const pair = path.join(here, `pair-phase-${phase}.png`);
        const diff = path.join(here, `diff-phase-${phase}.png`);
        const stats = pairAndDiff(off, on, pair, diff);
        log.push({ kind: "pair-phase", phase, pair, diff, stats });
        console.log("pair", phase, JSON.stringify(stats));
      }
    } finally {
      await ctxPack.ctx.close();
    }

    const loc = await openShot(browser, 1);
    try {
      const qs = new URLSearchParams({
        animate: "0",
        swayHold: "1",
        riders: "1",
        zoom: "22",
        pitch: "70",
        bearing: "90",
        phase: "0",
        riderModel: "rider14",
      });
      const ready = await gotoReady(loc.page, qs, loc.errors);
      await loc.page.waitForTimeout(2000);
      await loc.page.addStyleTag({ content: "#panel{display:none!important}" });
      await loc.page.waitForTimeout(200);
      const file = path.join(here, "rear-locate.png");
      await loc.page.screenshot({ path: file });
      log.push({ kind: "rear-locate", file, url: ready.url, status: ready.status, errors: loc.errors });
      console.log("rear-locate", loc.errors.length ? `errors=${loc.errors.length}` : "ok");
    } finally {
      await loc.ctx.close();
    }
  }

  if (stage === "rear" || stage === "all" || stage === "strip") {
    if (!fs.existsSync(REAR_CLIP_FILE)) {
      console.log("rear-clip.json 없음 — rear 단계는 건너뜀");
    } else {
      const clip = loadRearClip();
      console.log("rear clip", JSON.stringify(clip));
      if (stage !== "strip") {
      const ctxPack = await openShot(browser, 4);
      try {
        for (const phase of [0, 180]) {
          for (const sway of ["off", "on"]) {
            const page = await ctxPack.ctx.newPage();
            const errors = [];
            page.on("console", (m) => {
              if (m.type() === "error") errors.push(m.text());
            });
            page.on("pageerror", (e) => errors.push(String(e)));
            const qs = new URLSearchParams({
              animate: "0",
              swayHold: "1",
              riders: "1",
              zoom: "22",
              pitch: "70",
              bearing: "90",
              phase: String(phase),
              riderModel: "rider14",
            });
            if (sway === "off") qs.set("sway", "0");
            const ready = await gotoReady(page, qs, errors);
            await page.waitForTimeout(2000);
            await page.addStyleTag({ content: "#panel{display:none!important}" });
            await page.waitForTimeout(200);
            const file = path.join(here, `rear-phase-${phase}-${sway}.png`);
            await page.screenshot({ path: file, clip });
            log.push({ kind: "rear", phase, sway, file, url: ready.url, errors });
            console.log("rear", phase, sway, errors.length ? `errors=${errors.length}` : "ok");
            await page.close();
          }
          const stats = pairAndDiff(
            path.join(here, `rear-phase-${phase}-off.png`),
            path.join(here, `rear-phase-${phase}-on.png`),
            path.join(here, `pair-rear-phase-${phase}.png`),
            path.join(here, `diff-rear-phase-${phase}.png`),
          );
          log.push({ kind: "pair-rear", phase, stats });
          console.log("pair-rear", phase, JSON.stringify(stats));
        }
      } finally {
        await ctxPack.ctx.close();
      }
      }

      for (const sway of ["on", "off"]) {
        const stripCtx = await openShot(browser, 1);
        try {
          const qs = new URLSearchParams({
            animate: "1",
            riders: "1",
            zoom: "22",
            pitch: "70",
            bearing: "90",
            phase: "0",
            riderModel: "rider14",
          });
          if (sway === "off") qs.set("sway", "0");
          await stripCtx.page.clock.install({ time: new Date() });
          await stripCtx.page.clock.resume();
          const ready = await gotoReady(stripCtx.page, qs, stripCtx.errors);
          if (ready.status.includes("swayHold=1")) throw new Error("strip must not hold");
          await stripCtx.page.waitForTimeout(2000);
          await stripCtx.page.addStyleTag({ content: "#panel{display:none!important}" });
          await stripCtx.page.waitForTimeout(200);
          const frozen = await stripCtx.page.evaluate(() => Date.now());
          await stripCtx.page.clock.pauseAt(frozen + 250);
          const framesDir = path.join(here, `frames-rear-${sway}`);
          fs.mkdirSync(framesDir, { recursive: true });
          const frames = [];
          for (let i = 0; i < 9; i++) {
            const file = path.join(framesDir, `f${i}.png`);
            await stripCtx.page.screenshot({ path: file, clip });
            frames.push(file);
            log.push({ kind: "strip-frame", sway, i, atMs: i * 100, file });
            console.log("frame", sway, i, `${i * 100}ms`);
            if (i < 8) await stripCtx.page.clock.runFor(100);
          }
          const stripName = sway === "on" ? "strip-rear.png" : "strip-rear-off.png";
          const stripFile = path.join(here, stripName);
          stitchHorizontal(frames, stripFile);
          log.push({ kind: "strip", sway, file: stripFile, spanMs: 800, stepMs: 100, errors: stripCtx.errors });
          console.log("strip", sway, "span=800ms step=100ms");
        } finally {
          await stripCtx.ctx.close();
        }
      }
    }
  }
} finally {
  await browser.close();
}
fs.writeFileSync(path.join(here, `captures-${stage}.json`), JSON.stringify(log, null, 2));
console.log("wrote", path.join(here, `captures-${stage}.json`));
