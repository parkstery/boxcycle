#!/usr/bin/env node
/** P2b temp: riders=1 vs riders=3 shots to locate peer/pacer silhouettes. */
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";

const here = path.dirname(fileURLToPath(import.meta.url));
const BASE = "http://localhost:5040";

const browser = await chromium.launch({ headless: true });
try {
  for (const model of ["rider14"]) {
    const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
    await page.goto(
      `${BASE}/scripts/rider-preserve/rider-perf-bench.html?zoom=22&pitch=67&bearing=-32&riders=3&animate=0&riderModel=${model}`,
      { waitUntil: "load" },
    );
    await page.waitForFunction(() => Boolean(window.__rtwBench), null, { timeout: 120000 });
    await page.waitForFunction(() => window.__rtwBench.state().loadState === "ready", null, { timeout: 120000 });
    await page.waitForTimeout(1500);
    await page.evaluate(() => window.__rtwBench.setRiders(1));
    await page.waitForTimeout(1200);
    await page.screenshot({ path: path.join(here, `${model}-riders1.png`) });
    await page.evaluate(() => window.__rtwBench.setRiders(2));
    await page.waitForTimeout(1200);
    await page.screenshot({ path: path.join(here, `${model}-riders2.png`) });
    await page.close();
    console.log(`saved ${model} riders1/riders2`);
  }
} finally {
  await browser.close();
}
