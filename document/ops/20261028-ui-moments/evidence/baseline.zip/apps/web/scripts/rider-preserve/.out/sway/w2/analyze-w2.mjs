import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

function paeth(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  if (pb <= pc) return b;
  return c;
}

function decodePng(buf) {
  if (!buf.subarray(0, 8).equals(SIG)) throw new Error("not png");
  let o = 8;
  let width = 0;
  let height = 0;
  let bitDepth = 0;
  let colorType = 0;
  const idat = [];
  while (o + 8 <= buf.length) {
    const len = buf.readUInt32BE(o);
    o += 4;
    const type = buf.toString("ascii", o, o + 4);
    o += 4;
    const data = buf.subarray(o, o + len);
    o += len + 4;
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === "IDAT") idat.push(data);
    else if (type === "IEND") break;
  }
  if (bitDepth !== 8 || (colorType !== 6 && colorType !== 2)) throw new Error(`png ${bitDepth}/${colorType}`);
  const bpp = colorType === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * bpp;
  const out = Buffer.alloc(height * stride);
  let i = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[i++];
    const row = y * stride;
    for (let x = 0; x < stride; x++) {
      const v = raw[i++];
      const left = x >= bpp ? out[row + x - bpp] : 0;
      const up = y > 0 ? out[row - stride + x] : 0;
      const ul = y > 0 && x >= bpp ? out[row - stride + x - bpp] : 0;
      let recon = v;
      if (filter === 1) recon = (v + left) & 255;
      else if (filter === 2) recon = (v + up) & 255;
      else if (filter === 3) recon = (v + Math.floor((left + up) / 2)) & 255;
      else if (filter === 4) recon = (v + paeth(left, up, ul)) & 255;
      else if (filter !== 0) throw new Error(`filter ${filter}`);
      out[row + x] = recon;
    }
  }
  return { width, height, bpp, data: out };
}

function readPng(file) {
  const img = decodePng(fs.readFileSync(file));
  if (img.bpp === 4) return img;
  const data = Buffer.alloc(img.width * img.height * 4);
  for (let i = 0, j = 0; i < img.data.length; i += 3, j += 4) {
    data[j] = img.data[i];
    data[j + 1] = img.data[i + 1];
    data[j + 2] = img.data[i + 2];
    data[j + 3] = 255;
  }
  return { width: img.width, height: img.height, bpp: 4, data };
}

function isOrange(r, g, b) {
  return r > 170 && g > 50 && g < 160 && b < 90 && r > g + 40 && r > b + 80;
}

function isRider(r, g, b) {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  if (isOrange(r, g, b)) return true;
  if (max < 70 && max - min < 40) return true;
  if (r > 160 && g > 120 && b > 90 && r > b && max - min > 25 && max - min < 90) return true;
  return false;
}

function orangeBbox(file) {
  const img = readPng(file);
  let minX = img.width;
  let minY = img.height;
  let maxX = 0;
  let maxY = 0;
  let n = 0;
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      const i = (y * img.width + x) * 4;
      if (!isOrange(img.data[i], img.data[i + 1], img.data[i + 2])) continue;
      n += 1;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }
  return { n, minX, minY, maxX, maxY, w: maxX - minX + 1, h: maxY - minY + 1, imgW: img.width, imgH: img.height };
}

function bbox(file) {
  const img = readPng(file);
  let minX = img.width;
  let minY = img.height;
  let maxX = 0;
  let maxY = 0;
  let n = 0;
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      const i = (y * img.width + x) * 4;
      if (!isRider(img.data[i], img.data[i + 1], img.data[i + 2])) continue;
      n += 1;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }
  return { file: path.basename(file), n, minX, minY, maxX, maxY, w: maxX - minX + 1, h: maxY - minY + 1 };
}

function rowShift(offFile, onFile) {
  const off = readPng(offFile);
  const on = readPng(onFile);
  const rows = [];
  for (let y = 0; y < off.height; y++) {
    let ox = 0;
    let onx = 0;
    let oc = 0;
    let nc = 0;
    for (let x = 0; x < off.width; x++) {
      const i = (y * off.width + x) * 4;
      if (isRider(off.data[i], off.data[i + 1], off.data[i + 2])) {
        ox += x;
        oc += 1;
      }
      if (isRider(on.data[i], on.data[i + 1], on.data[i + 2])) {
        onx += x;
        nc += 1;
      }
    }
    if (oc > 8 && nc > 8) rows.push({ y, dx: onx / nc - ox / oc, oc });
  }
  const band = (a, b) => {
    const slice = rows.filter((r) => r.y >= a && r.y < b);
    if (!slice.length) return null;
    const dx = slice.reduce((s, r) => s + r.dx, 0) / slice.length;
    return Number(dx.toFixed(3));
  };
  const h = off.height;
  return {
    helmet: band(0, Math.round(h * 0.22)),
    shoulder: band(Math.round(h * 0.18), Math.round(h * 0.42)),
    hip: band(Math.round(h * 0.38), Math.round(h * 0.55)),
    wheel: band(Math.round(h * 0.62), h),
    samples: rows.length,
  };
}

function orangeGrid(file, cell) {
  const img = readPng(file);
  const cols = Math.ceil(img.width / cell);
  const rows = Math.ceil(img.height / cell);
  const counts = Array.from({ length: rows }, () => Array(cols).fill(0));
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      const i = (y * img.width + x) * 4;
      if (!isOrange(img.data[i], img.data[i + 1], img.data[i + 2])) continue;
      counts[Math.floor(y / cell)][Math.floor(x / cell)] += 1;
    }
  }
  const hits = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (counts[r][c] >= 8) hits.push({ x: c * cell, y: r * cell, n: counts[r][c] });
    }
  }
  hits.sort((a, b) => b.n - a.n);
  return hits.slice(0, 12);
}
function windowBbox(file, x0, y0, x1, y1) {
  const img = readPng(file);
  let minX = img.width;
  let minY = img.height;
  let maxX = 0;
  let maxY = 0;
  let n = 0;
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const i = (y * img.width + x) * 4;
      if (!isRider(img.data[i], img.data[i + 1], img.data[i + 2])) continue;
      n += 1;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }
  return { n, minX, minY, maxX, maxY, w: maxX - minX + 1, h: maxY - minY + 1 };
}
function cropPreview(file, x, y, w, h, out) {
  const img = readPng(file);
  const data = Buffer.alloc(w * h * 4);
  for (let row = 0; row < h; row++) {
    const src = ((y + row) * img.width + x) * 4;
    img.data.copy(data, row * w * 4, src, src + w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  const stride = w * 4;
  const raw = Buffer.alloc(h * (stride + 1));
  for (let row = 0; row < h; row++) {
    raw[row * (stride + 1)] = 0;
    data.copy(raw, row * (stride + 1) + 1, row * stride, (row + 1) * stride);
  }
  const SIG = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const chunk = (type, payload) => {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(payload.length);
    const body = Buffer.concat([Buffer.from(type), payload]);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(zlib.crc32(body) >>> 0);
    return Buffer.concat([len, body, crc]);
  };
  fs.writeFileSync(out, Buffer.concat([SIG, chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]));
}
function columnExtent(file, x0, x1, y0, y1) {
  const img = readPng(file);
  let minY = y1;
  let maxY = y0;
  let minX = x1;
  let maxX = x0;
  let n = 0;
  for (let y = y0; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const i = (y * img.width + x) * 4;
      const r = img.data[i];
      const g = img.data[i + 1];
      const b = img.data[i + 2];
      const dark = r < 90 && g < 90 && b < 90;
      if (!isOrange(r, g, b) && !dark) continue;
      n += 1;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
    }
  }
  return { n, minX, minY, maxX, maxY };
}
console.log("tight", JSON.stringify(columnExtent(path.join(here, "rear-locate.png"), 590, 710, 240, 480)));
cropPreview(path.join(here, "rear-locate.png"), 575, 255, 140, 210, path.join(here, "rear-locate-crop.png"));
console.log("wrote rear-locate-crop.png");
console.log("window", JSON.stringify(windowBbox(path.join(here, "rear-locate.png"), 520, 220, 760, 520)));
const locate = orangeBbox(path.join(here, "rear-locate.png"));
console.log("orange-locate", JSON.stringify(locate));
for (const phase of [0, 90, 180, 270]) {
  console.log("orange-phase", phase, JSON.stringify(orangeBbox(path.join(here, `phase-${phase}-on.png`))));
}
for (const phase of [0, 90, 180, 270]) {
  const shift = rowShift(
    path.join(here, `phase-${phase}-off.png`),
    path.join(here, `phase-${phase}-on.png`),
  );
  console.log("shift", phase, JSON.stringify(shift));
}

function orangeBox(img) {
  let minX = img.width;
  let minY = img.height;
  let maxX = 0;
  let maxY = 0;
  let n = 0;
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      const i = (y * img.width + x) * 4;
      if (!isOrange(img.data[i], img.data[i + 1], img.data[i + 2])) continue;
      n += 1;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }
  return { n, minX, minY, maxX, maxY };
}

function bandCentroid(img, y0, y1, pred) {
  let sx = 0;
  let n = 0;
  let left = img.width;
  let right = 0;
  for (let y = y0; y < y1; y++) {
    for (let x = 0; x < img.width; x++) {
      const i = (y * img.width + x) * 4;
      if (!pred(img.data[i], img.data[i + 1], img.data[i + 2])) continue;
      sx += x;
      n += 1;
      if (x < left) left = x;
      if (x > right) right = x;
    }
  }
  if (!n) return null;
  return { x: Number((sx / n).toFixed(2)), n, left, right, mid: Number(((left + right) / 2).toFixed(2)) };
}

function wheelAngle(img, y0, y1) {
  const pts = [];
  const mid = img.width / 2;
  for (let y = y0; y < y1; y++) {
    let bestX = 0;
    let bestV = 1e9;
    for (let x = Math.round(mid - 80); x < Math.round(mid + 80); x++) {
      const i = (y * img.width + x) * 4;
      const v = img.data[i] + img.data[i + 1] + img.data[i + 2];
      if (v < bestV) {
        bestV = v;
        bestX = x;
      }
    }
    if (bestV < 220) pts.push({ x: bestX, y });
  }
  const n = pts.length;
  if (n < 8) return { n };
  let sy = 0;
  let sx = 0;
  let syy = 0;
  let sxy = 0;
  for (const p of pts) {
    sy += p.y;
    sx += p.x;
    syy += p.y * p.y;
    sxy += p.x * p.y;
  }
  const b = (n * sxy - sx * sy) / (n * syy - sy * sy);
  return {
    n,
    degFromVertical: Number(((Math.atan(b) * 180) / Math.PI).toFixed(3)),
    xTop: Number((sx / n).toFixed(2)),
  };
}

for (const phase of [0, 180]) {
  const off = readPng(path.join(here, `rear-phase-${phase}-off.png`));
  const on = readPng(path.join(here, `rear-phase-${phase}-on.png`));
  const box = orangeBox(on);
  const yS0 = box.minY;
  const yS1 = box.minY + Math.round((box.maxY - box.minY) * 0.35);
  const yH0 = box.minY + Math.round((box.maxY - box.minY) * 0.65);
  const yH1 = box.maxY + 8;
  const shoulderOff = bandCentroid(off, yS0, yS1, isOrange);
  const shoulderOn = bandCentroid(on, yS0, yS1, isOrange);
  const hipOff = bandCentroid(off, yH0, yH1, (r, g, b) => r < 60 && g < 60 && b < 60);
  const hipOn = bandCentroid(on, yH0, yH1, (r, g, b) => r < 60 && g < 60 && b < 60);
  const yF0 = box.minY + Math.round((box.maxY - box.minY) * 0.78);
  const forkOff = bandCentroid(off, yF0, box.maxY + 1, isOrange);
  const forkOn = bandCentroid(on, yF0, box.maxY + 1, isOrange);
  const wheelOff = wheelAngle(off, box.maxY + 30, box.maxY + Math.round(off.height * 0.16));
  const wheelOn = wheelAngle(on, box.maxY + 30, box.maxY + Math.round(on.height * 0.16));
  console.log(
    "rear",
    phase,
    JSON.stringify({
      box,
      shoulderDx: shoulderOn && shoulderOff ? Number((shoulderOn.x - shoulderOff.x).toFixed(2)) : null,
      shoulderMidDx: shoulderOn && shoulderOff ? Number((shoulderOn.mid - shoulderOff.mid).toFixed(2)) : null,
      hipDx: hipOn && hipOff ? Number((hipOn.x - hipOff.x).toFixed(2)) : null,
      forkDx: forkOn && forkOff ? Number((forkOn.x - forkOff.x).toFixed(2)) : null,
      forkN: forkOn?.n ?? 0,
      wheelOff,
      wheelOn,
      wheelDegDelta:
        wheelOn.degFromVertical != null && wheelOff.degFromVertical != null
          ? Number((wheelOn.degFromVertical - wheelOff.degFromVertical).toFixed(3))
          : null,
      wheelXDelta:
        wheelOn.xTop != null && wheelOff.xTop != null ? Number((wheelOn.xTop - wheelOff.xTop).toFixed(2)) : null,
    }),
  );
}
