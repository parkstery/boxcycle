#!/usr/bin/env node
/** P2b temp: locate riders via riders1/riders2/riders3 diffs + sample peer/pacer colors. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

const r1 = decodePng(fs.readFileSync(path.join(here, "rider14-riders1.png")));
const r2 = decodePng(fs.readFileSync(path.join(here, "rider14-riders2.png")));
const r3 = decodePng(fs.readFileSync(path.join(here, "rider14-z22.png")));
const { width, height } = r1;
const px = (s, x, y) => { const i = (y * width + x) * s.ch; return [s.pixels[i], s.pixels[i + 1], s.pixels[i + 2]]; };
const dist = (p, q) => Math.abs(p[0] - q[0]) + Math.abs(p[1] - q[1]) + Math.abs(p[2] - q[2]);

// riders2-riders1 = peer 실루엣, riders3-riders2 = pacer 실루엣
for (const [name, x, y] of [["r2-r1(peer)", r2, r1], ["r3-r2(pacer)", r3, r2]]) {
  const CELL = 8;
  const cols = Math.ceil(width / CELL);
  const rows = Math.ceil(height / CELL);
  const grid = new Uint16Array(cols * rows);
  for (let yy = 0; yy < height; yy++) {
    for (let xx = 0; xx < width; xx++) {
      if (dist(px(x, xx, yy), px(y, xx, yy)) > 60) grid[Math.floor(yy / CELL) * cols + Math.floor(xx / CELL)]++;
    }
  }
  console.log(`--- ${name} diff cells ---`);
  for (let r = 0; r < rows; r++) {
    let line = "";
    for (let c = 0; c < cols; c++) {
      const n = grid[r * cols + c];
      line += n === 0 ? "." : n < 6 ? "+" : n < 20 ? "x" : "#";
    }
    if (/[+#x]/.test(line)) console.log(`${String(r * CELL).padStart(3)} ${line.slice(25, 115)}`);
  }
}
