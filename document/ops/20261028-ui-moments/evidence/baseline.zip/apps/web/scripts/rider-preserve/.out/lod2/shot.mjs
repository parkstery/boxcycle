import { chromium } from "@playwright/test";
const b = await chromium.launch();
const ctx = await b.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 3 });
for (const z of [18.9, 19.1]) {
  const p = await ctx.newPage();
  await p.goto(`http://localhost:5070/scripts/rider-preserve/rider-perf-bench.html?zoom=${z}&riders=3&animate=0&phase=90`, { waitUntil: "load" });
  await p.waitForFunction(() => window.__rtwBench?.state().loadState === "ready", null, { timeout: 60000 });
  await p.evaluate(() => window.__rtwBench.measure(30));
  await p.waitForTimeout(2500);
  await p.addStyleTag({ content: "#panel{display:none!important}" });
  await p.screenshot({ path: `scripts/rider-preserve/.out/lod2/z${z}.png`, clip: { x: 560, y: 360, width: 140, height: 70 } });
  await p.close();
}
await b.close();
