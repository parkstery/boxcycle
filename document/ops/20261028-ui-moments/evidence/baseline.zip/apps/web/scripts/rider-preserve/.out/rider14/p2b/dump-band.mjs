#!/usr/bin/env node
/** P2b temp: rider band ASCII colormap dump for s5 vs rider14 shots. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

function classify(r, g, b) {
  if (r > 140 && r - g > 40 && g - b > 20 && b < 150) return "O";
  if (g > 90 && b > 90 && g - r > 20 && b - r > 10) return "T";
  const mx = Math.max(r, g, b); const mn = Math.min(r, g, b);
  if (mx - mn < 45 && r >= 100 && r <= 230 && g >= 100 && b >= 90) return "S";
  if (r < 60 && g < 60 && b < 60) return "#";
  return ".";
}

for (const name of ["s5-z22.png", "rider14-z22.png"]) {
  const { width, height, ch, pixels } = decodePng(fs.readFileSync(path.join(here, name)));
  console.log(`=== ${name} (${width}x${height}) band x[280,720] y[230,420] step 4x4 ===`);
  for (let y = 230; y < 420; y += 4) {
    let line = "";
    for (let x = 280; x < 720; x += 4) {
      const at = (y * width + x) * ch;
      line += classify(pixels[at], pixels[at + 1], pixels[at + 2]);
    }
    console.log(line);
  }
}
