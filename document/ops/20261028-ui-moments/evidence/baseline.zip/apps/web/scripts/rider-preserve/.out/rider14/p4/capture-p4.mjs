// P4 캡처 (Supervisor 대행). 실행: apps/web 에서 node scripts/rider-preserve/.out/rider14/p4/capture-p4.mjs
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";

const here = path.dirname(fileURLToPath(import.meta.url));
const BASE = "http://localhost:5040/scripts/rider-preserve/rider-perf-bench.html";
// 지도 최대 줌 22 — 근접은 DPR 4 로 찍고 라이더 주변(css 좌표)만 잘라 해상도를 얻는다.
const SHOTS = [
  { name: "near-side", dpr: 3, clip: { x: 168, y: 280, width: 552, height: 150 }, q: { zoom: 22, pitch: 75, bearing: 0, riders: 3 } },
  { name: "near-persp", dpr: 2, clip: { x: 260, y: 200, width: 480, height: 260 }, q: { zoom: 22, pitch: 67, bearing: -32, riders: 3 } },
  { name: "rider-close", dpr: 4, clip: { x: 568, y: 282, width: 150, height: 128 }, q: { zoom: 22, pitch: 70, bearing: 10, riders: 1, phase: 90 } },
  { name: "shoe", dpr: 6, clip: { x: 603, y: 352, width: 66, height: 50 }, q: { zoom: 22, pitch: 70, bearing: 10, riders: 1, phase: 90 } },
  ...[0, 90, 180, 270].map((p) => ({ name: `phase-${p}`, dpr: 4, clip: { x: 578, y: 282, width: 134, height: 124 }, q: { zoom: 22, pitch: 78, bearing: 0, riders: 1, phase: p } })),
  { name: "mid", dpr: 2, q: { zoom: 19, pitch: 60, bearing: -32, riders: 3 } },
  { name: "far", dpr: 2, q: { zoom: 17, pitch: 60, bearing: -32, riders: 3 } },
];
const only = process.argv[2];
const browser = await chromium.launch({ headless: true });
const log = [];
try {
  const contexts = new Map();
  const ctxFor = async (dpr) => {
    if (!contexts.has(dpr)) contexts.set(dpr, await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: dpr }));
    return contexts.get(dpr);
  };
  for (const shot of SHOTS) {
    const ctx = await ctxFor(shot.dpr);
    if (only && shot.name !== only) continue;
    for (const model of ["s5", "rider14"]) {
      const page = await ctx.newPage();
      const errors = [];
      page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
      page.on("pageerror", (e) => errors.push(String(e)));
      const qs = new URLSearchParams({ animate: "0", riderModel: model, ...Object.fromEntries(Object.entries(shot.q).map(([k, v]) => [k, String(v)])) });
      for (let attempt = 0; ; attempt++) {
        try {
          await page.goto(`${BASE}?${qs}`, { waitUntil: "load" });
          await page.waitForFunction(() => window.__rtwBench?.state().loadState === "ready", null, { timeout: 30000 });
          break;
        } catch (error) {
          if (attempt >= 2) throw error;
          errors.length = 0;
        }
      }
      await page.waitForFunction(() => window.__rtwBench?.state().loadState === "ready", null, { timeout: 60000 });
      await page.evaluate(() => new Promise((r) => { const m = window.__rtwBench; void m; setTimeout(r, 0); }));
      await page.evaluate(() => window.__rtwBench.measure(30));
      await page.waitForTimeout(1500);
      await page.addStyleTag({ content: "#panel{display:none!important}" });
      await page.waitForTimeout(200);
      const file = path.join(here, `${shot.name}-${model}.png`);
      await page.screenshot({ path: file, ...(shot.clip ? { clip: shot.clip } : {}) });
      log.push({ shot: shot.name, model, file, errors });
      console.log(shot.name, model, errors.length ? `errors=${errors.length}` : "ok");
      await page.close();
    }
  }
} finally {
  await browser.close();
}
fs.writeFileSync(path.join(here, only ? `captures-${only}.json` : "captures.json"), JSON.stringify(log, null, 2));
