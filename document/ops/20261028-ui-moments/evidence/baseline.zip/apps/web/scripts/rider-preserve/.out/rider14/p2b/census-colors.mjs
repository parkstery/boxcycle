#!/usr/bin/env node
/** P2b temp: color census inside peer/pacer silhouettes, rider14 riders3 shot. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

const shot = decodePng(fs.readFileSync(path.join(here, "rider14-z22.png")));
const px = (x, y) => { const i = (y * shot.width + x) * shot.ch; return [shot.pixels[i], shot.pixels[i + 1], shot.pixels[i + 2]]; };

// 기대 sRGB(무조명): self 주황(255,128,0) / peer teal 헬멧(77,150,147)·저지(69,181,175) / pacer 슬레이트 헬멧(179,188,197)·저지(160,170,184)
function nearest(r, g, b) {
  const cands = {
    orange: [255, 128, 0],
    tealH: [77, 150, 147],
    tealJ: [69, 181, 175],
    slateH: [179, 188, 197],
    slateJ: [160, 170, 184],
  };
  let best = null; let bd = 1e9;
  for (const [k, c] of Object.entries(cands)) {
    const d = Math.abs(r - c[0]) + Math.abs(g - c[1]) + Math.abs(b - c[2]);
    if (d < bd) { bd = d; best = k; }
  }
  return { cls: best, d: bd };
}

for (const [label, x0, x1, y0, y1] of [["PEER", 390, 520, 280, 395], ["PACER", 300, 390, 232, 330], ["SELF", 600, 700, 280, 395]]) {
  const tally = {};
  const samples = [];
  for (let y = y0; y <= y1; y += 2) {
    for (let x = x0; x <= x1; x += 2) {
      const [r, g, b] = px(x, y);
      const { cls, d } = nearest(r, g, b);
      if (d > 150) continue; // 배경
      tally[cls] = (tally[cls] ?? 0) + 1;
      if (samples.length < 12) samples.push(`(${x},${y})=[${r},${g},${b}]→${cls}`);
    }
  }
  console.log(`${label}:`, JSON.stringify(tally));
  for (const s of samples) console.log(`   ${s}`);
}
