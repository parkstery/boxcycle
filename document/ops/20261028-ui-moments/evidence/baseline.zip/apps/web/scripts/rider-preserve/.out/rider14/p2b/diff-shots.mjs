#!/usr/bin/env node
/** P2b temp: diff s5 vs rider14 shots; print clusters of differing pixels + colors. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

const a = decodePng(fs.readFileSync(path.join(here, "s5-z22.png")));
const b = decodePng(fs.readFileSync(path.join(here, "rider14-z22.png")));
const { width, height } = a;

// 8px 셀 단위로 다른 픽셀 수 집계 → 라이더 위치 추定
const CELL = 8;
const cols = Math.ceil(width / CELL);
const rows = Math.ceil(height / CELL);
const grid = new Uint16Array(cols * rows);
for (let y = 0; y < height; y++) {
  for (let x = 0; x < width; x++) {
    const ia = (y * width + x) * a.ch;
    const ib = (y * width + x) * b.ch;
    const d = Math.abs(a.pixels[ia] - b.pixels[ib])
      + Math.abs(a.pixels[ia + 1] - b.pixels[ib + 1])
      + Math.abs(a.pixels[ia + 2] - b.pixels[ib + 2]);
    if (d > 60) grid[Math.floor(y / CELL) * cols + Math.floor(x / CELL)]++;
  }
}
console.log("diff cells (>3 diff px per 8x8 cell), x:0-1280 y:0-800 step 8:");
for (let r = 0; r < rows; r++) {
  let line = "";
  for (let c = 0; c < cols; c++) {
    const n = grid[r * cols + c];
    line += n === 0 ? "." : n < 6 ? "+" : n < 20 ? "x" : "#";
  }
  if (/[+#x]/.test(line)) console.log(`${String(r * CELL).padStart(3)} ${line.slice(30, 110)}`);
}
