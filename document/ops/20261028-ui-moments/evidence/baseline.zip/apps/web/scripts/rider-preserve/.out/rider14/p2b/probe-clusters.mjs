#!/usr/bin/env node
/** P2b temp: dense color samples in the two diff clusters, both shots. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

const s5 = decodePng(fs.readFileSync(path.join(here, "s5-z22.png")));
const r14 = decodePng(fs.readFileSync(path.join(here, "rider14-z22.png")));

function px(shot, x, y) {
  const at = (y * shot.width + x) * shot.ch;
  return [shot.pixels[at], shot.pixels[at + 1], shot.pixels[at + 2]];
}

// 두 차이 클러스터를 4px 격자로: s5 와 r14 의 색을 나란히, 다른 픽셀만 출력
for (const [x0, x1, y0, y1, label] of [[280, 400, 230, 410, "LEFT"], [520, 645, 230, 410, "MID"]]) {
  console.log(`--- ${label} x[${x0},${x1}] y[${y0},${y1}] (differing pixels only) ---`);
  for (let y = y0; y <= y1; y += 4) {
    let line = "";
    for (let x = x0; x <= x1; x += 4) {
      const c1 = px(s5, x, y);
      const c2 = px(r14, x, y);
      const d = Math.abs(c1[0] - c2[0]) + Math.abs(c1[1] - c2[1]) + Math.abs(c1[2] - c2[2]);
      if (d <= 60) { line += " "; continue; }
      const tag = (c) => {
        const [r, g, b] = c;
        if (r > 140 && r - g > 40 && g - b > 20 && b < 150) return "O";
        if (g > 90 && b > 90 && g - r > 20 && b - r > 10) return "T";
        if (r < 60 && g < 60 && b < 60) return "#";
        return "?";
      };
      line += `${tag(c1)}>${tag(c2)} `.slice(0, 2);
    }
    if (line.trim()) console.log(`${y}: ${line}`);
  }
}
