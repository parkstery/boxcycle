#!/usr/bin/env node
/** P2b one-off capture: s5 vs rider14 stills + palette color classes. Temp file, not committed. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";
import { chromium } from "@playwright/test";

const here = path.dirname(fileURLToPath(import.meta.url));
const BASE = process.env.RTW_BENCH_BASE ?? "http://localhost:5040";
const FRAMES = 60;

function urlFor(model) {
  const q = `zoom=22&pitch=67&bearing=-32&riders=3&animate=0${model ? `&riderModel=${model}` : ""}`;
  return `${BASE}/scripts/rider-preserve/rider-perf-bench.html?${q}`;
}

async function waitReady(page, timeoutMs = 120000) {
  await page.waitForFunction(() => Boolean(window.__rtwBench), null, { timeout: timeoutMs });
  await page.waitForFunction(() => window.__rtwBench.state().loadState === "ready", null, {
    timeout: timeoutMs,
  });
}

/** 8비트 RGB/RGBA non-interlaced PNG 전용 해독기. */
function decodePng(png) {
  let pos = 8;
  let width = 0;
  let height = 0;
  let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      if (data[8] !== 8 || (data[9] !== 2 && data[9] !== 6)) {
        throw new Error(`unsupported PNG depth=${data[8]} ctype=${data[9]}`);
      }
      if (data[12] !== 0) throw new Error("interlaced PNG unsupported");
      ctype = data[9];
    } else if (type === "IDAT") {
      idat.push(Buffer.from(data));
    } else if (type === "IEND") {
      break;
    }
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a);
        const pb = Math.abs(q - b);
        const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

function classify(r, g, b) {
  if (r > 140 && r - g > 40 && g - b > 20 && b < 150) return "orange";
  if (g > 90 && b > 90 && g - r > 20 && b - r > 10) return "teal";
  const mx = Math.max(r, g, b);
  const mn = Math.min(r, g, b);
  if (mx - mn < 45 && r >= 100 && r <= 230 && g >= 100 && b >= 90) return "slate";
  return null;
}

/** 패널(좌상단) 제외 전 화면에서 색상 클래스별 픽셀 수·bbox. */
function analyzeShot(pngPath) {
  const { width, height, ch, pixels } = decodePng(fs.readFileSync(pngPath));
  const stats = {
    orange: { n: 0, x0: width, y0: height, x1: 0, y1: 0 },
    teal: { n: 0, x0: width, y0: height, x1: 0, y1: 0 },
    slate: { n: 0, x0: width, y0: height, x1: 0, y1: 0 },
  };
  for (let y = 0; y < height; y += 2) {
    for (let x = 0; x < width; x += 2) {
      if (x < 480 && y < 230) continue; // 측정 패널 제외
      const at = (y * width + x) * ch;
      const cls = classify(pixels[at], pixels[at + 1], pixels[at + 2]);
      if (!cls) continue;
      const s = stats[cls];
      s.n++;
      if (x < s.x0) s.x0 = x;
      if (y < s.y0) s.y0 = y;
      if (x > s.x1) s.x1 = x;
      if (y > s.y1) s.y1 = y;
    }
  }
  return { width, height, step: 2, stats };
}

async function runModel(browser, model, outName) {
  const errors = [];
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("console", (msg) => {
    if (msg.type() === "error") errors.push(`console.error: ${msg.text()}`);
  });
  page.on("pageerror", (err) => errors.push(`pageerror: ${String(err?.message ?? err)}`));
  await page.goto(urlFor(model), { waitUntil: "load" });
  await waitReady(page);
  const state = await page.evaluate(() => window.__rtwBench.state());
  const panelCandidate = await page.evaluate(
    () => document.querySelector("#panel code")?.textContent ?? "(missing)",
  );
  const m3 = await page.evaluate((f) => window.__rtwBench.measure(f), FRAMES);
  await page.evaluate(() => window.__rtwBench.setRiders(0));
  await page.waitForTimeout(800);
  const m0 = await page.evaluate((f) => window.__rtwBench.measure(f), FRAMES);
  await page.evaluate(() => window.__rtwBench.setRiders(1));
  await page.waitForTimeout(800);
  const m1 = await page.evaluate((f) => window.__rtwBench.measure(f), FRAMES);
  await page.evaluate(() => window.__rtwBench.setRiders(3));
  await page.waitForTimeout(1500);
  const shotPath = path.join(here, outName);
  await page.screenshot({ path: shotPath });
  await page.close();
  const analysis = analyzeShot(shotPath);
  return {
    model: model ?? "s5(default)",
    loadState: state.loadState,
    panelCandidate,
    riders3: m3,
    riders0: m0,
    riders1: m1,
    perRiderDrawFrom3: (m3.drawCallsPerFrame - m0.drawCallsPerFrame) / 3,
    perRiderDrawFrom1: m1.drawCallsPerFrame - m0.drawCallsPerFrame,
    perRiderTriFrom3: (m3.trianglesPerFrame - m0.trianglesPerFrame) / 3,
    perRiderTriFrom1: m1.trianglesPerFrame - m0.trianglesPerFrame,
    capture: shotPath,
    colorAnalysis: analysis,
    consoleErrors: errors,
  };
}

const attempts = [
  { gpuPath: "default", args: [] },
  { gpuPath: "swiftshader", args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader"] },
];
let result = null;
let lastError = null;
for (const attempt of attempts) {
  let browser = null;
  try {
    console.log(`launch: gpuPath=${attempt.gpuPath}`);
    browser = await chromium.launch({ headless: true, args: attempt.args });
    const s5 = await runModel(browser, null, "s5-z22.png");
    const r14 = await runModel(browser, "rider14", "rider14-z22.png");
    result = { meta: { gpuPath: attempt.gpuPath, base: BASE, at: new Date().toISOString() }, s5, r14 };
    break;
  } catch (error) {
    lastError = error;
    console.error(`attempt ${attempt.gpuPath} failed: ${error?.message ?? error}`);
    if (attempt.gpuPath === "swiftshader") throw error;
  } finally {
    await browser?.close();
  }
}
if (!result) throw lastError ?? new Error("capture failed");
fs.writeFileSync(path.join(here, "p2b-captures.json"), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
