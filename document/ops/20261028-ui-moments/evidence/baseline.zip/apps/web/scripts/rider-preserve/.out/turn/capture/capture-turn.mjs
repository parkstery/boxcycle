/**
 * T1 육안 준비. 기존 dev 서버(127.0.0.1:5070)만 사용. 서버를 띄우거나 끄지 않는다.
 * 입문 Basic 2 파리 퐁뇌프 — 경로 거리 약 140 m 에서 방위가 +80° 꺾인다.
 */
import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const require = createRequire("C:/20.HDev/boxcycle-turn/apps/web/package.json");
const { chromium } = require("playwright");

const here = path.dirname(fileURLToPath(import.meta.url));
const BASE = "http://127.0.0.1:5070";
const CORNER_KM = 0.13;

function log(...args) {
  console.log("[turn-capture]", ...args);
}

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
page.setDefaultTimeout(20_000);
page.on("console", (msg) => {
  if (msg.type() === "error") log("console.error", msg.text().slice(0, 240));
});

const report = { base: BASE, steps: [], error: null, passes: [] };

async function shot(name) {
  const file = path.join(here, name);
  await page.screenshot({ path: file });
  log("shot", name);
  return file;
}

async function enterMap() {
  await page.goto(`${BASE}/`, { waitUntil: "domcontentloaded", timeout: 30_000 });
  const intro = page.getByRole("region", { name: "앱 소개" });
  const gate = page.getByRole("dialog", { name: "시작" });
  const trail = page.getByRole("button", { name: "Trail 메뉴" });
  const failed = page.getByText("서비스에 연결할 수 없습니다.", { exact: true });
  const unconfigured = page.getByText("Firebase 설정 필요", { exact: true });
  const deadline = Date.now() + 50_000;
  let surface = "waiting";
  while (Date.now() < deadline) {
    if (await failed.isVisible().catch(() => false)) {
      surface = "connect-failed";
      break;
    }
    if (await unconfigured.isVisible().catch(() => false)) {
      surface = "unconfigured";
      break;
    }
    if (await intro.isVisible().catch(() => false)) {
      surface = "intro";
      await intro.getByRole("button", { name: "시작하기", exact: true }).click();
      await intro.waitFor({ state: "hidden", timeout: 15_000 });
      continue;
    }
    if (await gate.isVisible().catch(() => false)) {
      surface = "guest";
      await gate.getByRole("button", { name: "시작", exact: true }).click();
      await gate.waitFor({ state: "hidden", timeout: 30_000 });
      continue;
    }
    const menuClose = page.getByRole("button", { name: "메뉴 닫기" }).first();
    if (await menuClose.isVisible().catch(() => false)) {
      await menuClose.click();
      await page.waitForTimeout(300);
      continue;
    }
    const dock = await page.locator(".route-dock-anchor").count();
    if (dock > 0 && (await trail.isVisible().catch(() => false))) {
      surface = "map";
      break;
    }
    await page.waitForTimeout(400);
  }
  log("entrySurface", surface);
  if (surface !== "map") throw new Error(`entry did not reach map (${surface})`);
}

async function armAndRide() {
  const caret = page.getByRole("button", { name: /^센서 설정 열기/ });
  const expand = page.getByRole("button", { name: /^경로 패널 펼치기/ });
  const chip = page.getByRole("button", { name: /^케이던스 센서/ });
  await caret.or(expand).or(chip).first().waitFor({ state: "visible", timeout: 30_000 });
  if (await caret.isVisible().catch(() => false)) await caret.click();
  else {
    if (await expand.isVisible().catch(() => false)) await expand.click();
    await chip.click();
  }
  const sheet = page.getByRole("dialog", { name: "케이던스 센서" });
  await sheet.waitFor({ state: "visible", timeout: 15_000 });
  await sheet.getByRole("button", { name: "센서 없음" }).click();
  const speed = sheet.getByRole("spinbutton", { name: "속도 km/h" });
  await speed.click();
  await speed.fill("20");
  await speed.press("Enter");
  await sheet.getByRole("button", { name: "센서 설정 닫기" }).click();
  await sheet.waitFor({ state: "hidden", timeout: 15_000 });

  await page.getByRole("button", { name: "Trail 메뉴" }).click();
  await page.getByRole("button", { name: "입문", exact: true }).click();
  const modal = page.getByRole("dialog").filter({ has: page.locator("#oc-modal-title") });
  await modal.waitFor({ state: "visible", timeout: 20_000 });
  await modal.getByRole("button", { name: /파리 퐁뇌프/ }).click();
  const start = page.getByRole("button", { name: "주행 시작" });
  await start.waitFor({ state: "visible", timeout: 25_000 });
  await start.click();
  await page.getByRole("button", { name: "주행 종료" }).waitFor({ state: "visible", timeout: 40_000 });
}

async function readDistKm() {
  return page.evaluate(() => {
    const el = document.querySelector(".hud-metrics__cell--w-distance .hud-metrics__value");
    if (!el) return null;
    const n = Number.parseFloat(el.textContent ?? "");
    return Number.isFinite(n) ? n : null;
  });
}

async function burst(prefix) {
  const deadline = Date.now() + 70_000;
  let dist = null;
  while (Date.now() < deadline) {
    dist = await readDistKm();
    if (dist != null && dist >= CORNER_KM) break;
    await page.waitForTimeout(100);
  }
  if (dist == null || dist < CORNER_KM) {
    throw new Error(`distance did not reach ${CORNER_KM} km (last ${dist})`);
  }
  const files = [];
  for (let i = 0; i < 12; i += 1) {
    const name = `${prefix}-${String(i).padStart(2, "0")}.png`;
    files.push(await shot(name));
    if (i < 11) await page.waitForTimeout(200);
  }
  const distEnd = await readDistKm();
  return { distStart: dist, distEnd, files };
}

try {
  await enterMap();
  await armAndRide();
  const cam2 = page.getByRole("button", { name: "카메라 2", exact: true });
  await cam2.click();
  await page.waitForTimeout(600);
  report.passes.push({ camera: "2-behind", ...(await burst("cam2")) });

  await page.reload({ waitUntil: "domcontentloaded" });
  await enterMap();
  await armAndRide();
  const cam1 = page.getByRole("button", { name: /^카메라 1/ });
  for (let i = 0; i < 4; i += 1) {
    const label = (await cam1.getAttribute("aria-label")) ?? "";
    log("cam1", label);
    if (label.includes("20m")) break;
    await cam1.click();
    await page.waitForTimeout(500);
  }
  report.passes.push({ camera: "1-above-20m", ...(await burst("cam1")) });
} catch (error) {
  report.error = String(error && error.stack ? error.stack : error);
  log("FAIL", report.error.split("\n")[0]);
  try {
    await shot("failure.png");
  } catch {
    /* page may be closed */
  }
} finally {
  fs.writeFileSync(path.join(here, "capture-report.json"), JSON.stringify(report, null, 2));
  await browser.close();
}

if (report.error) process.exit(1);
