#!/usr/bin/env node
/** P2b temp: peer/pacer jersey colors s5 vs rider14 at identical coords. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

const s5 = decodePng(fs.readFileSync(path.join(here, "s5-z22.png")));
const r14 = decodePng(fs.readFileSync(path.join(here, "rider14-z22.png")));
const px = (s, x, y) => { const i = (y * s.width + x) * s.ch; return [s.pixels[i], s.pixels[i + 1], s.pixels[i + 2]]; };

// 동행 teal bbox(x412-450 y286-318)와 페이서 영역(x300-390 y232-330): teal-ish 픽셀 상위 15개 출력
for (const [label, x0, x1, y0, y1] of [["PEERBOX", 405, 460, 280, 325], ["PACERBOX", 300, 390, 232, 330]]) {
  console.log(`--- ${label} ---`);
  const rows = [];
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      const c = px(r14, x, y);
      if (c[1] > 90 && c[2] > 90 && c[1] - c[0] > 20 && c[2] - c[0] > 10) {
        rows.push(`(${x},${y}) r14=[${c}] s5=[${px(s5, x, y)}]`);
      }
    }
  }
  console.log(`r14 teal-ish px: ${rows.length}`);
  for (const r of rows.slice(0, 15)) console.log(r);
}
