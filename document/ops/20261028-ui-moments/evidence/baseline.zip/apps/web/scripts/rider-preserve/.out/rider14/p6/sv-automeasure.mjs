import { chromium } from "@playwright/test";
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 390, height: 844 } });
await p.goto("http://localhost:5040/scripts/rider-preserve/rider-perf-bench.html?riderModel=rider14&autoMeasure=1&zoom=22", { waitUntil: "load" });
await p.waitForFunction(() => document.querySelector("#measure")?.textContent?.includes("AUTO"), null, { timeout: 120000 });
console.log(await p.textContent("#measure"));
await p.screenshot({ path: "scripts/rider-preserve/.out/rider14/p6/sv-automeasure.png" });
await b.close();
