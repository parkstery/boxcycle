#!/usr/bin/env node
/** P2b temp: exact RGB probe grid over rider clusters, s5 vs rider14. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import zlib from "node:zlib";

const here = path.dirname(fileURLToPath(import.meta.url));

function decodePng(png) {
  let pos = 8;
  let width = 0; let height = 0; let ctype = 0;
  const idat = [];
  while (pos + 8 <= png.length) {
    const length = png.readUInt32BE(pos);
    const type = png.toString("ascii", pos + 4, pos + 8);
    const data = png.subarray(pos + 8, pos + 8 + length);
    if (type === "IHDR") { width = data.readUInt32BE(0); height = data.readUInt32BE(4); ctype = data[9]; }
    else if (type === "IDAT") idat.push(Buffer.from(data));
    else if (type === "IEND") break;
    pos += 12 + length;
  }
  const ch = ctype === 6 ? 4 : 3;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * ch;
  const pixels = new Uint8Array(width * height * ch);
  let prev = new Uint8Array(stride);
  let at = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[at++];
    const row = raw.subarray(at, at + stride);
    at += stride;
    const out = new Uint8Array(stride);
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? out[i - ch] : 0;
      const b = prev[i];
      const c = i >= ch ? prev[i - ch] : 0;
      let v = row[i];
      if (filter === 1) v = (v + a) & 255;
      else if (filter === 2) v = (v + b) & 255;
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 255;
      else if (filter === 4) {
        const q = a + b - c;
        const pa = Math.abs(q - a); const pb = Math.abs(q - b); const pc = Math.abs(q - c);
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 255;
      }
      out[i] = v;
    }
    pixels.set(out, y * stride);
    prev = out;
  }
  return { width, height, ch, pixels };
}

const shots = {};
for (const name of ["s5-z22.png", "rider14-z22.png"]) {
  shots[name] = decodePng(fs.readFileSync(path.join(here, name)));
}

function px(shot, x, y) {
  const { width, ch, pixels } = shot;
  const at = (y * width + x) * ch;
  return [pixels[at], pixels[at + 1], pixels[at + 2]];
}

// 좌측 라이더 무리(x 300–400) + 우측 self(x 620–700): 10px 격자, s5|r14 병기
for (let y = 280; y <= 390; y += 10) {
  for (const x of [310, 330, 350, 370, 630, 650, 670]) {
    const a = px(shots["s5-z22.png"], x, y);
    const b = px(shots["rider14-z22.png"], x, y);
    const same = a[0] === b[0] && a[1] === b[1] && a[2] === b[2] ? "=" : "!";
    console.log(`(${x},${y}) s5=[${a}] r14=[${b}] ${same}`);
  }
}
