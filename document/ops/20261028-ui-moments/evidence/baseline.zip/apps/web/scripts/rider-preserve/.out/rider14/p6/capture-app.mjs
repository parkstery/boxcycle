/**
 * P6 — 기존 dev 서버(http://localhost:5040)만 사용. 서버를 띄우거나 끄지 않는다.
 * 브라우저 1개. 진입은 e2e rideEntryHelpers / camera-qc-lightlab 와 같은 버튼 이름.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const here = path.dirname(fileURLToPath(import.meta.url));
const OUT = here;
const BASE = "http://localhost:5040";
const riderHits = [];

function log(...args) {
  console.log("[p6-capture]", ...args);
}

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
page.setDefaultTimeout(20_000);
page.on("response", (res) => {
  const url = res.url();
  if (url.includes("/rider/preserved/candidates/") || url.includes("rider-lowpoly.glb")) {
    riderHits.push({ url, status: res.status() });
    log("asset", res.status(), url);
  }
});
page.on("console", (msg) => {
  if (msg.type() === "error") log("console.error", msg.text().slice(0, 300));
});

const report = {
  base: BASE,
  startedAt: new Date().toISOString(),
  steps: [],
  riderHits: [],
  performanceRiderUrls: [],
  lightLabVisible: false,
  screenshots: [],
  error: null,
};

async function shot(name) {
  const file = path.join(OUT, name);
  await page.screenshot({ path: file, fullPage: false });
  report.screenshots.push(file);
  log("shot", file);
}

async function step(name, fn) {
  log("step", name);
  report.steps.push(name);
  await fn();
}

try {
  await step("goto", async () => {
    await page.goto(`${BASE}/?lightlab=1`, { waitUntil: "domcontentloaded", timeout: 30_000 });
  });

  await step("entry", async () => {
    const intro = page.getByRole("region", { name: "앱 소개" });
    const gate = page.getByRole("dialog", { name: "시작" });
    const account = page.getByRole("button", { name: "사용자 정보" });
    const trail = page.getByRole("button", { name: "Trail 메뉴" });
    const failed = page.getByText("서비스에 연결할 수 없습니다.", { exact: true });
    const unconfigured = page.getByText("Firebase 설정 필요", { exact: true });
    const deadline = Date.now() + 50_000;
    let surface = "waiting";
    while (Date.now() < deadline) {
      if (await failed.isVisible().catch(() => false)) {
        surface = "connect-failed";
        break;
      }
      if (await unconfigured.isVisible().catch(() => false)) {
        surface = "unconfigured";
        break;
      }
      if (await intro.isVisible().catch(() => false)) {
        surface = "intro";
        await intro.getByRole("button", { name: "시작하기", exact: true }).click();
        await intro.waitFor({ state: "hidden", timeout: 15_000 });
        continue;
      }
      if (await gate.isVisible().catch(() => false)) {
        surface = "guest";
        await gate.getByRole("button", { name: "시작", exact: true }).click();
        await gate.waitFor({ state: "hidden", timeout: 30_000 });
        continue;
      }
      const menuClose = page.getByRole("button", { name: "메뉴 닫기" }).first();
      if (await menuClose.isVisible().catch(() => false)) {
        await menuClose.click();
        await page.waitForTimeout(300);
        continue;
      }
      const dock = await page.locator(".route-dock-anchor").count();
      if (dock > 0 && (await trail.isVisible().catch(() => false))) {
        surface = "map";
        break;
      }
      await page.waitForTimeout(400);
    }
    report.entrySurface = surface;
    log("entrySurface", surface);
    if (surface !== "map") throw new Error(`entry did not reach map (${surface})`);
  });

  await step("lightlab-before-ride", async () => {
    report.lightLabCountBeforeRide = await page.locator(".light-lab").count();
    const diag = await page.evaluate(() => {
      const buttons = [...document.querySelectorAll("button")].slice(0, 40).map((b) => ({
        name: b.getAttribute("aria-label") || b.textContent?.trim().slice(0, 40) || "",
        hidden: b.offsetParent == null,
      }));
      return {
        title: document.title,
        text: (document.body?.innerText || "").replace(/\s+/g, " ").slice(0, 500),
        buttons,
        dock: Boolean(document.querySelector(".route-dock-anchor")),
        lightLab: Boolean(document.querySelector(".light-lab")),
      };
    });
    report.uiDiag = diag;
    log("ui", JSON.stringify(diag).slice(0, 800));
    const toggle = page.locator(".light-lab").getByRole("button", { name: "조절판 펼치기" });
    if (await toggle.isVisible().catch(() => false)) {
      await toggle.click();
      await page.waitForTimeout(400);
    }
    await shot("app-after-entry.png");
  });

  await step("arm-and-ride", async () => {
    const intro = page.getByRole("region", { name: "앱 소개" });
    if (await intro.isVisible().catch(() => false)) {
      await intro.getByRole("button", { name: "시작하기", exact: true }).click();
      await intro.waitFor({ state: "hidden", timeout: 15_000 });
    }
    const caret = page.getByRole("button", { name: /^센서 설정 열기/ });
    const expand = page.getByRole("button", { name: /^경로 패널 펼치기/ });
    const chip = page.getByRole("button", { name: /^케이던스 센서/ });
    await caret.or(expand).or(chip).first().waitFor({ state: "visible", timeout: 30_000 });
    if (await caret.isVisible().catch(() => false)) await caret.click();
    else {
      if (await expand.isVisible().catch(() => false)) await expand.click();
      await chip.click();
    }
    const sheet = page.getByRole("dialog", { name: "케이던스 센서" });
    await sheet.waitFor({ state: "visible", timeout: 15_000 });
    await sheet.getByRole("button", { name: "센서 없음" }).click();
    await sheet.getByRole("button", { name: "센서 설정 닫기" }).click();
    await sheet.waitFor({ state: "hidden", timeout: 15_000 });

    await page.getByRole("button", { name: "Trail 메뉴" }).click();
    await page.getByRole("button", { name: "입문", exact: true }).click();
    const modal = page.getByRole("dialog").filter({ has: page.locator("#oc-modal-title") });
    await modal.waitFor({ state: "visible", timeout: 20_000 });
    await modal.locator("button.oc-modal__item").first().click();
    const start = page.getByRole("button", { name: "주행 시작" });
    await start.waitFor({ state: "visible", timeout: 25_000 });
    await start.click();
    await page.getByRole("button", { name: "주행 종료" }).waitFor({ state: "visible", timeout: 40_000 });
  });

  await step("wait-rider-asset", async () => {
    const deadline = Date.now() + 25_000;
    while (Date.now() < deadline && riderHits.length === 0) {
      await page.waitForTimeout(500);
    }
    const perf = await page.evaluate(() =>
      performance.getEntriesByType("resource").map((e) => e.name).filter((n) =>
        n.includes("/rider/preserved/candidates/") || n.includes("rider-lowpoly.glb"),
      ),
    );
    report.performanceRiderUrls = perf;
    report.riderHits = riderHits;
    report.lightLabVisible = (await page.locator(".light-lab").count()) > 0;
    if (report.lightLabVisible) {
      const toggle = page.locator(".light-lab").getByRole("button", { name: "조절판 펼치기" });
      if (await toggle.isVisible().catch(() => false)) await toggle.click();
    }
    const pacerDeadline = Date.now() + 20_000;
    let pacer = null;
    while (Date.now() < pacerDeadline) {
      pacer = await page.evaluate(() => {
        const fn = window.__rtwPacerDiag;
        return typeof fn === "function" ? fn() : null;
      });
      if (pacer && pacer.count >= 2 && pacer.visible) break;
      await page.waitForTimeout(500);
    }
    report.pacer = pacer;
    log("pacer", JSON.stringify(pacer));
    const cam2 = page.getByRole("button", { name: "카메라 2" });
    if (await cam2.isVisible().catch(() => false)) {
      await cam2.click();
      await page.waitForTimeout(800);
    }
    await shot("app-riding-lightlab.png");
    if (!riderHits.some((h) => h.url.includes("20261015-212136-df8de090"))) {
      throw new Error(`rider14 candidate URL not loaded: ${JSON.stringify(riderHits)}`);
    }
    if (!pacer || pacer.count < 2) {
      throw new Error(`pacer count < 2: ${JSON.stringify(pacer)}`);
    }
  });
} catch (error) {
  report.error = String(error && error.stack ? error.stack : error);
  log("FAIL", report.error.split("\n")[0]);
  try {
    await shot("app-failure.png");
  } catch {
    /* page may already be closed */
  }
} finally {
  report.riderHits = riderHits;
  report.finishedAt = new Date().toISOString();
  fs.writeFileSync(path.join(OUT, "capture-app.json"), JSON.stringify(report, null, 2));
  await browser.close();
}

if (report.error) process.exit(1);
