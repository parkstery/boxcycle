import { chromium } from "@playwright/test";
const b = await chromium.launch();
const out = [];
for (const z of [22, 19, 17, 15]) {
  const p = await b.newPage({ viewport: { width: 1280, height: 800 } });
  await p.goto(`http://localhost:5070/scripts/rider-preserve/rider-perf-bench.html?zoom=${z}&riders=3&animate=1`, { waitUntil: "load" });
  await p.waitForFunction(() => window.__rtwBench?.state().loadState === "ready", null, { timeout: 60000 });
  await p.waitForTimeout(3000);
  const m3 = await p.evaluate(() => window.__rtwBench.measure(60));
  await p.evaluate(() => window.__rtwBench.setRiders(0));
  const m0 = await p.evaluate(() => window.__rtwBench.measure(60));
  const panel = await p.textContent("#panel");
  out.push({ z, perRider: (m3.drawCallsPerFrame - m0.drawCallsPerFrame) / 3, triPerRider: Math.round((m3.trianglesPerFrame - m0.trianglesPerFrame) / 3), lod2: /lod2[^a-z]*ready/i.test(panel) });
  await p.close();
}
console.log(JSON.stringify(out));
await b.close();
