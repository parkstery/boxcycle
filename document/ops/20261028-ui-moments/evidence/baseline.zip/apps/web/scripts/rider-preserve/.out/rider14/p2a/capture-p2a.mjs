#!/usr/bin/env node
/** P2a one-off capture: s5 vs rider14 stills + per-rider drawcalls. Temp file, not committed. */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "@playwright/test";

const here = path.dirname(fileURLToPath(import.meta.url));
const BASE = process.env.RTW_BENCH_BASE ?? "http://localhost:5040";
const FRAMES = 60;

function urlFor(model) {
  const q = `zoom=22&pitch=67&bearing=-32&riders=3&animate=0${model ? `&riderModel=${model}` : ""}`;
  return `${BASE}/scripts/rider-preserve/rider-perf-bench.html?${q}`;
}

async function waitReady(page, timeoutMs = 120000) {
  await page.waitForFunction(() => Boolean(window.__rtwBench), null, { timeout: timeoutMs });
  await page.waitForFunction(() => window.__rtwBench.state().loadState === "ready", null, {
    timeout: timeoutMs,
  });
}

async function runModel(browser, model, outName) {
  const errors = [];
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.on("console", (msg) => {
    if (msg.type() === "error") errors.push(`console.error: ${msg.text()}`);
  });
  page.on("pageerror", (err) => errors.push(`pageerror: ${String(err?.message ?? err)}`));
  await page.goto(urlFor(model), { waitUntil: "load" });
  await waitReady(page);
  const state = await page.evaluate(() => window.__rtwBench.state());
  const m3 = await page.evaluate((f) => window.__rtwBench.measure(f), FRAMES);
  await page.evaluate(() => window.__rtwBench.setRiders(0));
  await page.waitForTimeout(800);
  const m0 = await page.evaluate((f) => window.__rtwBench.measure(f), FRAMES);
  await page.evaluate(() => window.__rtwBench.setRiders(1));
  await page.waitForTimeout(800);
  const m1 = await page.evaluate((f) => window.__rtwBench.measure(f), FRAMES);
  await page.evaluate(() => window.__rtwBench.setRiders(3));
  await page.waitForTimeout(1500);
  const shotPath = path.join(here, outName);
  await page.screenshot({ path: shotPath });
  await page.close();
  return {
    model: model ?? "s5(default)",
    loadState: state.loadState,
    riders3: m3,
    riders0: m0,
    riders1: m1,
    perRiderDrawFrom3: (m3.drawCallsPerFrame - m0.drawCallsPerFrame) / 3,
    perRiderDrawFrom1: m1.drawCallsPerFrame - m0.drawCallsPerFrame,
    perRiderTriFrom3: (m3.trianglesPerFrame - m0.trianglesPerFrame) / 3,
    perRiderTriFrom1: m1.trianglesPerFrame - m0.trianglesPerFrame,
    capture: shotPath,
    consoleErrors: errors,
  };
}

const attempts = [
  { gpuPath: "default", args: [] },
  { gpuPath: "swiftshader", args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader"] },
];
let result = null;
let lastError = null;
for (const attempt of attempts) {
  let browser = null;
  try {
    console.log(`launch: gpuPath=${attempt.gpuPath}`);
    browser = await chromium.launch({ headless: true, args: attempt.args });
    const s5 = await runModel(browser, null, "s5-z22.png");
    const r14 = await runModel(browser, "rider14", "rider14-z22.png");
    result = { meta: { gpuPath: attempt.gpuPath, base: BASE, at: new Date().toISOString() }, s5, r14 };
    break;
  } catch (error) {
    lastError = error;
    console.error(`attempt ${attempt.gpuPath} failed: ${error?.message ?? error}`);
    if (attempt.gpuPath === "swiftshader") throw error;
  } finally {
    await browser?.close();
  }
}
if (!result) throw lastError ?? new Error("capture failed");
fs.writeFileSync(path.join(here, "p2a-captures.json"), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
