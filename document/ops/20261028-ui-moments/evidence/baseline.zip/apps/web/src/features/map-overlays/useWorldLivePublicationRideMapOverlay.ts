/* eslint-disable react-hooks/refs, react-hooks/set-state-in-effect, react-hooks/purity */
import { startTransition, useEffect, useMemo, useRef, useState } from "react";
import type { ActivityWorldMapRoute } from "../../lib/activity/activityWorldLod";
import { ACTIVITY_TRACE_LIVE_STRENGTH } from "../../lib/activity/activityWorldTraceStyle";
import {
  isTrailLivePublicationRideRowFresh,
  isTrailLivePublicationRideRowPeerVisible,
  type TrailLivePublicationRideRow,
} from "../../lib/trail/repo/firestoreTrailLivePublicationRides";
import { acquireTrailLivePublicationRidesSubscription } from "../../lib/trail/repo/livePublicationRidesSubscriptionHub";
import { DEFAULT_TRAIL_ID, sanitizeTrailId } from "../../lib/trail/repo/firestoreTrail";
import type { LineStringGeometry, LngLat } from "../../lib/geo/geo";
import { spectatorPointOnRoute } from "../../lib/peerMotion/spectatorRideExtrap";
import type { TrailSpectatorDot } from "../../hooks/useTrailLivePublicationRideSpectatorOverlay";
import { decimateLineStringVertices, maxLineStringVerticesForMapZoom } from "../../lib/geo/geoDecimate";
import type { RouteActivityMapOverlay } from "../../hooks/useRouteActivityMapOverlay";
import { presenceRiderDisplayName } from "../../lib/identity/riderName";
import {
  loadMissingPublicationGeometries,
  type PublicationGeomState,
} from "../../hooks/loadPublicationGeometries";

type LivePublicationAggregate = {
  publicationId: string;
  progressRatio: number;
  riderCount: number;
};

function aggregateLivePublications(rows: readonly TrailLivePublicationRideRow[]): LivePublicationAggregate[] {
  const byPublication = new Map<string, { progressRatio: number; riderCount: number }>();
  for (const row of rows) {
    const publicationId = row.publicationId.trim();
    if (!publicationId) continue;
    const cur = byPublication.get(publicationId) ?? { progressRatio: 0, riderCount: 0 };
    cur.progressRatio = Math.max(cur.progressRatio, row.progressRatio);
    cur.riderCount += 1;
    byPublication.set(publicationId, cur);
  }
  return [...byPublication.entries()].map(([publicationId, v]) => ({
    publicationId,
    progressRatio: v.progressRatio,
    riderCount: v.riderCount,
  }));
}

function mergeLiveRows(maps: Map<string, TrailLivePublicationRideRow>[]): TrailLivePublicationRideRow[] {
  const merged = new Map<string, TrailLivePublicationRideRow>();
  for (const m of maps) {
    for (const [uid, row] of m) {
      const prev = merged.get(uid);
      if (!prev || (row.receivedAtLocalMs ?? 0) >= (prev.receivedAtLocalMs ?? 0)) {
        merged.set(uid, row);
      }
    }
  }
  return [...merged.values()];
}

const EMPTY_LIVE_OVERLAY: RouteActivityMapOverlay = {
  pulseRoutes: [],
  heatRoutes: [],
  pulseDots: [],
  heatDots: [],
};

/**
 * `livePublicationRides` → Activity World **pulse line only** (per-user dot 은 global livePresence).
 * catalog·publication 에 라인이 없을 때 route geometry gap-fill.
 */
export function useWorldLivePublicationRideMapOverlay(opts: {
  enabled: boolean;
  mapZoom: number;
  myUid: string | null;
  excludePublicationId: string | null;
  /** 현재 Trail + openTrailListings */
  trailIds: readonly string[];
}): RouteActivityMapOverlay & {
  livePublicationCount: number;
  liveRideRowCount: number;
  trailheadSpectatorDots: TrailSpectatorDot[];
  trailheadSpectatorRoutes: LineStringGeometry[];
} {
  const { enabled, mapZoom, myUid, excludePublicationId, trailIds } = opts;
  const [rows, setRows] = useState<TrailLivePublicationRideRow[]>([]);
  const [geomEpoch, setGeomEpoch] = useState(0);
  const [spectatorTickMs, setSpectatorTickMs] = useState(() => Date.now());
  const geomByPublicationRef = useRef<Map<string, PublicationGeomState>>(new Map());

  const trailIdsKey = useMemo(() => {
    const ids = new Set<string>();
    for (const raw of trailIds) {
      const tid = sanitizeTrailId(raw);
      if (tid && tid !== DEFAULT_TRAIL_ID) ids.add(tid);
    }
    return [...ids].sort().join(",");
  }, [trailIds]);

  useEffect(() => {
    if (!enabled || !trailIdsKey) {
      startTransition(() => setRows([]));
      geomByPublicationRef.current.clear();
      setGeomEpoch((n) => n + 1);
      return;
    }

    const trailIdList = trailIdsKey.split(",").filter(Boolean);
    const rowMaps = trailIdList.map(() => new Map<string, TrailLivePublicationRideRow>());
    const emit = () => {
      startTransition(() => setRows(mergeLiveRows(rowMaps)));
    };

    const releases = trailIdList.map((tid, index) =>
      acquireTrailLivePublicationRidesSubscription(
        tid,
        (next) => {
          const map = rowMaps[index]!;
          map.clear();
          for (const row of next) {
            if (!isTrailLivePublicationRideRowFresh(row)) continue;
            map.set(row.uid, row);
          }
          emit();
        },
        (err) => {
          if (import.meta.env.DEV) {
            console.warn("[WorldLivePublicationRide] subscribe failed", tid, err.message);
          }
        },
      ),
    );

    return () => {
      for (const release of releases) release();
    };
  }, [enabled, trailIdsKey]);

  const aggregates = useMemo(() => {
    const exclude = excludePublicationId?.trim() ?? "";
    const filtered = rows.filter((r) => {
      if (exclude && r.publicationId.trim() === exclude) return false;
      if (myUid && r.uid === myUid) return false;
      return true;
    });
    return aggregateLivePublications(filtered);
  }, [rows, excludePublicationId, myUid]);

  useEffect(() => {
    if (!enabled) return;
    if (aggregates.length === 0) {
      geomByPublicationRef.current.clear();
      setGeomEpoch((n) => n + 1);
      return;
    }

    const publicationIds = aggregates.map((a) => a.publicationId);
    loadMissingPublicationGeometries({
      publicationIds,
      geomByPublication: geomByPublicationRef.current,
      bumpGeomEpoch: () => setGeomEpoch((n) => n + 1),
      onGeometryMissing: (pid) => {
        if (import.meta.env.DEV) {
          console.warn("[WorldLivePublicationRide] geometry missing", pid);
        }
      },
    });
  }, [enabled, aggregates]);

  const trailheadActiveRowsKey = useMemo(() => {
    const exclude = excludePublicationId?.trim() ?? "";
    return rows
      .filter((r) => {
        if (!isTrailLivePublicationRideRowFresh(r)) return false;
        if (exclude && r.publicationId.trim() === exclude) return false;
        if (myUid && r.uid === myUid) return false;
        return true;
      })
      .map((r) => r.uid)
      .sort()
      .join("|");
  }, [rows, excludePublicationId, myUid]);

  useEffect(() => {
    if (!enabled || trailheadActiveRowsKey.length === 0) return;
    const id = window.setInterval(() => setSpectatorTickMs(Date.now()), 1_000);
    return () => window.clearInterval(id);
  }, [enabled, trailheadActiveRowsKey]);

  const overlay = useMemo((): RouteActivityMapOverlay => {
    if (aggregates.length === 0) return EMPTY_LIVE_OVERLAY;

    const pulseRoutes: ActivityWorldMapRoute[] = [];
    const geomMap = geomByPublicationRef.current;

    for (const agg of aggregates) {
      const g = geomMap.get(agg.publicationId);
      if (!g || g.status !== "ready") continue;

      pulseRoutes.push({
        publicationId: agg.publicationId,
        geometry: decimateLineStringVertices(g.geometry, maxLineStringVerticesForMapZoom(mapZoom)),
        kind: "pulse",
        traceStrength: ACTIVITY_TRACE_LIVE_STRENGTH,
      });
    }

    return {
      pulseRoutes,
      heatRoutes: [],
      pulseDots: [],
      heatDots: [],
    };
  }, [aggregates, mapZoom, geomEpoch]);

  const trailheadSpectator = useMemo(() => {
    const exclude = excludePublicationId?.trim() ?? "";
    const activeRows = rows.filter((r) => {
      /*
       * 맵 점은 **15초** 기준으로 지운다 — 240초(`...RowFresh`)가 아니다.
       *
       * 2026-09-27 실측: 103초 전에 발행이 끊긴 주행이 그대로 그려지고 있었다.
       * 관전 외삽은 3초에서 멈추므로(`SPECTATOR_MAX_EXTRAP_MS`) 그 점은 한자리에
       * 얼어붙어 있다가, 다음 행이 오는 순간 그만큼 **순간이동**한다 — 「툭툭 튀는」 증상.
       * 240초는 멤버 목록·인원수용 기준이고, 맵 표시 기준은 `PEER_LIVE_RIDE_STALE_MS`(15초)다.
       */
      if (!isTrailLivePublicationRideRowPeerVisible(r, spectatorTickMs)) return false;
      if (exclude && r.publicationId.trim() === exclude) return false;
      if (myUid && r.uid === myUid) return false;
      return true;
    });
    if (activeRows.length === 0) {
      return { trailheadSpectatorDots: [] as TrailSpectatorDot[], trailheadSpectatorRoutes: [] as LineStringGeometry[] };
    }

    const geomMap = geomByPublicationRef.current;
    const maxV = maxLineStringVerticesForMapZoom(mapZoom);
    const seenPublications = new Set<string>();
    const trailheadSpectatorRoutes: LineStringGeometry[] = [];
    const trailheadSpectatorDots: TrailSpectatorDot[] = [];

    for (const r of activeRows) {
      const g = geomMap.get(r.publicationId);
      if (!g || g.status !== "ready") continue;
      if (!seenPublications.has(r.publicationId)) {
        seenPublications.add(r.publicationId);
        trailheadSpectatorRoutes.push(decimateLineStringVertices(g.geometry, maxV));
      }
      const p = spectatorPointOnRoute(r, g.geometry, spectatorTickMs, { logPt10: true });
      if (p) {
        const who = presenceRiderDisplayName(r.uid, null, r.displayName);
        trailheadSpectatorDots.push({
          id: r.uid,
          lngLat: p as LngLat,
          label: who,
        });
      }
    }

    return { trailheadSpectatorDots, trailheadSpectatorRoutes };
  }, [rows, excludePublicationId, myUid, mapZoom, geomEpoch, spectatorTickMs]);

  return {
    ...overlay,
    livePublicationCount: aggregates.length,
    liveRideRowCount: rows.length,
    trailheadSpectatorDots: trailheadSpectator.trailheadSpectatorDots,
    trailheadSpectatorRoutes: trailheadSpectator.trailheadSpectatorRoutes,
  };
}
