import { useState, useEffect, useRef } from "react";
import { validateSavedRouteName } from "../../lib/route/repo/firestoreSavedRoutes";
import { isIncompleteQuotaError } from "../../lib/account/tierQuota";
import { progressPercentLabel, type RideEndResult } from "../../lib/ride/rideEndResult";
import { useRideConquestResult } from "../../hooks/useRideConquestResult";
import type { RideConquestResult } from "../../lib/ride/rideConquestResult";
import { getRideSaveStatusLabel, getSavedRouteProgressStatusLabel } from "../../lib/ride/rideStatusCopy";
import { formatNewRoadHero, formatConquestStatusCopy } from "../../lib/ride/rideSessionPreview";
import { formatCaloriesEstimateLabel } from "../../lib/ride/caloriesEstimate";
import type { RideStory } from "../../lib/ride/rideStory";
import type { RideRankChangeLine } from "../leaderboard/leaderboardLiveRank";
import { formatElapsedFromMs } from "../../lib/ride/rideFormat";
import { useDialogFocus } from "../ui/useDialogFocus";
import "./RideSummarySheet.css";

type RideSummarySheetProps = {
  open: boolean;
  arrivalCompleted: boolean;
  elapsedLabel: string;
  avgKmh: string;
  /** null = 미산정. result.caloriesEstimate 가 있으면 그쪽 우선 */
  caloriesEstimate: number | null;
  /**
   * 주행 스토리(2026-10-07 Chief) — 숫자보다 먼저 사람에게 건네는 한 줄 + 사실 한 줄.
   * null 이면 줄을 그리지 않는다.
   */
  story?: RideStory | null;
  /** 미산정 시 체중·체력 설정 진입 */
  onOpenCalorieSettings?: () => void;
  /**
   * 체중·체력이 이미 저장돼 있으면 미산정(센서 없음 등)이어도 설정 버튼을 띄우지 않는다 —
   * 주행마다 다시 묻지 않기(2026-10-08 Chief).
   */
  calorieProfileComplete?: boolean;
  /**
   * 게스트일 때만 — Google 연결(등록) 권유(2026-10-09 Chief: 게스트는 짧고 강한 경험 뒤 등록으로).
   * 주행 직후가 가장 강한 순간이다. 연결은 같은 uid 를 유지하므로 이번 주행·내 도로망이 그대로 남는다.
   */
  onGuestLinkGoogle?: () => void;
  /**
   * 종료 결과(§3.5) — 모든 유효 Ride 가 채운다. 미완주면 이전→신규 진행률을 보여 준다.
   * null 이면 진행률 배지만 생략.
   */
  result?: RideEndResult | null;
  /** F3: 현재 로그인 사용자 uid (conquest result ownership 체크) */
  userId?: string | null;
  /** 최근 신규 도로 임시 강조를 서버 판정과 연결한다. */
  onConquestResult?: (recordId: string, result: RideConquestResult) => void;
  /** conquestResult 구독이 60초 timeout 된 경우 최근 강조를 제거한다. */
  onConquestTimeout?: (recordId: string) => void;
  /** ad-hoc(저장 안 한 채) 주행이 직전에 종료되어 「사용자 경로로 저장」 액션이 가능한 상태인지 */
  adhocSaveAvailable: boolean;
  /** 미완주 SavedRoute — 전체 진행률 변화(이전→이번) */
  savedRouteProgress?: {
    fromPct: number;
    toPct: number;
    routeName: string | null;
  } | null;
  /** 저장 길이 제한 */
  maxNameLength: number;
  /** 자동 제안 이름(출발→도착·거리) — 입력란 초기값으로 미리 채운다. 지명 비동기 도착 시 갱신될 수 있음 */
  suggestedName?: string;
  onSaveAdhoc: (name: string, confirmUpdate?: boolean) => Promise<void> | void;
  onDismissAdhoc: () => void;
  onClose: () => void;
  /** 미완료 쿼터 초과로 저장이 막혔을 때 상위에 알림(→ 시트 닫고 「내 경로」 대기 탭 유도) */
  onIncompleteQuotaBlocked?: (message: string) => void;
  /** 이번 주 순위 변화 한 줄 — 탭하면 큰 리더보드 */
  rankChange?: RideRankChangeLine | null;
  onOpenLeaderboard?: () => void;
  /**
   * RIDE-CLAIM-RESULT-1: 이미 로드된 내 도로망 geometries.
   * 세션 bounds 클리핑은 preview lib 에서 수행. 새 조회 없음.
   */
};

/**
 * 주행 종료 후 하단 시트.
 * - 도착 여부·ad-hoc 여부로 노출을 제한하지 않는다 — 폐기되지 않은 **모든 유효 Ride** 가 연다(§3.5).
 * - 컴팩트 4행 구성: 헤더 → 2열 히어로(새 도로 + 오늘, 완주/진행률 배지) → 보조 수치(+저장 상태) → 저장 폼.
 *   스크롤 없이 가로 폰 화면 한 장에 들어가야 한다.
 */
/**
 * 진행 블록 거리 — 자릿수는 **경로 전체 거리**가 정하고 블록 안 숫자가 모두 따른다
 * (「2.0km 중 0.18km」처럼 섞이지 않게). 1km 미만 경로는 소수 둘째 자리 — 짧은 경로가
 * 「0.2km 중 0.2km」로 뭉개지지 않게.
 */
function sheetKmDigits(totalKm: number): number {
  return totalKm < 1 ? 2 : totalKm < 100 ? 1 : 0;
}

function formatSheetKm(km: number, digits: number): string {
  return `${Math.max(0, km).toFixed(digits)}km`;
}

export function RideSummarySheet(props: RideSummarySheetProps) {
  const suggested = props.suggestedName ?? "";
  const [name, setName] = useState(suggested);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  /** 같은 경로가 이미 있어 "업데이트하시겠습니까?" 확인을 기다리는 중. */
  const [confirmingUpdate, setConfirmingUpdate] = useState(false);

  // RIDE-CLAIM-RESULT-1: UI-level delay/timeout tracking (15s delayed, 60s timed-out)
  const [isDelayed, setIsDelayed] = useState(false);
  const [isTimedOut, setIsTimedOut] = useState(false);
  const delayTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const timeoutTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // F3: rides/{serverRideId}.conquestResult 구독
  const result = props.result ?? null;
  const resultRecordId = result?.recordId;
  const onConquestResult = props.onConquestResult;
  const onConquestTimeout = props.onConquestTimeout;
  const conquestResult = useRideConquestResult({
    serverRideId: result?.serverRideId,
    userId: props.userId,
    localRecordId: result?.recordId ?? "",
  });
  const latestConquestResultRef = useRef(conquestResult);
  useEffect(() => {
    latestConquestResultRef.current = conquestResult;
  }, [conquestResult]);

  useEffect(() => {
    if (!resultRecordId) return;
    onConquestResult?.(resultRecordId, conquestResult);
  }, [conquestResult, onConquestResult, resultRecordId]);

  // UI delay 타이머 — serverRideId 가 바뀔 때만 재시작한다.
  // positive/confirmed_zero 에서는 formatConquestStatusCopy 가 null 을 반환하므로
  // isDelayed/isTimedOut 값이 있어도 UI 에 노출되지 않는다.
  const serverRideId = result?.serverRideId;

  useEffect(() => {
    if (!serverRideId) return;

    // 15초 → delayed (타이머 콜백에서 setState — 비동기, 허용됨)
    const t15 = setTimeout(() => setIsDelayed(true), 15000);
    // 60초 → timed out
    const t60 = setTimeout(() => {
      setIsTimedOut(true);
      const latest = latestConquestResultRef.current.status;
      // 서버 확정 결과는 timeout이 덮어쓰지 않는다. 아직 미확정인 경우에만
      // 낙관적으로 그린 최근 도로를 정리한다.
      if (
        resultRecordId &&
        latest !== "positive" &&
        latest !== "confirmed_zero"
      ) {
        onConquestTimeout?.(resultRecordId);
      }
    }, 60000);
    delayTimerRef.current = t15;
    timeoutTimerRef.current = t60;
    return () => {
      clearTimeout(t15);
      clearTimeout(t60);
      // cleanup 에서의 setState 는 허용됨 — serverRideId 변경 시 상태 초기화
      setIsDelayed(false);
      setIsTimedOut(false);
    };
  }, [onConquestTimeout, resultRecordId, serverRideId]);

  // R2: F4 persistence status (independent axes)
  const rideSaveStatus = result?.rideSaveStatus ?? "n/a";
  const savedRouteProgressStatus = result?.savedRouteProgressStatus ?? "n/a";

  // 제안 이름이 갱신되면(지명 비동기 도착 등), 사용자가 아직 손대지 않은 경우에만 따라간다.
  const [prevSuggested, setPrevSuggested] = useState(suggested);
  if (suggested !== prevSuggested) {
    setPrevSuggested(suggested);
    if (name === prevSuggested) setName(suggested);
  }

  const onClose = props.onClose;
  const sheetRef = useRef<HTMLDivElement>(null);
  useDialogFocus(props.open, sheetRef);
  useEffect(() => {
    if (!props.open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key !== "Escape" || busy) return;
      onClose();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [busy, onClose, props.open]);

  if (!props.open) return null;

  /*
   * 시간·평속은 **주행이 끝난 순간에 고정된 결과**에서 읽는다. props 의 두 값은 실시간 주행
   * 계기(rideMetrics)라 종료 직후 계기가 초기화되면 「00:00 · 0.0 km/h」로 바뀌었다
   * (2026-10-07 Chief 스크린샷). 결과가 없을 때만 props 로 내려간다.
   */
  const elapsedLabel =
    result && Number.isFinite(result.elapsedSec)
      ? formatElapsedFromMs(result.elapsedSec * 1000)
      : props.elapsedLabel;
  const avgKmhLabel =
    result && Number.isFinite(result.avgSpeedKmh) ? result.avgSpeedKmh.toFixed(1) : props.avgKmh;

  const routeCompleted = Boolean(result?.routeCompleted);
  /** 미완주 저장 경로 주행 — 이전→신규 진행률을 보여 줄 수 있는 경우 */
  const showProgressLine = Boolean(result && result.savedRouteId && !routeCompleted);

  // RIDE-CLAIM-RESULT-1: 새 도로 conquest 표시 로직
  const newRoadHero = formatNewRoadHero(conquestResult.newMeters, conquestResult.status);
  const conquestStatusCopy = formatConquestStatusCopy(
    conquestResult.status,
    isDelayed,
    isTimedOut,
  );

  // 저장 중(serverRideId 없음)이면 conquest hero 블록을 표시하지 않음
  const showConquestBlock = Boolean(result);
  /*
   * 내용이 실제로 있을 때만 새 도로 칸을 연다. `confirmed_zero`(새 도로 0m 확정)에서는
   * hero 도 statusCopy 도 null 이라, 설명문을 걷어낸 뒤로는 **테두리만 남은 빈 박스**가 됐다.
   * 「0 은 노출하지 않는다」는 기존 결정(50m 미만 미표시)을 뒤집지 않으려면 숫자를 채울 게
   * 아니라 칸 자체를 접는 것이 맞다 — 그러면 「오늘」이 1열로 자리를 넓혀 쓴다.
   */
  const hasConquestContent = showConquestBlock && Boolean(newRoadHero || conquestStatusCopy);
  /*
   * 「이번 주행」 세 값 — 주행거리 / 총거리 / 새 도로(2026-09-17 Chief).
   * 「오늘」(하루 누적)은 이 화면이 답할 질문이 아니다. 단위 km 는 헤더가 한 번만 말하고
   * 숫자에는 붙이지 않는다.
   *
   * 주행거리는 **경로상 누적 위치**다(세션 거리가 아니다, Chief 확정). 이어달리기로 경로
   * 중간부터 재개해 끝낸 경우에도 「완주 = 0.50 / 0.50」 이 성립해야 하고, 주행 중 상단
   * 계기판이 보여 주던 「누적 / 전체」와 같은 숫자여야 화면이 이어지기 때문이다.
   */
  const routeTotalKmNum = result ? result.routeDistanceMeters / 1000 : null;
  /*
   * 완주면 분자를 전체거리로 맞춘다. 완주 인정 기준은 100% 가 아니라 **98%**
   * (`ROUTE_COMPLETION_RATIO_THRESHOLD`)라, 그대로 두면 완주해도 「0.99 / 1.00」 처럼
   * 보인다. 「완주」 배지를 뺀 근거가 「숫자를 보고 완주를 확인한다」(Chief)인데
   * 0.99/1.00 으로는 완주인지 알 수 없어 그 근거가 무너진다.
   */
  const riddenKmNum =
    result && Number.isFinite(result.progressRatio)
      ? result.routeCompleted
        ? result.routeDistanceMeters / 1000
        : (result.routeDistanceMeters * Math.max(0, Math.min(1, result.progressRatio))) / 1000
      : null;
  const distancePair =
    routeTotalKmNum != null && riddenKmNum != null && routeTotalKmNum > 0
      ? `${riddenKmNum.toFixed(2)} / ${routeTotalKmNum.toFixed(2)}`
      : null;
  const kmDigits = sheetKmDigits(routeTotalKmNum ?? 0);
  // 진행 막대 — 지난번까지(이전 진행률) + 이번 주행분. 완주면 꽉 채운다
  const progressNowPct = routeCompleted
    ? 100
    : Math.round(Math.max(0, Math.min(1, result?.progressRatio ?? 0)) * 1000) / 10;
  const progressBeforePct = Math.min(
    progressNowPct,
    Math.round(Math.max(0, Math.min(1, result?.previousProgressRatio ?? 0)) * 1000) / 10,
  );
  const progressThisPct = Math.max(0, progressNowPct - progressBeforePct);
  function requestClose() {
    if (busy) return;
    props.onClose();
  }

  async function commitSave(confirmUpdate = false) {
    if (busy) return;
    let normalized: string;
    try {
      normalized = validateSavedRouteName(name);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await props.onSaveAdhoc(normalized, confirmUpdate);
      setName("");
      setConfirmingUpdate(false);
    } catch (e) {
      if (isIncompleteQuotaError(e)) {
        setName("");
        setConfirmingUpdate(false);
        setError(null);
        props.onIncompleteQuotaBlocked?.(e.message);
      } else if (
        e && typeof e === "object" && (e as { code?: string }).code === "saved-route-duplicate"
      ) {
        setConfirmingUpdate(true);
      } else {
        setError(e instanceof Error ? e.message : String(e));
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="ride-summary" role="region" aria-label="주행 결과">
      <button
        type="button"
        className="ride-summary__scrim"
        aria-label="닫기"
        title="Close"
        onClick={requestClose}
      />
      <div
        ref={sheetRef}
        className="ride-summary__sheet"
        role="dialog"
        aria-labelledby="ride-summary-title"
      >
        <div className="ride-summary__handle" aria-hidden />
        <div className="ride-summary__cols">
          <div className="ride-summary__col ride-summary__col--primary">
            {/*
              스토리 — 숫자를 사람의 말로(2026-10-07 Chief). 문장은 lib/ride/rideStory.ts 가
              기록의 사실로만 만든다. 가로 800 판에서는 왼쪽 요약 열의 맨 위.
            */}
            {props.story ? (
              <div className="ride-summary__story" aria-live="polite">
                <p className="ride-summary__story-headline">{props.story.headline}</p>
                {props.story.detail ? (
                  <p className="ride-summary__story-detail">{props.story.detail}</p>
                ) : null}
              </div>
            ) : null}

            {/* §3.1 히어로 — 새 도로 + 진행. 가로 판에서는 왼쪽 열에 세로로 쌓는다 */}
            <div className="ride-summary__heroes">
          <div
            className={
              hasConquestContent && distancePair
                ? "ride-summary__heroes-main"
                : "ride-summary__heroes-main ride-summary__heroes-main--solo"
            }
          >
            {hasConquestContent ? (
              <div className="ride-summary__conquest-hero" aria-live="polite">
                {newRoadHero ? (
                  <>
                    <div className="ride-summary__conquest-label">새 도로</div>
                    <strong className="ride-summary__conquest-value" aria-label="새 도로">
                      +{newRoadHero}
                      <span className="ride-summary__conquest-km" aria-hidden="true"> km</span>
                    </strong>
                  </>
                ) : conquestStatusCopy ? (
                  <p className="ride-summary__conquest-status">
                    {conquestStatusCopy}
                    {isTimedOut ? (
                      <>
                        {" "}
                        <button
                          type="button"
                          className="ride-summary__conquest-retry"
                          onClick={() => {
                            setIsDelayed(false);
                            setIsTimedOut(false);
                          }}
                        >
                          다시 확인
                        </button>
                      </>
                    ) : null}
                  </p>
                ) : null}
              </div>
            ) : null}

            {/*
              진행 블록(2026-10-08 Chief) — 큰 숫자 「0.17 / 2.02」를 걷어내고 「2.0km 중 0.2km」를
              주인공으로. 막대는 지난번까지 온 길(흐린 흰색) + **이번에 달린 구간(골드)** + 남은 길.
              숫자 계약은 화면 문구가 아니라 data-* 로 남긴다(e2e 가 문구에 묶이지 않게).
            */}
            {distancePair && routeTotalKmNum != null && riddenKmNum != null ? (
              <div
                className={`ride-summary__progress${routeCompleted ? " ride-summary__progress--done" : ""}`}
                aria-label="주행 거리 / 경로 전체거리"
                data-ridden-km={riddenKmNum.toFixed(2)}
                data-total-km={routeTotalKmNum.toFixed(2)}
              >
                <div className="ride-summary__progress-text">
                  {routeCompleted ? (
                    <span className="ride-summary__progress-main">
                      <strong className="ride-summary__progress-v">{formatSheetKm(routeTotalKmNum, kmDigits)}</strong>
                      <span className="ride-summary__progress-of">완주</span>
                    </span>
                  ) : (
                    <span className="ride-summary__progress-main">
                      <span className="ride-summary__progress-of">{formatSheetKm(routeTotalKmNum, kmDigits)} 중</span>
                      <strong className="ride-summary__progress-v">{formatSheetKm(riddenKmNum, kmDigits)}</strong>
                    </span>
                  )}
                </div>
                {/* 남은 거리는 막대 끝에 작게 — 해낸 거리가 먼저다(N2) */}
                <div className="ride-summary__progress-track">
                  <div className="ride-summary__progress-bar" aria-hidden>
                    <span
                      className="ride-summary__progress-before"
                      style={{ width: `${progressBeforePct}%` }}
                    />
                    <span
                      className="ride-summary__progress-this"
                      style={{ width: `${progressThisPct}%` }}
                    />
                  </div>
                  {routeCompleted ? null : (
                    <span className="ride-summary__progress-left">
                      남은 {formatSheetKm(Math.max(0, routeTotalKmNum - riddenKmNum), kmDigits)}
                    </span>
                  )}
                </div>
              </div>
            ) : null}
          </div>
            </div>
          </div>

          <div className="ride-summary__col ride-summary__col--detail">
            <div
              className={[
                "ride-summary__head",
                props.adhocSaveAvailable ? "" : "ride-summary__head--with-close",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              <div className="ride-summary__head-left">
                <h2 id="ride-summary-title" className="ride-summary__title">
                  주행 결과
                  <span className="ride-summary__title-unit">km</span>
                </h2>
                {!routeCompleted && showProgressLine && result ? (
                  <span className="ride-summary__heroes-badge" aria-label="전체 진행">
                    {progressPercentLabel(result.previousProgressRatio)}% →{" "}
                    {progressPercentLabel(result.progressRatio)}%
                  </span>
                ) : null}
              </div>
              {props.adhocSaveAvailable ? null : (
                <button
                  type="button"
                  className="ride-summary__close"
                  title="닫기"
                  aria-label="닫기"
                  onClick={requestClose}
                >
                  <span aria-hidden="true">✕</span>
                </button>
              )}
            </div>

        {props.rankChange && props.onOpenLeaderboard ? (
          <button
            type="button"
            className="ride-summary__rank-line"
            onClick={props.onOpenLeaderboard}
          >
            {props.rankChange.kind === "guest-projected" ? (
              <>
                회원이라면 이번 주 예상{" "}
                <strong className="ride-summary__rank-num">{props.rankChange.projectedRank}</strong>위
              </>
            ) : props.rankChange.kind === "member-change" ? (
              <>
                이번 주 순위{" "}
                <span className="ride-summary__rank-muted">{props.rankChange.beforeRank}</span>위 →{" "}
                <strong className="ride-summary__rank-num">{props.rankChange.afterRank}</strong>위
                <span className="ride-summary__rank-up">▲{props.rankChange.delta}</span>
                {props.rankChange.gapToFirstKm != null ? (
                  <span className="ride-summary__rank-gap">
                    1위까지{" "}
                    <strong className="ride-summary__rank-num-sm">
                      {props.rankChange.gapToFirstKm.toFixed(1)} km
                    </strong>
                  </span>
                ) : null}
              </>
            ) : (
              <>
                이번 주 <strong className="ride-summary__rank-num">{props.rankChange.rank}</strong>위
                그대로
                {props.rankChange.gapToFirstKm != null ? (
                  <span className="ride-summary__rank-gap">
                    1위까지{" "}
                    <strong className="ride-summary__rank-num-sm">
                      {props.rankChange.gapToFirstKm.toFixed(1)} km
                    </strong>
                  </span>
                ) : null}
              </>
            )}
          </button>
        ) : null}

        <div className="ride-summary__substats">
          <span className="ride-summary__substat">
            <span className="ride-summary__substat-label">시간</span>
            <span className="ride-summary__substat-metric">{elapsedLabel}</span>
          </span>
          <span className="ride-summary__substat">
            <span className="ride-summary__substat-label">평균</span>
            <span className="ride-summary__substat-metric">{avgKmhLabel}&nbsp;km/h</span>
          </span>
          {(() => {
            const kcal =
              result?.caloriesEstimate !== undefined
                ? result.caloriesEstimate
                : props.caloriesEstimate;
            const label = formatCaloriesEstimateLabel(kcal);
            const signalGap = Boolean(result?.caloriesMeta?.signalGap);
            if (kcal == null) {
              return (
                <span
                  className="ride-summary__substat ride-summary__substat--calorie"
                  title={props.calorieProfileComplete ? "케이던스 센서가 연결된 주행만 산정합니다" : undefined}
                >
                  <span className="ride-summary__substat-label">칼로리</span>
                  <span className="ride-summary__substat-metric">
                    {props.calorieProfileComplete ? "센서 주행 후 표시" : "체중·체력 입력 후 표시"}
                  </span>
                  {props.onOpenCalorieSettings && !props.calorieProfileComplete ? (
                    <button
                      type="button"
                      className="ride-summary__calorie-setup"
                      onClick={props.onOpenCalorieSettings}
                    >
                      체중·체력 설정
                    </button>
                  ) : null}
                </span>
              );
            }
            return (
              <span
                className="ride-summary__substat"
                title={
                  signalGap
                    ? "추정 총 운동 에너지 · 센서 끊김 구간 미산정"
                    : "추정 총 운동 에너지"
                }
              >
                <span className="ride-summary__substat-label">칼로리</span>
                <span className="ride-summary__substat-metric">
                  추정 {label} kcal{signalGap ? " · 누락" : ""}
                </span>
              </span>
            );
          })()}
          {/* R2: F4 persistence status (independent axes) — 독립 줄 대신 보조 수치 줄에 합류 */}
          {rideSaveStatus !== "n/a" || savedRouteProgressStatus !== "n/a" ? (
            <span className="ride-summary__substat ride-summary__status" aria-live="polite">
              {getRideSaveStatusLabel(rideSaveStatus) != null ? (
                <span
                  className={`ride-summary__status-item ride-summary__status-item--${rideSaveStatus}`}
                >
                  {getRideSaveStatusLabel(rideSaveStatus)}
                </span>
              ) : null}
              {getSavedRouteProgressStatusLabel(savedRouteProgressStatus) != null ? (
                <span
                  className={`ride-summary__status-item ride-summary__status-item--${savedRouteProgressStatus}`}
                >
                  {getSavedRouteProgressStatusLabel(savedRouteProgressStatus)}
                </span>
              ) : null}
            </span>
          ) : null}
        </div>

        {props.onGuestLinkGoogle ? (
          <div className="ride-summary__guest-cta" role="group" aria-label="기록 지키기">
            <span className="ride-summary__guest-cta-copy">
              회원 등록하면 이번 주행과 내 도로망이 그대로 이어지고, 다른 기기에서도 볼 수 있어요.
            </span>
            <button
              type="button"
              className="ride-summary__btn ride-summary__btn--primary ride-summary__guest-cta-btn"
              onClick={props.onGuestLinkGoogle}
            >
              Google 연결
            </button>
          </div>
        ) : null}

        {props.adhocSaveAvailable ? (
          <>
            {/*
              ad-hoc 저장은 보조 액션이다 — 저장하지 않아도 Ride 기록과 다음 출발점은 남는다.
              입력창 + 버튼 2개를 한 행으로 — 690px 가로 기준 한 줄, 좁으면 flex-wrap 으로 대응.
            */}
            <div className="ride-summary__form">
              <input
                type="text"
                className="ride-summary__input"
                placeholder={`경로 이름 (최대 ${props.maxNameLength}자)`}
                maxLength={props.maxNameLength}
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <div className="ride-summary__form-btns">
                <button
                  type="button"
                  className="ride-summary__btn ride-summary__btn--ghost"
                  title="Save to my routes"
                  onClick={() => void commitSave()}
                  disabled={busy}
                >
                  {busy ? "저장 중…" : "내 경로로 저장"}
                </button>
                {/*
                  2026-09-27 — 「저장 안 함」이 **시트를 닫는다.**
                  종전에는 저장 행만 사라지고 시트가 남아, 누른 사람이 「아무 일도 안 일어났다」고
                  느꼈다(자동 시험도 여기서 닫히기를 기다리다 죽었다). 「이 주행을 경로로 남기지
                  않는다」는 결정은 그 자체로 결말이므로, 닫는 것까지가 한 동작이다.
                  ⚠️ Ride 기록과 다음 출발점은 그대로 남는다 — 지워지는 것은 「내 경로로 저장」뿐이다.
                */}
                <button
                  type="button"
                  className="ride-summary__btn ride-summary__btn--ghost"
                  title="Skip saving and close"
                  onClick={() => {
                    props.onDismissAdhoc();
                    requestClose();
                  }}
                  disabled={busy}
                >
                  저장 안 함
                </button>
              </div>
            </div>
            {error ? <p className="ride-summary__err">{error}</p> : null}

            {confirmingUpdate ? (
              <div className="ride-summary__confirm" role="alertdialog" aria-live="assertive">
                <p className="ride-summary__confirm-msg">
                  저장된 경로 — 업데이트할까요?
                </p>
                <div className="ride-summary__form-btns">
                  <button
                    type="button"
                    className="ride-summary__btn ride-summary__btn--primary"
                    onClick={() => void commitSave(true)}
                    disabled={busy}
                  >
                    {busy ? "업데이트 중…" : "예 · 업데이트"}
                  </button>
                  <button
                    type="button"
                    className="ride-summary__btn ride-summary__btn--ghost"
                    onClick={() => setConfirmingUpdate(false)}
                    disabled={busy}
                  >
                    아니오 · 유지
                  </button>
                </div>
              </div>
            ) : null}
          </>
        ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
