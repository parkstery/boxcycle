import type { AuthExpiryKind } from "../../lib/identity/authRestore";
import { AuthGoogleMark } from "./AuthGateCard";
import { AuthExpiryNotice } from "./AuthExpiryNotice";
import "./GuestEntryCard.css";

type GuestEntryCardProps = {
  busy: boolean;
  error: string | null;
  /** 시작 화면 위 한 줄 안내(예: 탈퇴 완료) */
  notice?: string | null;
  expiryKind?: AuthExpiryKind | null;
  onStartGuest: () => void;
  onGoogleSignIn: () => void;
};

/**
 * 최초 진입 — 임시 라이더(익명 인증) 안내 후 세계 참가.
 * [tier 정책 §3.2](document/reference/product/260519-사용자-tier-및-진입-정책.md)
 */
export function GuestEntryCard({
  busy,
  error,
  notice = null,
  expiryKind = null,
  onStartGuest,
  onGoogleSignIn,
}: GuestEntryCardProps) {
  return (
    <div className="guest-entry" role="dialog" aria-modal="true" aria-label="시작">
      <div className="guest-entry__card">
        <div className="guest-entry__brand">
          <span className="guest-entry__brand-dot" aria-hidden />
          Spinatlas
        </div>
        {expiryKind ? <AuthExpiryNotice kind={expiryKind} /> : null}
        {!expiryKind && notice ? (
          <p className="guest-entry__notice" role="status">
            {notice}
          </p>
        ) : null}
        <h2 className="guest-entry__title">세계에 참가하기</h2>
        <p className="guest-entry__lead">지도에서 입문·퍼블릭 경로를 주행합니다.</p>
        <div className="guest-entry__actions">
          <button type="button" className="btn primary" disabled={busy} onClick={onStartGuest}>
            {busy ? "연결 중…" : "시작"}
          </button>
          <button
            type="button"
            className="btn secondary guest-entry__google"
            disabled={busy}
            title="Sign in with Google"
            onClick={onGoogleSignIn}
          >
            <AuthGoogleMark />
            Google로 시작
          </button>
        </div>
        {error ? <p className="error tight">{error}</p> : null}
      </div>
    </div>
  );
}
