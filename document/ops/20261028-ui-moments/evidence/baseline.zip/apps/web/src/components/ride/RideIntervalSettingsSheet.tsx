import { useId, useRef, useState } from "react";
import {
  getRideIntervalTotalMs, isRideIntervalConfig, RIDE_INTERVAL_PRESETS,
  type RideIntervalConfig,
} from "../../lib/ride/rideInterval";
import { useDialogFocus } from "../ui/useDialogFocus";
import { useEscapeKeyClose } from "../ui/useEscapeKeyClose";
import { SettingsCloseIcon } from "../ui/SettingsCloseIcon";
import "./RideIntervalSettingsSheet.css";

type Props = {
  open: boolean;
  config: RideIntervalConfig;
  restartOnApply: boolean;
  onApply: (config: RideIntervalConfig) => boolean;
  onClose: () => void;
};

const formatTime = (seconds: number) => `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
const sameConfig = (a: RideIntervalConfig, b: RideIntervalConfig) => a.highSec === b.highSec && a.lowSec === b.lowSec && a.repeats === b.repeats && (a.warmupSec ?? 300) === (b.warmupSec ?? 300) && (a.cooldownSec ?? 300) === (b.cooldownSec ?? 300);
const toDraft = (config: RideIntervalConfig) => ({ highSec: String(config.highSec), lowSec: String(config.lowSec), repeats: String(config.repeats), warmupSec: String(config.warmupSec ?? 300), cooldownSec: String(config.cooldownSec ?? 300) });

/** 별도 편집 초안: 적용 전에는 진행 중인 운동을 바꾸지 않는다. */
function IntervalEditor({ config, restartOnApply, onApply, onClose }: Omit<Props, "open">) {
  const titleId = useId();
  const [draft, setDraft] = useState(() => toDraft(config));
  const [mode, setMode] = useState(() => RIDE_INTERVAL_PRESETS.find(preset => sameConfig(preset.config, config))?.id ?? "custom");
  const highRef = useRef<HTMLInputElement>(null);
  const candidate = { highSec: Number(draft.highSec), lowSec: Number(draft.lowSec), repeats: Number(draft.repeats), warmupSec: Number(draft.warmupSec), cooldownSec: Number(draft.cooldownSec) };
  const valid = Object.values(draft).every(raw => raw.trim() !== "") && isRideIntervalConfig(candidate);
  const changed = valid && !sameConfig(candidate, config);
  const fields = [
    { key: "highSec", label: "고강도", unit: "초", min: 5, max: 600, change: 5 },
    { key: "lowSec", label: "저강도", unit: "초", min: 5, max: 600, change: 5 },
    { key: "repeats", label: "반복 수", unit: "회", min: 1, max: 30, change: 1 },
  ] as const;
  const setField = (key: keyof RideIntervalConfig, raw: string) => {
    setDraft(previous => ({ ...previous, [key]: raw }));
    setMode("custom");
  };
  const edgeFields = [{ key: "warmupSec", label: "준비" }, { key: "cooldownSec", label: "마무리" }] as const;
  const segments: { kind: string; seconds: number }[] = [];
  if (valid && candidate.warmupSec > 0) segments.push({ kind: "warmup", seconds: candidate.warmupSec });
  if (valid) for (let index = 0; index < candidate.repeats; index++) {
    segments.push({ kind: "high", seconds: candidate.highSec }, { kind: "low", seconds: candidate.lowSec });
  }
  if (valid && candidate.cooldownSec > 0) segments.push({ kind: "cooldown", seconds: candidate.cooldownSec });
  return <>
    <header className="ride-interval-settings__header">
      <h2 id={titleId}>인터벌 운동</h2>
      <select aria-label="운동 프리셋" value={mode} onChange={event => {
        const id = event.target.value;
        setMode(id);
        const preset = RIDE_INTERVAL_PRESETS.find(option => option.id === id);
        if (preset) setDraft(toDraft(preset.config));
        else highRef.current?.focus();
      }}>
        {RIDE_INTERVAL_PRESETS.map((preset, index) => <option key={preset.id} value={preset.id}>프리셋 {index + 1} · {preset.config.highSec}/{preset.config.lowSec}초 ×{preset.config.repeats}</option>)}
        <option value="custom">직접 설정</option>
      </select>
      <button type="button" className="ride-interval-settings__close" aria-label="인터벌 운동 설정 닫기" onClick={onClose}><SettingsCloseIcon /></button>
    </header>
    <div className="ride-interval-settings__body">
      <div className="ride-interval-settings__fields" role="group" aria-label="운동 시간과 반복 수">
        {fields.map(field => {
          const number = candidate[field.key];
          const fieldValid = draft[field.key].trim() !== "" && Number.isInteger(number) && number >= field.min && number <= field.max;
          return <div key={field.key} className={`ride-interval-settings__field ride-interval-settings__field--${field.key}`}>
            <label htmlFor={`${titleId}-${field.key}`}>{field.label}<small>{field.unit}</small></label>
            <div className="ride-interval-settings__stepper">
              <button type="button" aria-label={`${field.label} ${field.change}${field.unit} 줄이기`} onClick={() => setField(field.key, String(Math.max(field.min, Math.min(field.max, (fieldValid ? number : config[field.key]) - field.change))))}>−</button>
              <input id={`${titleId}-${field.key}`} ref={field.key === "highSec" ? highRef : undefined} type="number" inputMode="numeric" min={field.min} max={field.max} step={1} required value={draft[field.key]} aria-label={field.key === "repeats" ? "반복 수" : `${field.label} 시간 초`} aria-invalid={!fieldValid} onChange={event => setField(field.key, event.target.value)} />
              <button type="button" aria-label={`${field.label} ${field.change}${field.unit} 늘리기`} onClick={() => setField(field.key, String(Math.max(field.min, Math.min(field.max, (fieldValid ? number : config[field.key]) + field.change))))}>+</button>
            </div>
          </div>;
        })}
      </div>
      <aside className="ride-interval-settings__summary" aria-label="운동 구성 미리보기">
        <div className="ride-interval-settings__total"><span>총 운동 시간</span><strong aria-live="polite">{valid ? formatTime(getRideIntervalTotalMs(candidate) / 1000) : "—"}</strong></div>
        {edgeFields.map(field => {
          const fieldValid = draft[field.key].trim() !== "" && Number.isInteger(candidate[field.key]) && candidate[field.key] >= 0 && candidate[field.key] <= 1800;
          return <div className="ride-interval-settings__edge-time" key={field.key}>
            <label htmlFor={`${titleId}-${field.key}`}>{field.label}<small>{fieldValid ? formatTime(candidate[field.key]) : "초"}</small></label>
            <div className="ride-interval-settings__stepper">
              <button type="button" aria-label={`${field.label} 30초 줄이기`} onClick={() => setField(field.key, String(Math.max(0, (fieldValid ? candidate[field.key] : 300) - 30)))}>−</button>
              <input id={`${titleId}-${field.key}`} type="number" inputMode="numeric" min={0} max={1800} step={30} required value={draft[field.key]} aria-label={`${field.label} 시간 초`} aria-invalid={!fieldValid} onChange={event => setField(field.key, event.target.value)} />
              <button type="button" aria-label={`${field.label} 30초 늘리기`} onClick={() => setField(field.key, String(Math.min(1800, (fieldValid ? candidate[field.key] : 300) + 30)))}>+</button>
            </div>
          </div>;
        })}
        <div className="ride-interval-settings__timeline" role="img" aria-label={valid ? `준비 ${candidate.warmupSec}초, 고강도 ${candidate.highSec}초와 저강도 ${candidate.lowSec}초 ${candidate.repeats}회, 마무리 ${candidate.cooldownSec}초` : "입력 확인 필요"}>
          {segments.map((segment, index) => <span key={index} data-kind={segment.kind} style={{ flexGrow: segment.seconds }} />)}
        </div>
      </aside>
    </div>
    <footer className="ride-interval-settings__footer">
      <div>{valid ? <small>{restartOnApply && changed ? "적용하면 처음부터 다시 시작해요" : "준비·마무리 0초는 건너뜀"}</small> : <small role="alert">고·저 5~600초 · 준비·마무리 0~1800초 · 반복 1~30회</small>}</div>
      <button type="button" className="ride-interval-settings__apply" disabled={!valid} onClick={() => { if (valid && onApply(candidate)) onClose(); }}>설정 적용</button>
    </footer>
  </>;
}

export function RideIntervalSettingsSheet(props: Props) {
  const panelRef = useRef<HTMLDivElement>(null);
  useDialogFocus(props.open, panelRef);
  useEscapeKeyClose(props.open, props.onClose);
  if (!props.open) return null;
  return <div className="ride-interval-settings" role="dialog" aria-label="인터벌 운동 설정" aria-modal="true">
    <button type="button" className="ride-interval-settings__scrim" aria-label="인터벌 운동 설정 배경 닫기" onClick={props.onClose} />
    <div className="ride-interval-settings__panel" ref={panelRef}><IntervalEditor config={props.config} restartOnApply={props.restartOnApply} onApply={props.onApply} onClose={props.onClose} /></div>
  </div>;
}
