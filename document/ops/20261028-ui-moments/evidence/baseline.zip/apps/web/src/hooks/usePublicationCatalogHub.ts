/* eslint-disable react-hooks/set-state-in-effect -- config/auth gates clear catalog state */
import type { User } from "firebase/auth";
import type { Dispatch, MutableRefObject, SetStateAction } from "react";
import { startTransition, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { deletePublicationSessionMember } from "../lib/ride/repo/firestorePublicationSessionPresence";
import {
  BASIC_SHARED_HUB_IDS,
  fetchCourseRoutePayload,
  findPublishedPublicFingerprintsAmong,
  getBasicHubCoursePayload,
  listPublishedPublicCourses,
  matchBasicSharedHubCourseId,
  routeGeometryMatchesBasicSharedHub,
  type PublishedPublicCourseSummary,
} from "../lib/route/repo/firestoreCourses";
import type { LineStringGeometry, LngLat } from "../lib/geo/geo";
import { getUserPublicLabelsByUid } from "../lib/identity/repo/firestoreUser";
import {
  createInflightDeduper,
  decidePublishedCatalogRefresh,
  PUBLISHED_CATALOG_TTL_MS,
} from "../lib/route/publishedCatalogRefreshPolicy";
import { lockRouteWorkspaceDuringRide } from "../lib/route/routeWorkspaceLock";
import {
  encodeCanonicalRouteGeometryProfile,
  fingerprintFromCanonicalSync,
} from "../lib/route/routeFingerprint";
import type { RouteProfile } from "../services/mapboxDirections";
import { formatDuration } from "../services/mapboxDirections";
import type { SavedRoute } from "../lib/route/repo/firestoreSavedRoutes";
import type { RideSessionStatus } from "./useVirtualRideSession";

export type UsePublicationCatalogHubOptions = {
  configured: boolean;
  user: User | null;
  routeGeometry: LineStringGeometry | null;
  rideStatus: RideSessionStatus;
  handleEndRideRef: MutableRefObject<() => void>;
  setRouteGeometry: Dispatch<SetStateAction<LineStringGeometry | null>>;
  setStartLngLat: Dispatch<SetStateAction<LngLat | null>>;
  setEndLngLat: Dispatch<SetStateAction<LngLat | null>>;
  setRouteWaypoints: Dispatch<SetStateAction<LngLat[]>>;
  setProfile: Dispatch<SetStateAction<RouteProfile>>;
  setRouteDistanceMeters: Dispatch<SetStateAction<number>>;
  setRouteDurationSec: Dispatch<SetStateAction<number>>;
  setRouteSummary: Dispatch<SetStateAction<string>>;
  resetRide: () => void;
  setActiveOfficialCourseId: Dispatch<SetStateAction<string | null>>;
  setPlaceSearchMarkerLngLat: Dispatch<SetStateAction<LngLat | null>>;
  /** 입문 코스 로드 직전에 저장 경로 ref·ad-hoc 등 App 쪽 정리 */
  enterBasicHubArtifactsRef: MutableRefObject<() => void>;
  /** 퍼블릭 코스 전환 시 이전 coursePresence 정리 */
  activeOfficialCourseIdRef?: MutableRefObject<string | null>;
  savedRoutes: SavedRoute[];
  pendingPublicRouteIds: ReadonlySet<string>;
  /** 퍼블릭·입문 코스 탭에서 불러올 때 주행 입구 표시 */
  onPublicCatalogRideEntry?: () => void;
};

/**
 * 퍼블릭 공식 코스 카탈로그, 경로 지문 매칭, 입문 허브 동행 courseId·입장/퇴장.
 */
export function usePublicationCatalogHub(options: UsePublicationCatalogHubOptions) {
  const {
    configured,
    user,
    routeGeometry,
    rideStatus,
    handleEndRideRef,
    setRouteGeometry,
    setStartLngLat,
    setEndLngLat,
    setRouteWaypoints,
    setProfile,
    setRouteDistanceMeters,
    setRouteDurationSec,
    setRouteSummary,
    resetRide,
    setActiveOfficialCourseId,
    setPlaceSearchMarkerLngLat,
    enterBasicHubArtifactsRef,
    activeOfficialCourseIdRef,
    savedRoutes,
    pendingPublicRouteIds,
    onPublicCatalogRideEntry,
  } = options;

  const [publishedPublicCourses, setPublishedPublicCourses] = useState<PublishedPublicCourseSummary[]>([]);
  const [publishedPublicCoursesLoading, setPublishedPublicCoursesLoading] = useState(false);
  const [publishedPublicCoursesError, setPublishedPublicCoursesError] = useState<string | null>(null);
  const [basicActiveHubCourseId, setBasicActiveHubCourseId] = useState<string | null>(null);
  const [basicStartLoading, setBasicStartLoading] = useState(false);
  const basicStartHubJoined = basicActiveHubCourseId !== null;
  const basicStartHubLeftExplicitRef = useRef(false);
  const catalogLastSuccessAtMsRef = useRef<number | null>(null);
  const catalogInflightRef = useRef(createInflightDeduper<PublishedPublicCourseSummary[]>());

  useEffect(() => {
    if (configured) return;
    catalogLastSuccessAtMsRef.current = null;
    catalogInflightRef.current.reset();
    setPublishedPublicCourses([]);
    setPublishedPublicCoursesError(null);
    setPublishedPublicCoursesLoading(false);
  }, [configured]);

  const refreshPublishedPublicCourseCatalog = useCallback(
    async (opts?: { force?: boolean }) => {
      if (!configured) {
        catalogLastSuccessAtMsRef.current = null;
        catalogInflightRef.current.reset();
        setPublishedPublicCourses([]);
        setPublishedPublicCoursesError(null);
        setPublishedPublicCoursesLoading(false);
        return;
      }
      const force = opts?.force === true;
      const decision = decidePublishedCatalogRefresh({
        hasCachedResult: catalogLastSuccessAtMsRef.current != null,
        lastSuccessAtMs: catalogLastSuccessAtMsRef.current,
        nowMs: Date.now(),
        ttlMs: PUBLISHED_CATALOG_TTL_MS,
        force,
      });
      if (decision === "use_cache") return;

      setPublishedPublicCoursesLoading(true);
      setPublishedPublicCoursesError(null);
      try {
        /**
         * 표시 이름 조회는 **여기서 꽂는다** — 코스 저장소는 사용자 저장소를 모른다
         * (`lib/route/routeIdentityPort.ts`).
         * 동시 자동 refresh 는 in-flight 하나로 합친다.
         */
        const rows = await catalogInflightRef.current.run(() =>
          listPublishedPublicCourses(getUserPublicLabelsByUid, 50),
        );
        catalogLastSuccessAtMsRef.current = Date.now();
        setPublishedPublicCourses(rows);
      } catch (e: unknown) {
        // 실패는 성공 freshness 로 기록하지 않는다. 직전 성공 rows 는 유지.
        if (catalogLastSuccessAtMsRef.current == null) {
          setPublishedPublicCourses([]);
        }
        const msg = e instanceof Error ? e.message : String(e);
        setPublishedPublicCoursesError(msg);
      } finally {
        setPublishedPublicCoursesLoading(false);
      }
    },
    [configured],
  );

  const publishedPublicSavedRouteIds = useMemo(
    () =>
      new Set(
        publishedPublicCourses
          .map((c) => c.sourceSavedRouteId)
          .filter((id): id is string => typeof id === "string" && id.length > 0),
      ),
    [publishedPublicCourses],
  );

  const [publishedPublicRouteFingerprints, setPublishedPublicRouteFingerprints] = useState<
    ReadonlySet<string>
  >(() => new Set());

  useEffect(() => {
    let cancelled = false;
    if (!configured || !user) {
      setPublishedPublicRouteFingerprints(new Set());
      return;
    }
    const fps = savedRoutes
      .filter((r) => r.completed === 1)
      .map((r) =>
        fingerprintFromCanonicalSync(
          encodeCanonicalRouteGeometryProfile(r.geometry, r.profile),
        ),
      );
    void findPublishedPublicFingerprintsAmong(fps)
      .then((hit) => {
        if (!cancelled) setPublishedPublicRouteFingerprints(hit);
      })
      .catch(() => {
        if (!cancelled) setPublishedPublicRouteFingerprints(new Set());
      });
    return () => {
      cancelled = true;
    };
  }, [configured, user, savedRoutes, publishedPublicCourses, pendingPublicRouteIds]);

  useEffect(() => {
    if (!user) {
      basicStartHubLeftExplicitRef.current = false;
      startTransition(() => setBasicActiveHubCourseId(null));
    }
  }, [user]);

  useEffect(() => {
    const matched = matchBasicSharedHubCourseId(routeGeometry);
    if (!matched) {
      basicStartHubLeftExplicitRef.current = false;
    }
  }, [routeGeometry]);

  useEffect(() => {
    if (!configured || !user) return;
    if (basicStartHubLeftExplicitRef.current) return;

    const matched = matchBasicSharedHubCourseId(routeGeometry);
    if (matched) {
      startTransition(() => setBasicActiveHubCourseId(matched));
      return;
    }

    if (
      basicActiveHubCourseId &&
      (BASIC_SHARED_HUB_IDS as readonly string[]).includes(basicActiveHubCourseId) &&
      routeGeometryMatchesBasicSharedHub(basicActiveHubCourseId, routeGeometry)
    ) {
      return;
    }

    if (routeGeometry?.coordinates?.length) {
      startTransition(() => setBasicActiveHubCourseId(null));
    }
  }, [configured, user, routeGeometry, basicActiveHubCourseId]);

  const enterBasicHub = useCallback(
    async (courseId: string) => {
      if (lockRouteWorkspaceDuringRide(rideStatus !== "idle")) {
        setRouteSummary("세션이 대기 상태일 때만 입문 경로를 불러올 수 있습니다.");
        return;
      }
      setBasicStartLoading(true);
      setRouteSummary("공식 경로 불러오는 중…");
      try {
        if (user && basicActiveHubCourseId && basicActiveHubCourseId !== courseId) {
          await deletePublicationSessionMember(user.uid, basicActiveHubCourseId).catch(() => {
            /* noop */
          });
        }
        const prevOfficial = activeOfficialCourseIdRef?.current;
        if (user && prevOfficial && prevOfficial !== courseId) {
          await deletePublicationSessionMember(user.uid, prevOfficial).catch(() => {
            /* noop */
          });
        }
        let payload = null;
        if (configured) {
          try {
            payload = await fetchCourseRoutePayload(courseId);
          } catch {
            payload = null;
          }
        }
        const resolved = payload ?? getBasicHubCoursePayload(courseId);
        const coords = resolved.geometry.coordinates;
        setRouteGeometry(resolved.geometry);
        setStartLngLat(coords[0] ?? null);
        setEndLngLat(coords[coords.length - 1] ?? null);
        setRouteWaypoints([]);
        setProfile(resolved.profile);
        setRouteDistanceMeters(resolved.distanceMeters);
        setRouteDurationSec(resolved.durationSec);
        resetRide();
        enterBasicHubArtifactsRef.current();
        setRouteSummary(
          `${resolved.title} · 거리 ${(resolved.distanceMeters / 1000).toFixed(2)} km / 예상 ${formatDuration(resolved.durationSec)}`,
        );
        basicStartHubLeftExplicitRef.current = false;
        setPlaceSearchMarkerLngLat(null);
        const joinHubPresence =
          Boolean(user) && (BASIC_SHARED_HUB_IDS as readonly string[]).includes(resolved.id);
        setBasicActiveHubCourseId(joinHubPresence ? resolved.id : null);
        setActiveOfficialCourseId(resolved.id);
        onPublicCatalogRideEntry?.();
      } catch (e: unknown) {
        const message = e instanceof Error ? e.message : String(e);
        setRouteSummary(message);
      } finally {
        setBasicStartLoading(false);
      }
    },
    [
      rideStatus,
      configured,
      user,
      resetRide,
      basicActiveHubCourseId,
      setRouteGeometry,
      setStartLngLat,
      setEndLngLat,
      setRouteWaypoints,
      setProfile,
      setRouteDistanceMeters,
      setRouteDurationSec,
      setRouteSummary,
      setActiveOfficialCourseId,
      setPlaceSearchMarkerLngLat,
      enterBasicHubArtifactsRef,
      activeOfficialCourseIdRef,
      onPublicCatalogRideEntry,
    ],
  );

  const leaveBasicHub = useCallback(async () => {
    handleEndRideRef.current();
    basicStartHubLeftExplicitRef.current = true;
    if (user && basicActiveHubCourseId) {
      await deletePublicationSessionMember(user.uid, basicActiveHubCourseId).catch(() => {
        /* noop */
      });
    }
    setBasicActiveHubCourseId(null);
    setPlaceSearchMarkerLngLat(null);
  }, [user, basicActiveHubCourseId, handleEndRideRef, setPlaceSearchMarkerLngLat]);

  return {
    publishedPublicCourses,
    publishedPublicCoursesLoading,
    publishedPublicCoursesError,
    refreshPublishedPublicCourseCatalog,
    publishedPublicSavedRouteIds,
    publishedPublicRouteFingerprints,
    basicActiveHubCourseId,
    setBasicActiveHubCourseId,
    basicStartLoading,
    basicStartHubJoined,
    enterBasicHub,
    leaveBasicHub,
  };
}
