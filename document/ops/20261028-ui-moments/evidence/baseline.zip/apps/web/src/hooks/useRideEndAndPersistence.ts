import type { User } from "firebase/auth";
import type { Dispatch, MutableRefObject, RefObject, SetStateAction } from "react";
import { useCallback } from "react";
import {
  promoteSavedRouteInFirestore,
  updateSavedRouteProgressInFirestore,
  type SavedRoute,
} from "../lib/route/repo/firestoreSavedRoutes";
import { markRouteActivityRideCompletedOptimistic } from "../lib/activity/repo/firestoreRouteActivity";
import { saveRideSessionToFirestore } from "../lib/ride/repo/firestoreRides";
import {
  persistRideEndCore,
  persistDiscardedRideSavedRouteProgress,
  type SaveRideSessionFn,
  type UpdateSavedRouteProgressFn,
  type PromoteSavedRouteFn,
  type OnSavedRouteProgressApplied,
} from "../lib/ride/rideEndPersistence";
import {
  buildConquestCellsFromRoute,
  buildTraveledPathForTrace,
  CONQUEST_CELL_ZOOM,
  CONQUEST_PAYLOAD_VERSION,
  type ConquestRidePayload,
} from "../lib/conquest/conquestTiles";
import type { LineStringGeometry, LngLat } from "../lib/geo/geo";
import { formatLngLat, getDistanceMeters } from "../lib/geo/geo";
import { computeRideSessionAnchors } from "../lib/ride/rideSessionAnchors";
import type { RideEndResult } from "../lib/ride/rideEndResult";
import {
  buildCaloriesMeta,
  clampActiveSecForCalories,
  estimateGrossKcal,
  type CalorieSessionSnapshot,
} from "../lib/ride/caloriesEstimate";
import { MAX_ROUTE_WAYPOINTS } from "../lib/geo/routeWaypoints";
import { safeRideSpeechCancel } from "../lib/ride/rideSpeech";
import { loadRideSessions, saveRideSessions, type StoredRideSession } from "../lib/ride/rideSessionsStorage";
import { isRouteCompletion, resolveRideEndDisposition } from "../lib/ride/rideRecordPolicy";
import { resolveSavedRouteProgressUpdate } from "../lib/route/savedRouteProgressPolicy";
import {
  loadSavedRoutesFromLocal,
  promoteSavedRouteInLocal,
  updateSavedRouteProgressInLocal,
} from "../lib/route/repo/savedRoutesLocal";
import { fetchMapboxReverseGeocodePlaceName } from "../services/mapboxReverseGeocode";
import type { RouteProfile } from "../services/mapboxDirections";
import type { PublishedPublicCourseSummary } from "../lib/route/repo/firestoreCourses";
import {
  resolvePublishedRouteLink,
  resolvePublishedRouteLinkByPublicationId,
  type RouteRideEntry,
} from "../lib/route/routePublicationResolve";
import type { LastEndedAdhocState } from "./useSavedRoutesWorkspace";
import type { RideMetricsUi, RideSessionStatus } from "./useVirtualRideSession";

export type UseRideEndAndPersistenceOptions = {
  mapboxAccessToken: string;
  configured: boolean;
  user: User | null;
  trailId: string;
  /** 주행 종료 시점 publication ID — `rides.publicationId`·CF aggregate용 */
  publicationIdRef: RefObject<string | null>;
  /** 종료 직후 heat 낙관 표시(서버 `liveNow` 지연 대비) */
  onRideEndedWithPublication?: (publicationId: string) => void;
  /** aggregate 캐시 무효화 직후 UI 갱신(heat 반영) */
  onRidePersistedToFirestore?: (publicationId: string | null) => void;
  profile: RouteProfile;
  rideStatus: RideSessionStatus;
  setRideStatus: Dispatch<SetStateAction<RideSessionStatus>>;
  rideMetrics: RideMetricsUi;
  routeGeometry: LineStringGeometry | null;
  routeDistanceMeters: number;
  routeDurationSec: number;
  routeWaypoints: LngLat[];
  startLngLat: LngLat | null;
  endLngLat: LngLat | null;
  startPlaceLabel: string | null;
  endPlaceLabel: string | null;
  loadedSavedRouteIdRef: MutableRefObject<string | null>;
  loadedSavedRouteNameRef: MutableRefObject<string | null>;
  /**
   * 이어 달리기(§9.5.5 단위7) — 이번 세션의 경로상 시작 오프셋(m). virtualDistance 는
   * 「경로상 위치(누적)」이므로 운동 인정·Claim 페이로드는 (virtualDistance − offset) 세션 구간만.
   */
  startOffsetMetersRef?: RefObject<number>;
  /** 로드 시점 저장 진행률(0..1) — 진행률 저장은 max(기존, 신규)로 최대 도달점 유지 */
  loadedSavedRouteProgressRef?: MutableRefObject<number>;
  /** 주행 입구 — 내 경로 vs 퍼블릭 탭 */
  rideEntryRef?: RefObject<RouteRideEntry | null>;
  /**
   * Conquest — 이번 세션의 케이던스>0 누적 초. null = BLE 센서 미연결(T0 no-sensor).
   * App 이 주행 중 1초 간격으로 누적(§3.2 Trust Tier). 칼로리 활동초와 동일 신호.
   */
  pedalActiveSecRef?: RefObject<number | null>;
  /** 세션 시작 시 고정된 체중·MET. 중간 설정 변경은 반영하지 않음 */
  calorieSessionSnapshotRef?: RefObject<CalorieSessionSnapshot | null>;
  /** 세션 중 센서 일시 끊김 여부 */
  calorieSignalGapRef?: RefObject<boolean>;
  /** `resolvePublishedRouteLink` 카탈로그 1차 힌트 */
  publishedCatalogRef?: RefObject<readonly PublishedPublicCourseSummary[]>;
  setSavedRoutes: Dispatch<SetStateAction<SavedRoute[]>>;
  setLastEndedWasAdhoc: Dispatch<SetStateAction<LastEndedAdhocState | null>>;
  setRecentSessions: Dispatch<SetStateAction<StoredRideSession[]>>;
  /**
   * 종료 결과(RIDE-CONTINUE-1 §3.5) — 도착·ad-hoc 여부와 무관하게 **모든 유효 Ride** 가 채운다.
   * 결과 시트는 이 값 하나로 구동되고, 닫으면 「다음 주행」 카드가 즉시 갱신된다.
   */
  setLastRideResult?: Dispatch<SetStateAction<RideEndResult | null>>;
  /**
   * N2: injectable Firestore fns (controlled Promise injection for testing).
   * 기본값: production imports. 테스트에서만 오버라이드한다.
   */
  saveRideSessionToFirestoreFn?: SaveRideSessionFn;
  updateSavedRouteProgressInFirestoreFn?: UpdateSavedRouteProgressFn;
  promoteSavedRouteInFirestoreFn?: PromoteSavedRouteFn;
  /**
   * 실제 progress 저장 성공 후 UI result 와 무관하게 슬롯 확보/해제용.
   * save/progress 실패에는 호출되지 않는다.
   */
  onSavedRouteProgressApplied?: OnSavedRouteProgressApplied;
};

/**
 * 가상 주행 종료: 로컬 기록·Firestore ride 문서·저장 경로 격상·ad-hoc 저장 컨텍스트.
 */
export function useRideEndAndPersistence(options: UseRideEndAndPersistenceOptions) {
  const {
    mapboxAccessToken,
    configured,
    user,
    trailId,
    publicationIdRef,
    onRideEndedWithPublication,
    onRidePersistedToFirestore,
    profile,
    rideStatus,
    setRideStatus,
    rideMetrics,
    routeGeometry,
    routeDistanceMeters,
    routeDurationSec,
    routeWaypoints,
    startLngLat,
    endLngLat,
    startPlaceLabel,
    endPlaceLabel,
    loadedSavedRouteIdRef,
    loadedSavedRouteNameRef,
    startOffsetMetersRef,
    loadedSavedRouteProgressRef,
    rideEntryRef,
    pedalActiveSecRef,
    calorieSessionSnapshotRef,
    calorieSignalGapRef,
    publishedCatalogRef,
    setSavedRoutes,
    setLastEndedWasAdhoc,
    setRecentSessions,
    setLastRideResult,
    saveRideSessionToFirestoreFn,
    updateSavedRouteProgressInFirestoreFn,
    promoteSavedRouteInFirestoreFn,
    onSavedRouteProgressApplied,
  } = options;

  const handleEndRide = useCallback(() => {
    if (rideStatus === "idle") return;
    safeRideSpeechCancel();

    const elapsedSec = Math.floor(rideMetrics.accumulatedMs / 1000);
    /**
     * 이어 달리기(§9.5.5 단위7) — virtualDistance 는 경로상 위치(누적).
     * 운동 인정(거리·칼로리·평속)·Claim 페이로드는 이번 세션 실주행 구간만.
     */
    const startOffsetMeters = Math.max(
      0,
      Math.min(startOffsetMetersRef?.current ?? 0, rideMetrics.virtualDistanceMeters),
    );
    const sessionDistanceMeters = rideMetrics.virtualDistanceMeters - startOffsetMeters;
    const snap = calorieSessionSnapshotRef?.current ?? null;
    const rawPedalForCal = clampActiveSecForCalories(
      pedalActiveSecRef?.current ?? null,
      elapsedSec,
    );
    const caloriesEstimate = estimateGrossKcal({
      weightKg: snap?.weightKg ?? null,
      met: snap?.met ?? null,
      activeSec: rawPedalForCal,
    });
    const caloriesMeta =
      caloriesEstimate != null && snap?.met != null && rawPedalForCal != null
        ? buildCaloriesMeta({
            met: snap.met,
            activeSec: rawPedalForCal,
            signalGap: calorieSignalGapRef?.current ?? false,
          })
        : null;
    const savedRouteIdAtEnd = loadedSavedRouteIdRef.current;
    const savedRouteNameAtEnd = loadedSavedRouteNameRef.current;
    // Codex -03 Fix 2: R1/F2 — Keep historical meaning of saved ratios (routeDistanceMeters 기준)
    // completionRatio (motion-offset) = virtualDist / routeDistanceMeters → 저장, 완주 판정, 0.98 비교
    // Resume 시에만 geometry 좌표로 변환 (boundary adapter)
    const completionRatio =
      routeDistanceMeters > 0
        ? Math.max(0, Math.min(1, rideMetrics.virtualDistanceMeters / routeDistanceMeters))
        : 0;

    const startPlaceSnapshot =
      startLngLat != null
        ? startPlaceLabel !== null && startPlaceLabel.trim().length > 0
          ? startPlaceLabel.trim()
          : formatLngLat(startLngLat)
        : undefined;
    const endPlaceSnapshot =
      endLngLat != null
        ? endPlaceLabel !== null && endPlaceLabel.trim().length > 0
          ? endPlaceLabel.trim()
          : formatLngLat(endLngLat)
        : undefined;

    /**
     * 실제 세션 시작·종료 anchor(§4.1) — 계획된 `endLngLat` 이 아니라 **실제 종료 누적 거리** 지점.
     * `liveForMap` 과 같은 경계 함수를 공유한다. geometry 가 없으면 좌표는 null 이고 저장은 계속된다.
     */
    const anchors = computeRideSessionAnchors({
      geometry: routeGeometry,
      routeDistanceMeters,
      startOffsetMeters,
      endVirtualDistanceMeters: rideMetrics.virtualDistanceMeters,
    });
    /** 이번 주행 **전** 저장돼 있던 진행률 — 결과 시트의 「31% → 43%」 좌변 */
    const previousProgressRatio = Math.max(
      0,
      Math.min(1, loadedSavedRouteProgressRef?.current ?? 0),
    );

    /**
     * 완주(≥98%)만 `completed:1` 로 격상하고 미완주는 진행률만 남긴다(§9.5).
     * 진행률은 최대 도달점 유지 — 「처음부터 다시」 중간 종료가 기존 재개 지점을 지우지 않게 한다.
     *
     * ⚠ **동기 구간에서 계산한다.** 아래 비동기 블록은 첫 `await` 뒤에 실행되는데, 그때는
     * 이 함수 끝에서 `loadedSavedRouteProgressRef.current = 0` 이 이미 실행된 뒤라
     * 거기서 ref 를 읽으면 언제나 0 이었다(= max 보호가 무력화).
     */
    const rideCompletedRoute = isRouteCompletion(completionRatio);
    // Codex -03 Fix 2: progressToSave는 routeDistanceMeters 기준 (historical meaning 유지)
    const progressToSave = Math.max(completionRatio, previousProgressRatio);

    /**
     * anchor 가 계획 핀과 사실상 같은 지점이면(전 구간 주행) 이미 확보한 지명을 그대로 쓴다.
     * 다르면(부분 주행) 아래 비동기 블록에서 anchor 좌표를 따로 역지오코딩한다.
     */
    const ANCHOR_SAME_PLACE_METERS = 25;
    const startAnchorIsPlanned =
      anchors.sessionStartLngLat != null &&
      startLngLat != null &&
      getDistanceMeters(anchors.sessionStartLngLat, startLngLat) <= ANCHOR_SAME_PLACE_METERS;
    const endAnchorIsPlanned =
      anchors.sessionEndLngLat != null &&
      endLngLat != null &&
      getDistanceMeters(anchors.sessionEndLngLat, endLngLat) <= ANCHOR_SAME_PLACE_METERS;

    const record: StoredRideSession = {
      id: crypto.randomUUID(),
      endedAt: new Date().toISOString(),
      elapsedSec,
      distanceMeters: sessionDistanceMeters,
      avgSpeedKmh:
        elapsedSec > 0
          ? (sessionDistanceMeters / 1000) / (elapsedSec / 3600)
          : 0,
      caloriesEstimate,
      caloriesMeta,
      routeDistanceMeters,
      routeDurationSec,
      userRouteId: savedRouteIdAtEnd,
      routeName: savedRouteNameAtEnd,
      completionRatio,
      startPlaceLabel: startPlaceSnapshot,
      endPlaceLabel: endPlaceSnapshot,
      ...anchors,
      sessionStartPlaceLabel: startAnchorIsPlanned ? startPlaceSnapshot : undefined,
      sessionEndPlaceLabel: endAnchorIsPlanned ? endPlaceSnapshot : undefined,
    };
    if (!user) {
      setRideStatus("idle");
      return;
    }

    /**
     * 운동 기록 폐기와 저장 경로 진행 반영을 분리(지시 13).
     * 짧은 이어 달리기로 남은 구간만 달려 기록이 폐기돼도, 진행이 늘었으면 완주·진행률은 반영한다.
     */
    const disposition = resolveRideEndDisposition({
      distanceMeters: record.distanceMeters,
      elapsedSec: record.elapsedSec,
      hasSavedRoute: Boolean(savedRouteIdAtEnd),
      previousProgressRatio,
      completionRatio,
    });
    const discardRecord = disposition.discardRecord;
    const applySavedRouteProgress = disposition.applySavedRouteProgress;

    /** Conquest 페이로드 — 이번 세션 실주행 구간(offset..virtualDistance) 도로 셀 + 궤적 + 검증된 페달링 초 */
    let conquestPayload: ConquestRidePayload | null = null;
    if (!discardRecord && routeGeometry && routeGeometry.coordinates.length >= 2) {
      try {
        const cells = buildConquestCellsFromRoute(
          routeGeometry,
          rideMetrics.virtualDistanceMeters,
          startOffsetMeters,
        );
        if (cells.length > 0) {
          const rawPedalSec = pedalActiveSecRef?.current ?? null;
          conquestPayload = {
            v: CONQUEST_PAYLOAD_VERSION,
            z: CONQUEST_CELL_ZOOM,
            cells,
            path: buildTraveledPathForTrace(
              routeGeometry,
              rideMetrics.virtualDistanceMeters,
              startOffsetMeters,
            ),
            pedalSec:
              rawPedalSec == null
                ? null
                : Math.max(0, Math.min(Math.round(rawPedalSec), elapsedSec)),
          };
        }
      } catch {
        /* 정복 계산 실패는 주행 저장을 막지 않는다 */
      }
    }

    if (!discardRecord) {
      const next = [record, ...loadRideSessions()].slice(0, 50);
      saveRideSessions(next, user);
      setRecentSessions(next);
    }

    /**
     * 결과 시트 구동값(§3.5) — 도착·ad-hoc 여부로 노출을 제한하지 않는다.
     * 유효 Ride 또는 **폐기됐지만 경로 진행이 늘어난** 종료는 시트를 연다.
     * 후자는 rides 저장이 없으므로 rideSaveStatus = "n/a".
     */
    if (!discardRecord || applySavedRouteProgress) {
      setLastRideResult?.({
        recordId: record.id,
        endedAtIso: record.endedAt,
        sessionDistanceMeters: record.distanceMeters,
        elapsedSec: record.elapsedSec,
        avgSpeedKmh: record.avgSpeedKmh,
        caloriesEstimate: discardRecord ? null : record.caloriesEstimate,
        caloriesMeta: discardRecord ? null : (record.caloriesMeta ?? null),
        savedRouteId: savedRouteIdAtEnd,
        routeName: savedRouteNameAtEnd,
        hasRoute: routeDistanceMeters > 0 && Boolean(routeGeometry),
        previousProgressRatio,
        progressRatio: Math.max(previousProgressRatio, completionRatio),
        routeCompleted: isRouteCompletion(completionRatio),
        anchorLngLat: anchors.sessionEndLngLat,
        anchorPlaceLabel: record.sessionEndPlaceLabel ?? null,
        profile,
        routeDistanceMeters,
        // F4: persistence status (independent axes)
        rideSaveStatus: discardRecord ? "n/a" : "pending",
        savedRouteProgressStatus:
          applySavedRouteProgress && savedRouteIdAtEnd ? "pending" : "n/a",
        // RIDE-CLAIM-RESULT-1: 세션 궤적 스냅샷 (Route workspace 초기화 전에 고정)
        sessionPathLngLat: (() => {
          if (!routeGeometry || routeGeometry.coordinates.length < 2) return null;
          try {
            const flat = buildTraveledPathForTrace(
              routeGeometry,
              rideMetrics.virtualDistanceMeters,
              startOffsetMeters,
            );
            if (flat.length < 4) return null;
            const pairs: import("../lib/geo/geo").LngLat[] = [];
            for (let i = 0; i < flat.length - 1; i += 2) {
              pairs.push([flat[i], flat[i + 1]]);
            }
            return pairs;
          } catch {
            return null;
          }
        })(),
      });
    } else {
      setLastRideResult?.(null);
    }

    /**
     * 진행률 낙관 반영(§3.5) — 결과 시트를 닫는 즉시 「다음 주행」 카드가 올바른 재개 후보를
     * 보이려면, Firestore 왕복을 기다리지 않고 로컬 state 부터 올려야 한다.
     * 규칙은 서버 transaction 과 동일한 순수 정책을 쓴다(낮은 값으로 되돌리지 않는다).
     * 서버 판정이 오면 아래에서 그 값으로 정정한다.
     * 기록 폐기여도 applySavedRouteProgress 이면 동일하게 낙관 반영한다.
     */
    if (applySavedRouteProgress && savedRouteIdAtEnd) {
      const nowIso = new Date().toISOString();
      setSavedRoutes((prev) =>
        prev.map((r) => {
          if (r.id !== savedRouteIdAtEnd) return r;
          if (rideCompletedRoute) {
            return {
              ...r,
              completed: 1,
              completedAtIso: r.completedAtIso ?? nowIso,
              expiresAtIso: null,
              lastProgressRatio: 1,
              updatedAtIso: nowIso,
            };
          }
          const decision = resolveSavedRouteProgressUpdate(
            { completed: r.completed, lastProgressRatio: r.lastProgressRatio },
            progressToSave,
          );
          if (!decision.shouldWrite) return r;
          return {
            ...r,
            lastProgressRatio: decision.nextProgressRatio,
            updatedAtIso: nowIso,
          };
        }),
      );
    }

    if (configured && !discardRecord) {
      /**
       * geocoding · publication 해소 후 `persistRideEndCore` 로 위임.
       * save / progress fns 은 N2 injectable deps 로 주입하고, 기본값은 production imports.
       */
      void (async () => {
        let sessionForPersist: StoredRideSession = record;
        const token = mapboxAccessToken.trim();
        if (token && startLngLat && endLngLat) {
          try {
            /**
             * 계획 핀 지명 + **실제 세션 anchor 지명**(§4.1). anchor 가 계획 핀과 같은 지점이면
             * 같은 결과를 재사용해 불필요한 호출을 만들지 않는다(부분 주행일 때만 추가 조회).
             */
            const needStartAnchor =
              anchors.sessionStartLngLat != null && !startAnchorIsPlanned;
            const needEndAnchor = anchors.sessionEndLngLat != null && !endAnchorIsPlanned;
            const [sName, eName, sAnchorName, eAnchorName] = await Promise.all([
              fetchMapboxReverseGeocodePlaceName(startLngLat, token),
              fetchMapboxReverseGeocodePlaceName(endLngLat, token),
              needStartAnchor
                ? fetchMapboxReverseGeocodePlaceName(anchors.sessionStartLngLat!, token)
                : Promise.resolve(null),
              needEndAnchor
                ? fetchMapboxReverseGeocodePlaceName(anchors.sessionEndLngLat!, token)
                : Promise.resolve(null),
            ]);
            const sFromApi = sName?.trim();
            const eFromApi = eName?.trim();
            const sessionStartFromApi = needStartAnchor
              ? sAnchorName?.trim()
              : sFromApi || record.sessionStartPlaceLabel;
            const sessionEndFromApi = needEndAnchor
              ? eAnchorName?.trim()
              : eFromApi || record.sessionEndPlaceLabel;
            if (sFromApi || eFromApi || sessionStartFromApi || sessionEndFromApi) {
              sessionForPersist = {
                ...record,
                startPlaceLabel: sFromApi || record.startPlaceLabel,
                endPlaceLabel: eFromApi || record.endPlaceLabel,
                sessionStartPlaceLabel:
                  sessionStartFromApi || record.sessionStartPlaceLabel,
                sessionEndPlaceLabel: sessionEndFromApi || record.sessionEndPlaceLabel,
              };
              const rows = loadRideSessions().map((r) =>
                r.id === record.id ? sessionForPersist : r,
              );
              saveRideSessions(rows, user);
              setRecentSessions(rows);
              // 결과 시트의 「다음 출발점」 지명도 함께 갱신(좌표는 UI 에 노출하지 않는다).
              const resolvedAnchorLabel = sessionForPersist.sessionEndPlaceLabel ?? null;
              setLastRideResult?.((prev) =>
                prev && prev.recordId === record.id
                  ? { ...prev, anchorPlaceLabel: resolvedAnchorLabel }
                  : prev,
              );
            }
          } catch {
            /* noop */
          }
        }
        let persistedPublicationId = publicationIdRef.current?.trim() || null;
        let canonicalRouteId = savedRouteIdAtEnd;
        let publicationId: string | null = persistedPublicationId;
        let publicTitleSnap: string | null = null;
        let routeEntry: RouteRideEntry | null = rideEntryRef?.current ?? null;

        if (
          !persistedPublicationId &&
          savedRouteIdAtEnd &&
          routeGeometry &&
          routeGeometry.coordinates.length >= 2
        ) {
          try {
            const link = await resolvePublishedRouteLink({
              savedRouteId: savedRouteIdAtEnd,
              geometry: routeGeometry,
              profile,
              catalogHints: publishedCatalogRef?.current,
            });
            if (link) {
              persistedPublicationId = link.publicationId;
              publicationId = link.publicationId;
              canonicalRouteId = link.routeId;
              publicTitleSnap = link.publicTitle;
              if (!routeEntry) routeEntry = "owner_library";
            }
          } catch {
            /* publication 조회 실패 시 publicationId 없이 저장 */
          }
        }

        if (persistedPublicationId && !canonicalRouteId) {
          try {
            const link = await resolvePublishedRouteLinkByPublicationId(persistedPublicationId);
            if (link) {
              canonicalRouteId = link.routeId;
              publicationId = publicationId ?? link.publicationId;
              publicTitleSnap = publicTitleSnap ?? link.publicTitle;
              if (!routeEntry) routeEntry = "public_catalog";
            }
          } catch {
            /* noop */
          }
        }

        if (savedRouteIdAtEnd && !routeEntry) routeEntry = "owner_library";
        if (persistedPublicationId && !savedRouteIdAtEnd && !routeEntry) {
          routeEntry = "public_catalog";
        }

        // aggregate 재조회는 onRidePersisted에서 수행 — 여기서 invalidate 하면
        // CF `recentRideCount7d` 반영 전 서버 0이 낙관 heat를 지워 버린다.
        const publicationIdBeforeAsync = publicationIdRef.current?.trim() || null;

        // N2: persistRideEndCore 로 저장 커널 위임 — injectable deps 로 controlled Promise 주입 가능
        await persistRideEndCore(
          {
            record,
            sessionForPersist,
            userId: user.uid,
            trailId,
            savedRouteIdAtEnd,
            rideCompletedRoute,
            progressToSave,
            completionRatio,
            canonicalRouteId,
            publicationId,
            persistedPublicationId,
            publicationIdBeforeAsync,
            routeEntry,
            publicTitleSnap,
            profile,
            conquestPayload,
            routeDistanceMeters,
            routeDurationSec,
            routeGeometry,
            routeWaypoints,
            startLngLat,
            endLngLat,
          },
          {
            setLastRideResult: setLastRideResult ?? (() => {}),
            setSavedRoutes,
            setRecentSessions,
            setLastEndedWasAdhoc,
            onRidePersistedToFirestore,
            onRideEndedWithPublication,
            onPublicationOptimistic: markRouteActivityRideCompletedOptimistic,
          },
          {
            saveRideSessionFn:
              saveRideSessionToFirestoreFn ?? saveRideSessionToFirestore,
            updateSavedRouteProgressFn:
              updateSavedRouteProgressInFirestoreFn ?? updateSavedRouteProgressInFirestore,
            promoteSavedRouteFn:
              promoteSavedRouteInFirestoreFn ?? promoteSavedRouteInFirestore,
            loadRideSessionsFn: loadRideSessions,
            saveRideSessionsFn: (items) => saveRideSessions(items, user),
            onSavedRouteProgressApplied,
          },
        );
        // persistRideEndCore 는 절대 throw 하지 않는다 — .catch() 불필요
      })();
    } else if (
      configured &&
      discardRecord &&
      applySavedRouteProgress &&
      savedRouteIdAtEnd
    ) {
      /**
       * 짧은 주행으로 운동 기록은 폐기했지만 경로 진행·완주는 반영(지시 13).
       * rides 문서 없음 → promote/update 의 rideId 는 "" (adhoc promote 관례).
       */
      void persistDiscardedRideSavedRouteProgress(
        {
          userId: user.uid,
          recordId: record.id,
          savedRouteId: savedRouteIdAtEnd,
          rideCompletedRoute,
          progressToSave,
        },
        {
          setLastRideResult: setLastRideResult ?? (() => {}),
          setSavedRoutes,
        },
        {
          updateSavedRouteProgressFn:
            updateSavedRouteProgressInFirestoreFn ?? updateSavedRouteProgressInFirestore,
          promoteSavedRouteFn:
            promoteSavedRouteInFirestoreFn ?? promoteSavedRouteInFirestore,
          onSavedRouteProgressApplied,
        },
      );
    } else if (applySavedRouteProgress && savedRouteIdAtEnd) {
      // Firebase 미구성(로컬 전용) — 완주 게이트·진행률 저장 동일 적용(§9.5)
      // 폐기된 짧은 주행도 진행이 늘었으면 여기로 온다. rideId: 폐기면 "" (Firestore 관례와 동일).
      const localCompleted = isRouteCompletion(completionRatio);
      const rideIdForWrite = discardRecord ? "" : record.id;
      let appliedCompleted: 0 | 1 = localCompleted ? 1 : 0;
      if (localCompleted) {
        promoteSavedRouteInLocal({
          routeId: savedRouteIdAtEnd,
          rideId: rideIdForWrite,
        });
      } else {
        const applied = updateSavedRouteProgressInLocal({
          routeId: savedRouteIdAtEnd,
          rideId: rideIdForWrite,
          progressRatio: Math.max(completionRatio, previousProgressRatio),
        });
        appliedCompleted = applied.completed;
      }
      setSavedRoutes(loadSavedRoutesFromLocal());
      setLastRideResult?.((prev) =>
        prev && prev.recordId === record.id
          ? {
              ...prev,
              routeCompleted: appliedCompleted === 1,
              rideSaveStatus: discardRecord ? "n/a" : prev.rideSaveStatus,
              savedRouteProgressStatus: "success",
            }
          : prev,
      );
      if (user) {
        onSavedRouteProgressApplied?.({
          userId: user.uid,
          recordId: record.id,
          routeId: savedRouteIdAtEnd,
          routeCompleted: appliedCompleted === 1,
        });
      }
    } else if (
      !discardRecord &&
      routeGeometry &&
      routeGeometry.coordinates.length >= 2 &&
      startLngLat &&
      endLngLat &&
      routeDistanceMeters > 0
    ) {
      setLastEndedWasAdhoc({
        distanceMeters: routeDistanceMeters,
        durationSec: routeDurationSec,
        geometry: routeGeometry,
        startLngLat,
        endLngLat,
        waypoints: routeWaypoints.slice(0, MAX_ROUTE_WAYPOINTS),
        profile,
        rideId: null,
        progressRatio: progressToSave,
        completedRoute: rideCompletedRoute,
      });
    }

    if (!(configured && user) && !discardRecord) {
      const token = mapboxAccessToken.trim();
      if (token && startLngLat && endLngLat) {
        void (async () => {
          try {
            const [sName, eName] = await Promise.all([
              fetchMapboxReverseGeocodePlaceName(startLngLat, token),
              fetchMapboxReverseGeocodePlaceName(endLngLat, token),
            ]);
            const sFromApi = sName?.trim();
            const eFromApi = eName?.trim();
            if (!sFromApi && !eFromApi) return;
            const sessionForPersist: StoredRideSession = {
              ...record,
              startPlaceLabel: sFromApi || record.startPlaceLabel,
              endPlaceLabel: eFromApi || record.endPlaceLabel,
            };
            const rows = loadRideSessions().map((r) =>
              r.id === record.id ? sessionForPersist : r,
            );
            saveRideSessions(rows, user);
            setRecentSessions(rows);
          } catch {
            /* noop */
          }
        })();
      }
    }

    loadedSavedRouteIdRef.current = null;
    loadedSavedRouteNameRef.current = null;
    if (loadedSavedRouteProgressRef) loadedSavedRouteProgressRef.current = 0;
    if (rideEntryRef) rideEntryRef.current = null;

    const publicationIdAtEnd = publicationIdRef.current?.trim() || null;
    if (publicationIdAtEnd && !discardRecord) {
      markRouteActivityRideCompletedOptimistic(publicationIdAtEnd);
      onRideEndedWithPublication?.(publicationIdAtEnd);
    }

    setRideStatus("idle");
  }, [
    mapboxAccessToken,
    configured,
    user,
    trailId,
    profile,
    rideStatus,
    setRideStatus,
    rideMetrics,
    routeGeometry,
    routeDistanceMeters,
    routeDurationSec,
    routeWaypoints,
    startLngLat,
    endLngLat,
    startPlaceLabel,
    endPlaceLabel,
    loadedSavedRouteIdRef,
    loadedSavedRouteNameRef,
    startOffsetMetersRef,
    loadedSavedRouteProgressRef,
    rideEntryRef,
    pedalActiveSecRef,
    calorieSessionSnapshotRef,
    calorieSignalGapRef,
    publicationIdRef,
    publishedCatalogRef,
    setSavedRoutes,
    setLastEndedWasAdhoc,
    setRecentSessions,
    setLastRideResult,
    onRideEndedWithPublication,
    onRidePersistedToFirestore,
    saveRideSessionToFirestoreFn,
    updateSavedRouteProgressInFirestoreFn,
    promoteSavedRouteInFirestoreFn,
    onSavedRouteProgressApplied,
  ]);

  return { handleEndRide };
}
