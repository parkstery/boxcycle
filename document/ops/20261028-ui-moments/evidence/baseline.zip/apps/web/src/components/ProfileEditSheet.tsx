import { useEffect, useRef, useState, type FormEvent } from "react";
import type { User } from "firebase/auth";
import {
  CALORIE_INTENSITY_OPTIONS,
  WEIGHT_KG_INPUT_START,
  WEIGHT_KG_MAX,
  WEIGHT_KG_MIN,
  parseWeightKg,
  type CalorieIntensityId,
} from "../lib/ride/caloriesEstimate";
import {
  isValidNickname,
  nicknameChangeBlockedUntilMs,
  NICKNAME_CHANGE_COOLDOWN_DAYS,
  NICKNAME_RULES_SUMMARY_KO,
} from "../lib/identity/nickname";
import { ACCOUNT_DELETION_CONFIRM_PHRASE, deleteMyAccount, isDeletionConfirmPhrase } from "../lib/account/accountDeletion";
import { prepareStartScreen } from "../lib/storage/appSessionKeys";
import "./ride/RideSettingsSheet.css";
import "./ProfileEditSheet.css";
import { SettingsCloseIcon } from "./ui/SettingsCloseIcon";
import { useDialogFocus } from "./ui/useDialogFocus";

type ProfileEditSheetProps = {
  open: boolean;
  onClose: () => void;
  user: User | null;
  weightKg: number | null;
  intensityId: CalorieIntensityId | null;
  /** 마지막 닉네임 변경 시각(ms, users/{uid}.nicknameChangedAt). 30일 안이면 입력을 잠근다 */
  nicknameChangedAtMs: number | null;
  /** 실패 시 throw — 메시지를 시트에 보여 준다 */
  onChangeNickname: (nickname: string) => Promise<void>;
  onWeightKg: (raw: string) => boolean | void;
  onIntensityId: (id: CalorieIntensityId | null) => boolean | void;
};

/**
 * 프로필 수정 — 닉네임(정식 계정만)·체중·체력. 2026-10-08 Chief.
 * 체중·체력은 본인 전용 서버 문서로 기기 간 동기화된다(useCalorieProfile).
 * 하단에 「계정 탈퇴」 작은 글자 버튼 추가(지시03).
 */
export function ProfileEditSheet(props: ProfileEditSheetProps) {
  if (!props.open || !props.user) return null;
  // 열 때마다 현재 값으로 새로 시작한다(닫힌 동안 바뀐 값·이전 오류가 남지 않게)
  return <ProfileEditForm {...props} user={props.user} />;
}

function ProfileEditForm(props: ProfileEditSheetProps & { user: User }) {
  const { onClose } = props;
  const panelRef = useRef<HTMLFormElement>(null);
  useDialogFocus(true, panelRef);
  const isGuest = props.user.isAnonymous;
  const currentNickname = props.user.displayName?.trim() ?? "";
  const [nickname, setNickname] = useState(currentNickname);
  // 체중이 없으면 70kg 에서 시작한다(Chief 10-26) — 보이는 값이 곧 저장될 값이다
  const [weightDraft, setWeightDraft] = useState(String(props.weightKg ?? WEIGHT_KG_INPUT_START));
  const [intensityId, setIntensityId] = useState<CalorieIntensityId | null>(props.intensityId);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  // 열 때 한 번 판정한다 — 시트를 연 채로 30일이 지나는 경우는 없다
  const [nicknameLockedUntilMs] = useState(() =>
    nicknameChangeBlockedUntilMs(props.nicknameChangedAtMs, Date.now()),
  );

  // 계정 탈퇴 확인 상태
  const [confirmingDeletion, setConfirmingDeletion] = useState(false);
  const [deletionPhrase, setDeletionPhrase] = useState("");
  const [deletionBusy, setDeletionBusy] = useState(false);
  const [deletionNote, setDeletionNote] = useState<string | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !saving && !confirmingDeletion) onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose, saving, confirmingDeletion]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const nextNickname = nickname.trim();
    const nicknameChanged = !isGuest && nextNickname !== currentNickname;
    if (nicknameChanged && !isValidNickname(nextNickname)) {
      setError(NICKNAME_RULES_SUMMARY_KO);
      return;
    }
    const weightKg = parseWeightKg(weightDraft);
    if (weightKg == null && weightDraft.trim() !== "") {
      setError(`체중은 ${WEIGHT_KG_MIN}–${WEIGHT_KG_MAX}kg 사이로 입력해 주세요.`);
      return;
    }
    setError(null);
    setSaving(true);
    try {
      if (nicknameChanged) await props.onChangeNickname(nextNickname);
      if (weightKg !== props.weightKg) props.onWeightKg(weightKg == null ? "" : String(weightKg));
      if (intensityId !== props.intensityId) props.onIntensityId(intensityId);
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setSaving(false);
    }
  }

  const runAccountDeletion = async () => {
    if (!props.user || props.user.isAnonymous || deletionBusy) return;
    if (!isDeletionConfirmPhrase(deletionPhrase)) return;
    setDeletionBusy(true);
    setDeletionNote(null);
    try {
      await deleteMyAccount(props.user, deletionPhrase);
      prepareStartScreen("account-deleted");
      location.reload();
    } catch (e) {
      setDeletionBusy(false);
      setDeletionNote(e instanceof Error ? e.message : String(e));
    }
  };

  return (
    <div className="ride-settings-sheet profile-edit-sheet settings-surface" aria-modal="true" role="dialog" aria-label="프로필 수정">
      <button
        type="button"
        className="ride-settings-sheet__scrim"
        aria-label="닫기"
        title="닫기"
        disabled={saving || deletionBusy}
        onClick={onClose}
      />
      <form ref={panelRef} className="ride-settings-sheet__panel settings-surface__panel" noValidate onSubmit={(ev) => void handleSubmit(ev)}>
        <div className="ride-settings-sheet__handle" aria-hidden />
        <div className="settings-surface__head">
          <h2 className="ride-settings-sheet__title settings-surface__title">프로필 수정</h2>
          <button type="button" className="settings-surface__close" aria-label="닫기" title="닫기" disabled={saving || deletionBusy} onClick={onClose}><SettingsCloseIcon /></button>
        </div>

        <div className="ride-settings-sheet__group profile-edit-sheet__nickname">
          <span className="ride-settings-sheet__kicker">닉네임</span>
          {isGuest ? (
            <p className="ride-settings-sheet__help">
              게스트는 닉네임이 없습니다. Google 연결 후 정할 수 있습니다.
            </p>
          ) : (
            <>
              <input
                className="profile-edit-sheet__input"
                type="text"
                aria-label="닉네임"
                autoComplete="username"
                spellCheck={false}
                maxLength={12}
                value={nickname}
                disabled={saving || nicknameLockedUntilMs != null}
                onChange={(ev) => {
                  setNickname(ev.target.value);
                  setError(null);
                }}
              />
              <p className="ride-settings-sheet__help">
                {nicknameLockedUntilMs != null
                  ? `닉네임은 ${NICKNAME_CHANGE_COOLDOWN_DAYS}일에 한 번 바꿀 수 있습니다. ${formatMonthDay(nicknameLockedUntilMs)} 이후에 바꿀 수 있습니다.`
                  : `${NICKNAME_RULES_SUMMARY_KO} 바꾸면 ${NICKNAME_CHANGE_COOLDOWN_DAYS}일 동안 다시 바꿀 수 없습니다.`}
              </p>
            </>
          )}
        </div>

        <div className="ride-settings-sheet__group">
          <div className="profile-edit-sheet__calorie-field">
            <span className="ride-settings-sheet__kicker">체중</span>
            <div className="profile-edit-sheet__weight-controls">
              <button type="button" className="profile-edit-sheet__weight-step" aria-label="체중 줄이기" disabled={saving} onClick={() => setWeightDraft(String(Math.max(WEIGHT_KG_MIN, Math.round(((parseWeightKg(weightDraft) ?? props.weightKg ?? WEIGHT_KG_INPUT_START) - 1) * 10) / 10)))}>−</button>
              <label className="ride-settings-sheet__weight">
                <span className="profile-edit-sheet__visually-hidden">체중(kg)</span>
                <input
                  type="number"
                  aria-label="체중(kg)"
                  inputMode="decimal"
                  min={WEIGHT_KG_MIN}
                  max={WEIGHT_KG_MAX}
                  step="0.1"
                  placeholder={`${WEIGHT_KG_MIN}–${WEIGHT_KG_MAX}`}
                  value={weightDraft}
                  disabled={saving}
                  onChange={(ev) => {
                    setWeightDraft(ev.target.value);
                    setError(null);
                  }}
                />
                <span className="profile-edit-sheet__weight-unit">kg</span>
              </label>
              <button type="button" className="profile-edit-sheet__weight-step" aria-label="체중 늘리기" disabled={saving} onClick={() => setWeightDraft(String(Math.min(WEIGHT_KG_MAX, Math.round(((parseWeightKg(weightDraft) ?? props.weightKg ?? WEIGHT_KG_INPUT_START) + 1) * 10) / 10)))}>+</button>
              <input
                className="profile-edit-sheet__weight-slider"
                type="range"
                aria-label="체중 슬라이더"
                min={WEIGHT_KG_MIN}
                max={WEIGHT_KG_MAX}
                step="0.1"
                value={parseWeightKg(weightDraft) ?? props.weightKg ?? WEIGHT_KG_INPUT_START}
                disabled={saving}
                onChange={(ev) => {
                  setWeightDraft(ev.target.value);
                  setError(null);
                }}
              />
            </div>
          </div>
          <div className="profile-edit-sheet__calorie-field">
            <span className="ride-settings-sheet__kicker">체력</span>
            <div className="profile-edit-sheet__fitness-scale">
            <span className="profile-edit-sheet__fitness-end" aria-hidden="true">약함</span>
            <div className="ride-settings-sheet__chips" role="group" aria-label="체력 1 약함 ~ 5 강함">
              {CALORIE_INTENSITY_OPTIONS.map((opt) => {
                const active = intensityId === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    className={`ride-settings-sheet__chip${active ? " is-active" : ""}`}
                    aria-pressed={active}
                    aria-label={`체력 ${opt.label}`}
                    title={`체력 ${opt.label}`}
                    disabled={saving}
                    onClick={() => setIntensityId(active ? null : opt.id)}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>
            <span className="profile-edit-sheet__fitness-end" aria-hidden="true">강함</span>
            </div>
          </div>
          <p className="ride-settings-sheet__help">본인만 볼 수 있고 다른 기기에서도 이어 씁니다.</p>
        </div>

        {error ? (
          <p className="ride-settings-sheet__error" role="alert">
            {error}
          </p>
        ) : null}

        <div className="ride-settings-sheet__row profile-edit-sheet__actions">
          <button type="button" className="ride-settings-sheet__btn" disabled={saving} onClick={onClose}>
            취소
          </button>
          <button
            type="submit"
            className="ride-settings-sheet__btn ride-settings-sheet__btn--primary"
            disabled={saving}
          >
            {saving ? "저장 중…" : "저장"}
          </button>
        </div>

        {/* 계정 탈퇴 — 하단 작은 글자 버튼 (지시03) */}
        {!isGuest && (
          <div className="profile-edit-sheet__deletion-section">
            {confirmingDeletion ? (
              <div className="profile-edit-sheet__deletion-confirm" role="group" aria-label="계정 탈퇴 확인">
                <p className="profile-edit-sheet__deletion-copy">
                  계정과 내 경로·주행 기록·정복 기록·토큰이 즉시 삭제되며 되돌릴 수 없습니다.
                  구독 중이면 해지됩니다. 내가 등록한 퍼블릭 경로는 「탈퇴한 라이더」 이름으로
                  남습니다.
                </p>
                <label className="profile-edit-sheet__deletion-copy">
                  계속하려면 「{ACCOUNT_DELETION_CONFIRM_PHRASE}」를 입력하세요
                  <input
                    type="text"
                    className="profile-edit-sheet__deletion-input"
                    value={deletionPhrase}
                    disabled={deletionBusy}
                    aria-label="탈퇴 확인 문구"
                    onChange={(e) => setDeletionPhrase(e.target.value)}
                  />
                </label>
                {deletionNote ? (
                  <p className="profile-edit-sheet__deletion-copy" role="alert">
                    {deletionNote}
                  </p>
                ) : null}
                <div className="profile-edit-sheet__deletion-row">
                  <button
                    type="button"
                    className="ride-settings-sheet__btn"
                    disabled={deletionBusy}
                    onClick={() => {
                      setConfirmingDeletion(false);
                      setDeletionPhrase("");
                      setDeletionNote(null);
                    }}
                  >
                    취소
                  </button>
                  <button
                    type="button"
                    className="ride-settings-sheet__btn ride-settings-sheet__btn--danger"
                    disabled={
                      deletionBusy || !isDeletionConfirmPhrase(deletionPhrase)
                    }
                    title="Delete account"
                    onClick={() => void runAccountDeletion()}
                  >
                    {deletionBusy ? "탈퇴 처리 중…" : "탈퇴"}
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                className="profile-edit-sheet__deletion-btn"
                disabled={deletionBusy}
                onClick={() => setConfirmingDeletion(true)}
              >
                계정 탈퇴
              </button>
            )}
          </div>
        )}
      </form>
    </div>
  );
}

function formatMonthDay(ms: number): string {
  const d = new Date(ms);
  return `${d.getMonth() + 1}월 ${d.getDate()}일`;
}