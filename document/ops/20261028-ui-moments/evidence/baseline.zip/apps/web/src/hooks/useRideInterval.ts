import { useState } from "react";
import {
  DEFAULT_RIDE_INTERVAL_CONFIG,
  getRideIntervalView,
  normalizeRideIntervalConfig,
  type RideIntervalConfig,
} from "../lib/ride/rideInterval";

const CONFIG_STORAGE_KEY = "spinatlas.rideInterval.config.v1";

function copyConfig(config: Required<RideIntervalConfig>): Required<RideIntervalConfig> {
  return {
    highSec: config.highSec,
    lowSec: config.lowSec,
    repeats: config.repeats,
    warmupSec: config.warmupSec,
    cooldownSec: config.cooldownSec,
  };
}

function sameConfig(a: Required<RideIntervalConfig>, b: Required<RideIntervalConfig>): boolean {
  return (
    a.highSec === b.highSec &&
    a.lowSec === b.lowSec &&
    a.repeats === b.repeats &&
    a.warmupSec === b.warmupSec &&
    a.cooldownSec === b.cooldownSec
  );
}

function fallbackConfig(): Required<RideIntervalConfig> {
  return copyConfig(DEFAULT_RIDE_INTERVAL_CONFIG);
}

function readStoredConfig(): Required<RideIntervalConfig> {
  try {
    const storage = globalThis.localStorage;
    if (!storage) return fallbackConfig();
    const raw = storage.getItem(CONFIG_STORAGE_KEY);
    if (!raw) return fallbackConfig();
    const parsed: unknown = JSON.parse(raw);
    return normalizeRideIntervalConfig(parsed) ?? fallbackConfig();
  } catch {
    return fallbackConfig();
  }
}

function writeStoredConfig(config: Required<RideIntervalConfig>): void {
  try {
    globalThis.localStorage?.setItem(CONFIG_STORAGE_KEY, JSON.stringify(copyConfig(config)));
  } catch {
    // 저장 실패 시 메모리 선택값만 유지한다.
  }
}

function resolveInitialConfig(initialConfig?: RideIntervalConfig): Required<RideIntervalConfig> {
  if (initialConfig !== undefined) {
    return normalizeRideIntervalConfig(initialConfig) ?? fallbackConfig();
  }
  return readStoredConfig();
}

/** 주행의 활동시간을 공유하므로 일시정지·배경 복귀에서 별도 시계가 어긋나지 않는다. */
export function useRideInterval(
  status: "idle" | "running" | "paused",
  elapsedMs: number,
  initiallyEnabled = false,
  initialConfig?: RideIntervalConfig,
) {
  const active = status !== "idle";
  const [selection, setSelection] = useState(() => ({
    enabled: initiallyEnabled,
    startMs: 0,
    active,
    config: resolveInitialConfig(initialConfig),
  }));
  // 주행이 끝나거나 새로 시작할 때 구간 기준만 초기화하고 사용자의 선택은 유지한다.
  if (selection.active !== active) {
    setSelection({ ...selection, active, startMs: 0 });
  }
  const startMs = selection.active === active ? selection.startMs : 0;
  const config = normalizeRideIntervalConfig(selection.config) ?? fallbackConfig();
  return {
    enabled: selection.enabled,
    onEnabled: (enabled: boolean) => setSelection({ ...selection, enabled, startMs: active ? elapsedMs : 0, active }),
    view: selection.enabled && active ? getRideIntervalView(elapsedMs - startMs, config) : null,
    config,
    onConfig: (next: RideIntervalConfig): boolean => {
      const normalized = normalizeRideIntervalConfig(next);
      if (!normalized) return false;
      if (sameConfig(normalized, config)) return true;
      writeStoredConfig(normalized);
      const restart = selection.enabled && active;
      setSelection({
        ...selection,
        config: copyConfig(normalized),
        startMs: restart ? elapsedMs : selection.startMs,
        active,
      });
      return true;
    },
  };
}
