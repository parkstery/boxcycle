/* eslint-disable react-hooks/refs, react-hooks/set-state-in-effect, react-hooks/purity */
import { startTransition, useEffect, useMemo, useRef, useState } from "react";
import type { User } from "firebase/auth";
import type { LineStringGeometry, LngLat } from "../lib/geo/geo";
import { decimateLineStringVertices, maxLineStringVerticesForMapZoom } from "../lib/geo/geoDecimate";
import { acquireTrailLivePublicationRidesSubscription } from "../lib/trail/repo/livePublicationRidesSubscriptionHub";
import { sanitizeTrailId } from "../lib/trail/repo/firestoreTrail";
import {
  isTrailLivePublicationRideRowFresh,
  isTrailLivePublicationRideRowPeerVisible,
  type TrailLivePublicationRideRow,
} from "../lib/trail/repo/firestoreTrailLivePublicationRides";
import { spectatorPointOnRoute } from "../lib/peerMotion/spectatorRideExtrap";
import { presenceRiderDisplayName } from "../lib/identity/riderName";
import { loadMissingPublicationGeometries, type PublicationGeomState } from "./loadPublicationGeometries";

export type TrailSpectatorDot = { id: string; lngLat: LngLat; label: string };

type UseTrailLivePublicationRideSpectatorOverlayOpts = {
  user: User | null | undefined;
  trailId: string;
  trailLabel: string;
  enabled: boolean;
  mapZoom: number;
  excludePeerIds: ReadonlySet<string>;
};

/**
 * 같은 Trail `livePublicationRides` → 동행 라이더 dot + 노선(line).
 * world 전역 dot 은 `livePresence` (MapView global layer).
 */
export function useTrailLivePublicationRideSpectatorOverlay(opts: UseTrailLivePublicationRideSpectatorOverlayOpts): {
  spectatorDots: TrailSpectatorDot[];
  spectatorRouteGeometries: LineStringGeometry[];
  livePublicationIds: string[];
  error: string | null;
} {
  const { user, trailId, trailLabel, enabled, mapZoom, excludePeerIds } = opts;
  const [rows, setRows] = useState<TrailLivePublicationRideRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [geomEpoch, setGeomEpoch] = useState(0);
  const [spectatorTickMs, setSpectatorTickMs] = useState(() => Date.now());
  const geomByPublicationRef = useRef<Map<string, PublicationGeomState>>(new Map());

  const myUid = user?.uid ?? null;

  useEffect(() => {
    if (!enabled || !user) {
      startTransition(() => {
        setRows([]);
        setError(null);
      });
      return;
    }

    const tid = sanitizeTrailId(trailId);
    let cancelled = false;
    startTransition(() => setError(null));

    const release = acquireTrailLivePublicationRidesSubscription(
      tid,
      (next) => {
        if (!cancelled) startTransition(() => setRows(next));
      },
      (err) => {
        if (!cancelled) setError(err.message);
      },
    );

    return () => {
      cancelled = true;
      release();
    };
  }, [enabled, trailId, user]);

  const activeRows = useMemo(() => {
    if (!myUid) return [];
    return rows.filter(
      (r) => r.uid !== myUid && isTrailLivePublicationRideRowFresh(r) && !excludePeerIds.has(r.uid),
    );
  }, [rows, myUid, excludePeerIds]);

  const activeRowsKey = useMemo(
    () =>
      activeRows
        .map((r) => `${r.uid}\0${r.publicationId}\0${r.progressRatio.toFixed(5)}`)
        .sort()
        .join("|"),
    [activeRows],
  );

  useEffect(() => {
    if (!enabled) {
      geomByPublicationRef.current.clear();
      setGeomEpoch((n) => n + 1);
      return;
    }
    if (activeRows.length === 0) return;

    const publicationIds = [...new Set(activeRows.map((r) => r.publicationId))];
    loadMissingPublicationGeometries({
      publicationIds,
      geomByPublication: geomByPublicationRef.current,
      bumpGeomEpoch: () => setGeomEpoch((n) => n + 1),
    });
  }, [enabled, activeRowsKey]);

  useEffect(() => {
    if (!enabled || activeRows.length === 0) return;
    const id = window.setInterval(() => setSpectatorTickMs(Date.now()), 1_000);
    return () => window.clearInterval(id);
  }, [enabled, activeRowsKey]);

  const spectatorDots = useMemo((): TrailSpectatorDot[] => {
    const map = geomByPublicationRef.current;
    const out: TrailSpectatorDot[] = [];
    for (const r of activeRows) {
      /*
       * 맵 점은 **15초** 기준으로 지운다 — `activeRows` 의 240초가 아니다.
       *
       * 여기서 다시 거르는 이유: `activeRows` 는 Firestore 가 새 행을 밀어야 다시 계산된다.
       * 발행이 끊긴 주행은 **영영 다시 계산되지 않아** 그 목록에 남는다. 반면 이 계산은
       * `spectatorTickMs` 로 1초마다 다시 도므로, 시간이 지나면 사라지게 하려면 여기여야 한다.
       * (2026-09-27 실측: 103초 끊긴 주행이 계속 그려짐 → 얼어붙었다가 순간이동)
       */
      if (!isTrailLivePublicationRideRowPeerVisible(r, spectatorTickMs)) continue;
      const g = map.get(r.publicationId);
      if (!g || g.status !== "ready") continue;
      const p = spectatorPointOnRoute(r, g.geometry, spectatorTickMs, { logPt10: true });
      if (p) {
        const who = presenceRiderDisplayName(r.uid, null, r.displayName);
        out.push({
          id: r.uid,
          lngLat: p,
          label: `${trailLabel} · ${who}`,
        });
      }
    }
    return out;
  }, [activeRows, geomEpoch, trailLabel, spectatorTickMs]);

  const livePublicationIds = useMemo(
    () => [...new Set(activeRows.map((r) => r.publicationId.trim()).filter(Boolean))],
    [activeRowsKey],
  );

  const spectatorRouteGeometries = useMemo((): LineStringGeometry[] => {
    const map = geomByPublicationRef.current;
    const maxV = maxLineStringVerticesForMapZoom(mapZoom);
    const seen = new Set<string>();
    const out: LineStringGeometry[] = [];
    for (const r of activeRows) {
      if (seen.has(r.publicationId)) continue;
      seen.add(r.publicationId);
      const g = map.get(r.publicationId);
      if (!g || g.status !== "ready") continue;
      out.push(decimateLineStringVertices(g.geometry, maxV));
    }
    return out;
  }, [activeRows, mapZoom, geomEpoch]);

  return { spectatorDots, spectatorRouteGeometries, livePublicationIds, error };
}
