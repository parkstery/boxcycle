import type { User } from "firebase/auth";
import { getFunctions } from "firebase/functions";
import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type MutableRefObject,
  type SetStateAction,
} from "react";
import { getFirebaseApp } from "../lib/firebase/app";
import type { LineStringGeometry, LngLat } from "../lib/geo/geo";
import { formatLngLat, getDistanceMeters } from "../lib/geo/geo";
import {
  MAX_ROUTE_DISTANCE_KM,
  MAX_ROUTE_STRAIGHT_LINE_METERS,
} from "../lib/route/routeLimits";
import { MAX_ROUTE_WAYPOINTS } from "../lib/geo/routeWaypoints";
import { lockRouteWorkspaceDuringRide } from "../lib/route/routeWorkspaceLock";
import { fetchRouteByProfile, formatDuration, type RouteProfile } from "../services/mapboxDirections";
import { fetchMapboxReverseGeocodePlaceName } from "../services/mapboxReverseGeocode";
import { prewarmRouteFunctions } from "../services/routeFunctionsPrewarm";
import { useVirtualRideSession } from "./useVirtualRideSession";

export type UseRoutePlanningOptions = {
  user: User | null;
  /** 현재 입력 모드(체험 슬라이더 또는 케이던스 센서)가 만든 목표 속도 */
  rideTargetSpeedKmh: number;
  mapboxAccessToken: string;
  functionsRegion: string;
  /** 경로 재계산·핀 클리어 직후 저장 경로 ref·공식 코스 id 등 App 쪽 정리 */
  clearRouteArtifactsRef: MutableRefObject<() => void>;
  /** Directions 실패 시 공식 코스 id 등(저장 경로 ref 는 유지) */
  onRouteDirectionsErrorRef: MutableRefObject<() => void>;
};

/**
 * 출발/도착/경유, OSRM(Mapbox Directions Callable) 경로, 역지오코딩 라벨, 가상 주행 세션.
 */
export function useRoutePlanning(options: UseRoutePlanningOptions) {
  const { user, rideTargetSpeedKmh, mapboxAccessToken, functionsRegion, clearRouteArtifactsRef, onRouteDirectionsErrorRef } =
    options;

  const [startLngLat, setStartLngLat] = useState<LngLat | null>(null);
  const [endLngLat, setEndLngLat] = useState<LngLat | null>(null);
  const [routeWaypoints, setRouteWaypoints] = useState<LngLat[]>([]);
  const geocodeToken = mapboxAccessToken.trim();
  const startPlaceLabel = useReverseGeocodedLabel(startLngLat, geocodeToken);
  const endPlaceLabel = useReverseGeocodedLabel(endLngLat, geocodeToken);
  const waypointPlaceLabels = useReverseGeocodedLabels(routeWaypoints, geocodeToken);

  const [profile, setProfile] = useState<RouteProfile>("cycling");
  /*
   * geometry 와 완료 token 을 한 state 에 둔다. nonnull 설정마다 새 object token
   * (같은 geometry 참조를 다시 골라도). null 이면 token 도 null. token 은 렌더 중 만들지 않는다.
   */
  const [routeGeometryState, setRouteGeometryState] = useState<{
    geometry: LineStringGeometry | null;
    token: object | null;
  }>({ geometry: null, token: null });
  const routeGeometry = routeGeometryState.geometry;
  const routeSetupToken = routeGeometryState.token;
  const setRouteGeometry = useCallback((update: SetStateAction<LineStringGeometry | null>) => {
    setRouteGeometryState((prev) => {
      const nextGeometry = typeof update === "function" ? update(prev.geometry) : update;
      if (nextGeometry == null) {
        if (prev.geometry == null && prev.token == null) return prev;
        return { geometry: null, token: null };
      }
      return { geometry: nextGeometry, token: {} };
    });
  }, []);
  const [routeDistanceMeters, setRouteDistanceMeters] = useState(0);
  const [routeDurationSec, setRouteDurationSec] = useState(0);
  const [routeSummary, setRouteSummary] = useState("");
  const [routeLoading, setRouteLoading] = useState(false);

  const {
    status: rideStatus,
    setStatus: setRideStatus,
    metrics: rideMetrics,
    resetDistances: resetRide,
    syncLiveFromDistance,
    sampleLiveLngLat,
    sampleLiveDistM,
    startOffsetMetersRef,
  } = useVirtualRideSession({
    targetSpeedKmh: rideTargetSpeedKmh,
    routeGeometry,
    routeDistanceMeters,
  });

  // Start 가 찍히면 End·방향을 고르는 사이에 경로 Functions cold start 를 끝내 둔다.
  useEffect(() => {
    if (!startLngLat || !user) return;
    prewarmRouteFunctions(user, "getMapboxDirections", "getDistanceAutoRoute");
  }, [startLngLat, user]);

  const startLabel = !startLngLat
    ? "미설정"
    : startPlaceLabel === null
      ? "주소 불러오는 중…"
      : startPlaceLabel;
  const endLabel = !endLngLat
    ? "미설정"
    : endPlaceLabel === null
      ? "주소 불러오는 중…"
      : endPlaceLabel;

  const waypointLabelsForPanel = useMemo(
    () =>
      routeWaypoints.map((wp, i) => {
        const lab = waypointPlaceLabels[i];
        if (lab === null) return "주소 불러오는 중…";
        if (typeof lab === "string") return lab;
        return formatLngLat(wp);
      }),
    [routeWaypoints, waypointPlaceLabels],
  );

  const generateRoute = useCallback(
    async (profileOverride?: RouteProfile) => {
      if (lockRouteWorkspaceDuringRide(rideStatus !== "idle")) {
        setRouteSummary("세션이 대기 상태일 때만 경로를 바꿀 수 있습니다. 종료 후 다시 시도하세요.");
        return;
      }
      if (!user) {
        setRouteSummary("경로 계산은 로그인(게스트 포함) 후에 사용할 수 있습니다.");
        return;
      }
      const start = startLngLat;
      const end = endLngLat;
      if (!start || !end) {
        setRouteSummary("");
        return;
      }

      // 사전 차단: start→경유→end 직선거리 합이 상한을 넘으면 실제 경로는 반드시 초과한다.
      // Mapbox 호출·토큰 소진 전에 막는다(최종 강제는 서버가 실제 거리로 수행).
      const wpsForCheck = routeWaypoints.slice(0, MAX_ROUTE_WAYPOINTS);
      const pathPoints: LngLat[] = [start, ...wpsForCheck, end];
      let straightLineMeters = 0;
      for (let i = 1; i < pathPoints.length; i++) {
        straightLineMeters += getDistanceMeters(pathPoints[i - 1], pathPoints[i]);
      }
      if (straightLineMeters > MAX_ROUTE_STRAIGHT_LINE_METERS) {
        setRouteSummary(`경로가 너무 깁니다. 최대 ${MAX_ROUTE_DISTANCE_KM}km까지 생성할 수 있습니다.`);
        return;
      }

      const activeProfile = profileOverride ?? profile;

      setRouteLoading(true);
      setRouteSummary("경로 계산 중…");
      try {
        const functions = getFunctions(getFirebaseApp(), functionsRegion);
        const wps = routeWaypoints.slice(0, MAX_ROUTE_WAYPOINTS);
        const requestId =
          typeof crypto !== "undefined" && "randomUUID" in crypto
            ? crypto.randomUUID().replace(/-/g, "")
            : `req_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
        const route = await fetchRouteByProfile(
          functions,
          user,
          start,
          end,
          activeProfile,
          wps.length ? wps : undefined,
          requestId,
        );
        setRouteGeometry(route.geometry);
        setRouteDistanceMeters(route.distance);
        setRouteDurationSec(route.duration);
        const viaNote = wps.length ? ` · 경과 ${wps.length}곳` : "";
        setRouteSummary(
          `거리 ${(route.distance / 1000).toFixed(2)} km / 예상 ${formatDuration(route.duration)}${viaNote}`,
        );
        resetRide();
        clearRouteArtifactsRef.current();
      } catch (e: unknown) {
        const fe = e as { code?: string; message?: string };
        const message =
          typeof fe?.message === "string"
            ? fe.message
            : e instanceof Error
              ? e.message
              : String(e);
        const hint =
          fe?.code === "functions/not-found"
            ? " Cloud Functions 가 배포되지 않았을 수 있습니다. 저장소 루트에서 firebase deploy --only functions 를 실행하고, MAPBOX_ACCESS_TOKEN 시크릿을 설정하세요."
            : "";
        setRouteSummary(message + hint);
        setRouteGeometry(null);
        setRouteDistanceMeters(0);
        setRouteDurationSec(0);
        onRouteDirectionsErrorRef.current();
      } finally {
        setRouteLoading(false);
      }
    },
    [
      rideStatus,
      startLngLat,
      endLngLat,
      routeWaypoints,
      profile,
      resetRide,
      user,
      functionsRegion,
      setRouteGeometry,
    ],
  );

  const clearRoutePins = useCallback(
    (rideLocked: boolean) => {
      if (rideLocked) return;
      setStartLngLat(null);
      setEndLngLat(null);
      setRouteWaypoints([]);
      setRouteGeometry(null);
      setRouteDistanceMeters(0);
      setRouteDurationSec(0);
      setRouteSummary("");
      clearRouteArtifactsRef.current();
    },
    [setRouteGeometry],
  );

  const applyRouteProfileFromMapPopup = useCallback(
    (rideLocked: boolean, p: RouteProfile) => {
      if (rideLocked) return;
      setProfile(p);
      void generateRoute(p);
    },
    [generateRoute],
  );

  return {
    startLngLat,
    setStartLngLat,
    endLngLat,
    setEndLngLat,
    routeWaypoints,
    setRouteWaypoints,
    profile,
    setProfile,
    routeGeometry,
    setRouteGeometry,
    routeSetupToken,
    routeDistanceMeters,
    setRouteDistanceMeters,
    routeDurationSec,
    setRouteDurationSec,
    routeSummary,
    setRouteSummary,
    routeLoading,
    setRouteLoading,
    rideStatus,
    setRideStatus,
    rideMetrics,
    resetRide,
    syncLiveFromDistance,
    sampleLiveLngLat,
    sampleLiveDistM,
    startOffsetMetersRef,
    startLabel,
    endLabel,
    startPlaceLabel,
    endPlaceLabel,
    waypointLabelsForPanel,
    generateRoute,
    clearRoutePins,
    applyRouteProfileFromMapPopup,
  };
}

/** 역지오코딩 결과 — 어느 입력의 결과인지(key) 함께 둬서, 입력이 바뀌면 렌더에서 「불러오는 중」(null)으로 본다. */
type ResolvedLabels<T> = { key: string; value: T };

/**
 * 좌표 하나의 주소 라벨. null = 미설정 또는 불러오는 중(호출부가 lngLat 로 구분).
 * 토큰이 없으면 좌표 문자열.
 */
function useReverseGeocodedLabel(lngLat: LngLat | null, token: string): string | null {
  const key = lngLat ? JSON.stringify(lngLat) : "";
  const [resolved, setResolved] = useState<ResolvedLabels<string> | null>(null);

  useEffect(() => {
    if (!lngLat || !token) return;
    const ac = new AbortController();
    void (async () => {
      let label: string;
      try {
        const name = await fetchMapboxReverseGeocodePlaceName(lngLat, token, ac.signal);
        label = (name && name.trim()) || formatLngLat(lngLat);
      } catch {
        label = formatLngLat(lngLat);
      }
      if (ac.signal.aborted) return;
      setResolved({ key, value: label });
    })();
    return () => ac.abort();
  }, [lngLat, key, token]);

  if (!lngLat) return null;
  if (!token) return formatLngLat(lngLat);
  return resolved?.key === key ? resolved.value : null;
}

/** 경유지 주소 라벨 — 항목별 null = 불러오는 중. */
function useReverseGeocodedLabels(points: LngLat[], token: string): (string | null)[] {
  const key = JSON.stringify(points);
  const [resolved, setResolved] = useState<ResolvedLabels<string[]> | null>(null);

  useEffect(() => {
    if (points.length === 0 || !token) return;
    const ac = new AbortController();
    void (async () => {
      const labels = await Promise.all(
        points.map(async (wp) => {
          try {
            const name = await fetchMapboxReverseGeocodePlaceName(wp, token, ac.signal);
            return (name && name.trim()) || formatLngLat(wp);
          } catch {
            return formatLngLat(wp);
          }
        }),
      );
      if (ac.signal.aborted) return;
      setResolved({ key, value: labels });
    })();
    return () => ac.abort();
  }, [points, key, token]);

  if (points.length === 0) return [];
  if (!token) return points.map(formatLngLat);
  return resolved?.key === key ? resolved.value : points.map(() => null);
}
