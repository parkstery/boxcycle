import type { LngLat, LineStringGeometry } from "../../lib/geo/geo";
import {
  distanceOnRouteByProjectedPoint,
  getDistanceMeters,
  headingAtRouteDistanceMeters,
  headingOnRouteAtPoint,
  type LineStringGeometry as RouteLineStringGeometry,
} from "../../lib/geo/geo";
import type { FollowMode } from "../../lib/map/mapGlobeView";
import { resolveRideCameraPitchClose } from "../../lib/map/mapGlobeView";
import {
  computeRideFollowFraming,
  RIDE_FOLLOW_NO_PADDING,
  viewportPxFromMap,
} from "../../lib/camera/rideCameraFraming";
import type { RideSpanFloorMode } from "../../lib/camera/rideCameraFraming";
import {
  noteFollowJumpTo,
  noteHeadingFromMove,
} from "../../lib/debug/mapTickProbe";
import {
  beginFollowCameraJump,
  endFollowCameraJump,
} from "./followCameraJump";
import { noteFollowJumpToValues } from "../../lib/camera/cameraFollowTrace";
import { noteCameraWrite } from "../../lib/camera/cameraRenderPhase";
import {
  getQuickCameraProductTune,
  type QuickCameraSlot,
} from "../../lib/camera/quickCameraProductTune";
import { getRideCameraLabOverride } from "../../lib/debug/rideCameraLab";
import { type LiveRiderMotion } from "./mapViewTypes";

const CAMERA_POSITION_TAU_SEC = 0.1;
const CAMERA_BEARING_TAU_PRIMARY_SEC = 0.2;
const CAMERA_BEARING_TAU_SECONDARY_SEC = 0.45;
const CAMERA_BEARING_MAX_DPS_PRIMARY = 280;
const CAMERA_BEARING_MAX_DPS_SECONDARY = 170;
const CAMERA_MAX_DT_MS = 50;
export const CAMERA_BEARING_WINDOW_METERS = 60;
export const CAMERA_BEARING_WINDOW_SAMPLES = 60;

/**
 * 팔로우 모드별 카메라 목표값 — 라이더 밀착(레이싱 게임) 프리셋.
 * bearing: 카메라가 바라보는 방향. offsetBearing: 카메라를 라이더로부터 미는 방향
 * (= bearing 의 반대쪽 — 라이더가 화면에 잡히도록). distanceM: 라이더~카메라 거리(m).
 * pitch 는 enable3D 에 재종속 — 3D(terrain) 에선 밀착 고정값(72/78), 2D(탑다운 평면)에선
 * RIDE_CAMERA_PITCH_FLAT(30, 약간 기울인 추적뷰) 로 완전히 다르게 준다. 2D 에서 72~78° 를 강제하면
 * terrain 없이 지도만 눕게 되어 거리감이 깨진다(회귀 원인) — enable3D=false 일 때 절대 밀착 pitch 쓰지 말 것.
 * north 는 거리 개념이 없어 distanceM=0(라이더 중앙, 기존 pitch 유지, enable3D 무관). free 는 호출부에서 early return.
 */
export function getCameraForFollowMode(input: {
  mode: FollowMode;
  baseHeading: number;
  currentPitch: number;
  distanceM: number;
}): { bearing: number; offsetBearing: number | null; pitch: number; distanceM: number } {
  // 밀착 4방향은 3D(terrain) 유무와 무관하게 준수평 추적 — GoPro/레이싱 뷰.
  // 2D 에선 terrain 이 없어 지도가 눕지만, 이는 라이더 밀착 체험을 위해 의도된 것.
  // maxPitch(85) 아래 resolveRideCameraPitchClose(확정 80, ?ridePitch=<deg> 캡처 유지).
  const pitchClose = resolveRideCameraPitchClose();
  const pitchRear = pitchClose;
  const pitchFront = pitchClose;
  const pitchSide = pitchClose;

  if (input.mode === "topDown") {
    // 상공 수직 — 라이더를 화면 중앙에 두고 진행 방향을 위로. 거리 개념 없음(줌은 앱 상태).
    return {
      bearing: normalizeCompass(input.baseHeading),
      offsetBearing: null,
      pitch: 0,
      distanceM: 0,
    };
  }
  if (input.mode === "aerial") {
    const bearing = normalizeCompass(input.baseHeading);
    return {
      bearing,
      offsetBearing: normalizeCompass(bearing + 180),
      pitch: 0,
      distanceM: input.distanceM > 0 ? input.distanceM : 60,
    };
  }
  if (input.mode === "north") {
    return { bearing: 0, offsetBearing: null, pitch: input.currentPitch, distanceM: 0 };
  }
  if (input.mode === "forward") {
    const bearing = normalizeCompass(input.baseHeading);
    return { bearing, offsetBearing: normalizeCompass(bearing + 180), pitch: pitchRear, distanceM: input.distanceM };
  }
  if (input.mode === "backward") {
    const bearing = normalizeCompass(input.baseHeading + 180);
    return { bearing, offsetBearing: normalizeCompass(bearing + 180), pitch: pitchFront, distanceM: input.distanceM };
  }
  if (input.mode === "right") {
    const bearing = normalizeCompass(input.baseHeading + 270);
    return { bearing, offsetBearing: normalizeCompass(bearing + 180), pitch: pitchSide, distanceM: input.distanceM };
  }
  if (input.mode === "left") {
    const bearing = normalizeCompass(input.baseHeading + 90);
    return { bearing, offsetBearing: normalizeCompass(bearing + 180), pitch: pitchSide, distanceM: input.distanceM };
  }
  return { bearing: normalizeCompass(input.baseHeading), offsetBearing: null, pitch: input.currentPitch, distanceM: 0 };
}

function normalizeCompass(deg: number) {
  let x = deg % 360;
  if (x < 0) x += 360;
  return x;
}

export { offsetLngLatByBearingMeters } from "../../lib/geo/geo";

export function getAverageHeadingAheadFromPoint(
  geometry: RouteLineStringGeometry | null,
  point: LngLat,
  windowMeters: number,
  samples: number,
): number | null {
  if (!geometry || geometry.coordinates.length < 2) return null;
  const currentDistance = distanceOnRouteByProjectedPoint(geometry, point);
  if (currentDistance == null) return headingOnRouteAtPoint(geometry, point);
  if (windowMeters <= 0 || samples <= 0) {
    return headingAtRouteDistanceMeters(geometry, currentDistance);
  }

  let sumX = 0;
  let sumY = 0;
  for (let i = 1; i <= samples; i += 1) {
    const ahead = headingAtRouteDistanceMeters(
      geometry,
      currentDistance + (windowMeters * i) / samples,
    );
    if (ahead == null) continue;
    const rad = (ahead * Math.PI) / 180;
    sumX += Math.cos(rad);
    sumY += Math.sin(rad);
  }
  if (sumX === 0 && sumY === 0) return null;
  let deg = (Math.atan2(sumY, sumX) * 180) / Math.PI;
  if (deg < 0) deg += 360;
  return deg;
}

export function resetCameraSmoothing(
  state: {
    center: LngLat | null;
    bearingPrimary: number | null;
    bearing: number | null;
    pitch: number | null;
    zoom: number | null;
    lastTs: number | null;
  },
  map: mapboxgl.Map,
) {
  const c = map.getCenter();
  state.center = [c.lng, c.lat];
  state.bearing = map.getBearing();
  state.bearingPrimary = map.getBearing();
  state.pitch = map.getPitch();
  state.zoom = map.getZoom();
  state.lastTs = null;
}

/** 팔로우 모드 카메라 — rAF 매 프레임 (React liveLngLat 200ms throttle 우회) */
export function shouldSyncMapZoomToApp(
  session: LiveRiderMotion["sessionStatus"] | undefined,
  followMode: FollowMode,
): boolean {
  return !((session === "running" || session === "paused") && followMode !== "free");
}

export function tickRideCameraFollow(
  map: mapboxgl.Map,
  targetLngLat: LngLat,
  opts: {
    followMode: FollowMode;
    mapZoom: number;
    /** 주행 카메라 라이더~카메라 거리(m) — 개발용 거리 슬라이더, 최적값 확정 후 제거 예정 */
    rideCameraDistanceM: number;
    /**
     * Quick Camera 6(북향 밀착) — 진행 heading 대신 이 값을 baseHeading 으로 고정.
     * null 이면 기존 move→route→map 우선순위.
     */
    lockBaseHeading?: number | null;
    /** 활성 QC 슬롯 — 제품 튜닝표(`quickCameraProductTune`) 조회용 */
    activeQuickCamera?: QuickCameraSlot | null;
    /** B1 — 사용자 줌 역산 거리면 floor 생략 */
    spanFloorMode?: RideSpanFloorMode;
    sessionStatus?: LiveRiderMotion["sessionStatus"];
    routeGeometry: LineStringGeometry | null;
    prevLiveRef: { current: LngLat | null };
    smooth: {
      center: LngLat | null;
      bearingPrimary: number | null;
      bearing: number | null;
      pitch: number | null;
      zoom: number | null;
      lastTs: number | null;
    };
    suppressUntilMs: number;
    nowMs: number;
  },
): void {
  if (opts.nowMs < opts.suppressUntilMs) return;

  if (opts.followMode === "free") {
    opts.prevLiveRef.current = targetLngLat;
    return;
  }

  const prev = opts.prevLiveRef.current;
  const stepM = prev ? getDistanceMeters(prev, targetLngLat) : 0;
  const headingFromMove = prev && stepM >= 2 ? getBearing(prev, targetLngLat) : null;
  noteHeadingFromMove(stepM, headingFromMove != null);
  const headingFromRoute = getAverageHeadingAheadFromPoint(
    opts.routeGeometry,
    targetLngLat,
    CAMERA_BEARING_WINDOW_METERS,
    CAMERA_BEARING_WINDOW_SAMPLES,
  );
  const baseHeading =
    opts.lockBaseHeading != null && Number.isFinite(opts.lockBaseHeading)
      ? opts.lockBaseHeading
      : (headingFromMove ?? headingFromRoute ?? map.getBearing());
  const nextCamera = getCameraForFollowMode({
    mode: opts.followMode,
    baseHeading,
    currentPitch: map.getPitch(),
    distanceM: opts.rideCameraDistanceM,
  });

  // 제품 QC 튜닝 → camlab 순. Follow 스키마만(FreeCamera 없음).
  // productTune 거리는 명시적 userZoom 이 있으면 덮지 않는다. camlab 은 거리 포함 전원 우선.
  const productTune = getQuickCameraProductTune(opts.activeQuickCamera ?? null);
  const lab = getRideCameraLabOverride();
  let targetBearing = nextCamera.bearing;
  let targetOffsetBearing = nextCamera.offsetBearing;
  let targetPitch = nextCamera.pitch;
  let targetDistanceM = nextCamera.distanceM;
  let lookAtAlongExtraM = 0;
  let screenAnchor: number | undefined;
  if (lab) {
    targetDistanceM = lab.distanceM;
    targetPitch = lab.pitchDeg;
    targetBearing = normalizeCompass(nextCamera.bearing + lab.bearingOffsetDeg);
    if (targetOffsetBearing != null) {
      targetOffsetBearing = normalizeCompass(targetBearing + 180);
    }
    lookAtAlongExtraM = lab.lookAtAlongExtraM;
    screenAnchor = lab.screenAnchor;
  } else if (productTune) {
    if (opts.spanFloorMode !== "userZoom") {
      targetDistanceM = productTune.distanceM;
    }
    targetPitch = productTune.pitchDeg;
    targetBearing = normalizeCompass(nextCamera.bearing + productTune.bearingOffsetDeg);
    if (targetOffsetBearing != null) {
      targetOffsetBearing = normalizeCompass(targetBearing + 180);
    }
    lookAtAlongExtraM = productTune.lookAtAlongExtraM;
    screenAnchor = productTune.screenAnchor;
  }

  opts.prevLiveRef.current = targetLngLat;
  const smooth = opts.smooth;
  if (
    !smooth.center ||
    smooth.bearing == null ||
    smooth.bearingPrimary == null ||
    smooth.pitch == null ||
    smooth.zoom == null
  ) {
    resetCameraSmoothing(smooth, map);
  }

  const dtMs = smooth.lastTs == null ? 0 : opts.nowMs - smooth.lastTs;
  smooth.lastTs = opts.nowMs;
  const dtSec = clamp(dtMs, 0, CAMERA_MAX_DT_MS) / 1000;
  const alphaPos = dampAlpha(dtSec, CAMERA_POSITION_TAU_SEC);
  const alignCam = true;
  const snapLab = lab != null;
  const alphaCenter = alignCam || snapLab ? 1 : alphaPos;
  const alphaBearingPrimary = snapLab ? 1 : dampAlpha(dtSec, CAMERA_BEARING_TAU_PRIMARY_SEC);
  const alphaBearingSecondary = snapLab ? 1 : dampAlpha(dtSec, CAMERA_BEARING_TAU_SECONDARY_SEC);
  const maxStepPrimary = snapLab ? 360 : CAMERA_BEARING_MAX_DPS_PRIMARY * dtSec;
  const maxStepSecondary = snapLab ? 360 : CAMERA_BEARING_MAX_DPS_SECONDARY * dtSec;

  const curPitch = smooth.pitch ?? map.getPitch();
  const curZoom = smooth.zoom ?? map.getZoom();
  const curBearingPrimary = smooth.bearingPrimary ?? map.getBearing();
  const curBearing = smooth.bearing ?? map.getBearing();

  const nextBearingPrimary = lerpAngle(
    curBearingPrimary,
    targetBearing,
    alphaBearingPrimary,
    maxStepPrimary,
  );
  const nextBearing = lerpAngle(
    curBearing,
    nextBearingPrimary,
    alphaBearingSecondary,
    maxStepSecondary,
  );

  const offsetForFraming =
    targetOffsetBearing == null
      ? null
      : alignCam || snapLab
        ? normalizeCompass(nextBearing + 180)
        : targetOffsetBearing;

  const vp = viewportPxFromMap(map);
  const framing = computeRideFollowFraming({
    riderLngLat: targetLngLat,
    offsetBearing: offsetForFraming,
    distanceM: targetDistanceM,
    pitchDeg: targetPitch,
    viewportWidthPx: vp.width,
    viewportHeightPx: vp.height,
    fallbackZoom: opts.mapZoom,
    screenUpBearing: nextBearing,
    spanFloorMode: opts.spanFloorMode ?? "preset",
    lookAtAlongExtraM,
    screenAnchor,
  });
  const cameraCenterTarget = framing.center;
  const followZoom = framing.zoom;

  const curCenter = smooth.center ?? cameraCenterTarget;
  const nextCenter: LngLat = [
    lerp(curCenter[0], cameraCenterTarget[0], alphaCenter),
    lerp(curCenter[1], cameraCenterTarget[1], alphaCenter),
  ];
  const nextPitch = lerp(curPitch, targetPitch, snapLab ? 1 : alphaPos);
  const nextZoom = lerp(curZoom, followZoom, snapLab ? 1 : alphaPos);

  smooth.center = nextCenter;
  smooth.pitch = nextPitch;
  smooth.zoom = nextZoom;
  smooth.bearingPrimary = nextBearingPrimary;
  smooth.bearing = nextBearing;

  applyFollowCameraJumpTo(map, {
    center: nextCenter,
    bearing: nextBearing,
    pitch: nextPitch,
    zoom: nextZoom,
    riderLngLat: targetLngLat,
    t: opts.nowMs,
    stopFirst: true,
  });
}

export type FollowCameraJump = {
  center: LngLat;
  bearing: number;
  pitch: number;
  zoom: number;
  riderLngLat: LngLat;
  t: number;
  stopFirst?: boolean;
};

/**
 * 팔로우 중 래스터(위성) 픽셀 정렬 끄기.
 *
 * Mapbox 는 `isMoving()` 이 거짓이면 래스터 타일을 **정수 픽셀에 스냅**해 그린다(선명도용,
 * `transform.alignedProjMatrix`). 팔로우 카메라는 매 프레임 `jumpTo` 라 `isMoving()` 이 늘
 * 거짓이다 — 위성 사진만 1px 계단으로 움직이고 경로선·마커는 매끄럽게 미끄러져, 사진이
 * 떨려 보인다. 벡터 지도(Outdoors)는 스냅이 없어 멀쩡하다. pitch 0(QC1 상공)에서 가장 잘 보인다.
 *
 * `isMoving` 을 속이면 `idle` 이 끊겨 스타일 재시도가 죽으므로, 행렬 선택만 바꾼다:
 * 최근 팔로우 jumpTo 가 있으면 `aligned` 요청을 무시한다. 멈추면 원래대로 선명하게 스냅.
 */
const FOLLOW_RASTER_UNALIGNED_MS = 250;

type RasterAlignTransform = {
  calculateProjMatrix?: (tileId: unknown, aligned?: boolean, expanded?: boolean) => unknown;
  __rtwFollowJumpAt?: number;
  __rtwRasterAlignPatched?: boolean;
};

function markFollowJumpForRasterAlign(map: mapboxgl.Map): void {
  const t = (map as unknown as { transform?: RasterAlignTransform }).transform;
  if (!t || typeof t.calculateProjMatrix !== "function") return;
  t.__rtwFollowJumpAt = performance.now();
  if (t.__rtwRasterAlignPatched) return;
  const original = t.calculateProjMatrix;
  t.calculateProjMatrix = function (this: RasterAlignTransform, tileId, aligned, expanded) {
    const following =
      this.__rtwFollowJumpAt != null && performance.now() - this.__rtwFollowJumpAt < FOLLOW_RASTER_UNALIGNED_MS;
    return original.call(this, tileId, aligned && !following, expanded);
  };
  t.__rtwRasterAlignPatched = true;
}

/** jumpTo 직전 계측 + 적용. */
export function applyFollowCameraJumpTo(map: mapboxgl.Map, jump: FollowCameraJump): void {
  noteFollowJumpToValues(jump);
  markFollowJumpForRasterAlign(map);
  noteCameraWrite({
    t: jump.t,
    center: jump.center,
    zoom: jump.zoom,
    bearing: jump.bearing,
  });
  if (jump.stopFirst) map.stop();
  beginFollowCameraJump();
  noteFollowJumpTo();
  try {
    const pad = map.getPadding();
    const hasPadding = pad.top !== 0 || pad.bottom !== 0 || pad.left !== 0 || pad.right !== 0;
    map.jumpTo({
      center: jump.center,
      bearing: jump.bearing,
      pitch: jump.pitch,
      zoom: jump.zoom,
      ...(hasPadding ? { padding: RIDE_FOLLOW_NO_PADDING } : {}),
    });
  } finally {
    endFollowCameraJump();
  }
}

function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

function normalizeAngle(angle: number) {
  let n = angle % 360;
  if (n > 180) n -= 360;
  if (n < -180) n += 360;
  return n;
}

function shortestAngleDelta(from: number, to: number) {
  return normalizeAngle(to - from);
}

function lerpAngle(from: number, to: number, t: number, maxStep: number) {
  const delta = shortestAngleDelta(from, to);
  const stepped = clamp(delta * t, -maxStep, maxStep);
  return normalizeAngle(from + stepped);
}

function dampAlpha(dtSec: number, tauSec: number) {
  if (tauSec <= 0 || dtSec <= 0) return 0;
  return 1 - Math.exp(-dtSec / tauSec);
}

export function getBearing(a: LngLat, b: LngLat): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const toDeg = (rad: number) => (rad * 180) / Math.PI;
  const dLng = toRad(b[0] - a[0]);
  const lat1 = toRad(a[1]);
  const lat2 = toRad(b[1]);
  const y = Math.sin(dLng) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

export function apply3DState(
  map: mapboxgl.Map,
  enabled: boolean,
  buildingLayerId: string,
  terrainSourceId: string,
  options?: { flatFallback?: boolean; preserveCamera?: boolean },
) {
  try {
  if (!enabled) {
    map.setTerrain(null);
    if (map.getLayer(buildingLayerId)) map.removeLayer(buildingLayerId);
    // pitch→0 만 — 주행 종료 정북은 lib/map/rideEndNorthUp.easeMapNorthUpAfterRideEnd.
    // 여기서 bearing 을 넣으면 3D 토글마다 북향이 강제된다.
    // 이미 2D인 초기 지도에서 easeTo를 호출하면 진행 중인 위치 flyTo까지 취소된다.
    if (Math.abs(map.getPitch()) > 0.01) map.easeTo({ pitch: 0, duration: 400 });
    return;
  }

  if (!map.getSource(terrainSourceId)) {
    map.addSource(terrainSourceId, {
      type: "raster-dem",
      url: "mapbox://mapbox.terrain-rgb",
      tileSize: 512,
      maxzoom: 14,
    });
  }
  map.setTerrain({ source: terrainSourceId, exaggeration: options?.flatFallback ? 0 : 1.3 });
  if (options?.flatFallback) {
    if (map.getLayer(buildingLayerId)) map.removeLayer(buildingLayerId);
    return;
  }
  if (!map.getLayer(buildingLayerId)) {
    let symbolLayer: { id: string } | undefined;
    try {
      const layers = map.getStyle()?.layers ?? [];
      symbolLayer = layers.find((layer) => layer.type === "symbol" && layer.layout?.["text-field"]);
    } catch {
      return;
    }
    map.addLayer(
      {
        id: buildingLayerId,
        source: "composite",
        "source-layer": "building",
        filter: ["==", "extrude", "true"],
        type: "fill-extrusion",
        minzoom: 15,
        paint: {
          "fill-extrusion-color": "#cbd5e1",
          "fill-extrusion-height": ["get", "height"],
          "fill-extrusion-base": ["get", "min_height"],
          "fill-extrusion-opacity": 0.65,
        },
      },
      symbolLayer?.id,
    );
  }
  if (!options?.preserveCamera && map.getPitch() < 35) {
    map.easeTo({ pitch: 60, bearing: map.getBearing(), duration: 450 });
  }
  } catch (err) {
    console.warn("[map] apply3DState failed", err);
  }
}
