import { startTransition, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { ActivityWorldMapDot, ActivityWorldMapRoute } from "../lib/activity/activityWorldLod";
import {
  ACTIVITY_TRACE_LIVE_STRENGTH,
  resolveHeatTraceStrength,
} from "../lib/activity/activityWorldTraceStyle";
import type { LngLat } from "../lib/geo/geo";
import {
  BASIC_SHARED_HUB_IDS,
  boundsCenterLngLat,
  fetchCourseBounds,
  fetchCourseRoutePayload,
  getBasicHubCourseBounds,
  getBasicHubCoursePayload,
} from "../lib/route/repo/firestoreCourses";
import {
  fetchRouteActivitiesBatch,
  heatVisualWeight,
  isRouteActivityHeat,
  isRouteActivityLive,
  type RouteActivitySnapshot,
} from "../lib/activity/repo/firestoreRouteActivity";
import type { LineStringGeometry } from "../lib/geo/geo";
import { decimateLineStringVertices, maxLineStringVerticesForMapZoom } from "../lib/geo/geoDecimate";
import { resolveActivityWorldDotLngLat } from "../lib/activity/activityWorldAnchor";
import type { RouteActivityMapOverlay } from "./useRouteActivityMapOverlay";

const MAX_LIVE_MAP_OVERLAY = 10;
const MAX_HEAT_MAP_OVERLAY = 10;

type GeomEntry =
  | { status: "ready"; geometry: LineStringGeometry }
  | { status: "loading" }
  | { status: "missing" };

type BoundsEntry =
  | { status: "ready"; lngLat: LngLat }
  | { status: "loading" }
  | { status: "missing" };

export type PublishedCoursesActivityOverlayStats = {
  boundsReady: number;
  geometryReady: number;
  boundsLoading: number;
  geometryLoading: number;
  activityRows: number;
  liveCandidates: number;
  heatCandidates: number;
  /** live/heat 후보인데 앵커 좌표 없음 (`courses`·bounds·liveAnchor) */
  anchorMissing: number;
};

type UsePublishedCoursesActivityMapOverlayOpts = {
  publicationIds: readonly string[];
  excludePublicationId: string | null;
  mapZoom: number;
  enabled: boolean;
  /** false면 aggregate만 조회 — dot/line·geometry 로드 생략(publication presence 사용 시) */
  worldMapRenderEnabled?: boolean;
  /** 주행 종료 등 — 즉시 aggregate·bounds 재조회 */
  refreshNonce?: number;
  /** WO-A coordinator — 제공 시 내부 poll 생략 */
  externalSync?: {
    activityByPublicationId: ReadonlyMap<string, RouteActivitySnapshot | null>;
    syncEpoch: number;
  };
};

function scoreLiveActivity(a: RouteActivitySnapshot): number {
  if (a.liveNow) return 1000 + a.activeRiderCount * 10 + a.pulseLevel;
  return 0;
}

function scoreHeatActivity(a: RouteActivitySnapshot): number {
  return a.recentRideCount7d;
}

function selectOverlayCandidateIds(
  map: ReadonlyMap<string, RouteActivitySnapshot | null>,
  excludePublicationId: string,
): string[] {
  const live: [string, RouteActivitySnapshot][] = [];
  const heat: [string, RouteActivitySnapshot][] = [];

  for (const [id, row] of map) {
    if (!row) continue;
    if (isRouteActivityLive(row)) {
      if (id !== excludePublicationId) live.push([id, row]);
      continue;
    }
    if (isRouteActivityHeat(row)) heat.push([id, row]);
  }

  live.sort((a, b) => scoreLiveActivity(b[1]) - scoreLiveActivity(a[1]));
  heat.sort((a, b) => scoreHeatActivity(b[1]) - scoreHeatActivity(a[1]));

  const liveIds = live.slice(0, MAX_LIVE_MAP_OVERLAY).map(([id]) => id);
  const heatIds = heat.slice(0, MAX_HEAT_MAP_OVERLAY).map(([id]) => id);
  return [...new Set([...liveIds, ...heatIds])];
}

function ensureBoundsLoaded(
  cid: string,
  row: RouteActivitySnapshot,
  boundsMap: Map<string, BoundsEntry>,
  onReady: () => void,
): void {
  const existing = boundsMap.get(cid);
  if (existing?.status === "ready" || existing?.status === "loading") return;

  if (row.liveAnchorLngLat) {
    boundsMap.set(cid, { status: "ready", lngLat: row.liveAnchorLngLat });
    onReady();
    return;
  }

  const hubBounds = getBasicHubCourseBounds(cid);
  if (hubBounds) {
    boundsMap.set(cid, { status: "ready", lngLat: boundsCenterLngLat(hubBounds) });
    onReady();
    return;
  }

  boundsMap.set(cid, { status: "loading" });
  void (async () => {
    try {
      const b = await fetchCourseBounds(cid);
      if (b) {
        boundsMap.set(cid, { status: "ready", lngLat: boundsCenterLngLat(b) });
      } else {
        const payload = await fetchCourseRoutePayload(cid);
        const geom = payload?.geometry;
        if (geom?.coordinates?.length) {
          const derived = resolveActivityWorldDotLngLat(row, geom);
          if (derived) {
            boundsMap.set(cid, { status: "ready", lngLat: derived });
          } else {
            boundsMap.set(cid, { status: "missing" });
          }
        } else {
          boundsMap.set(cid, { status: "missing" });
        }
      }
    } catch {
      boundsMap.set(cid, { status: "missing" });
    }
    onReady();
  })();
}

function ensureGeometryLoaded(
  cid: string,
  geomMap: Map<string, GeomEntry>,
  onReady: () => void,
): void {
  const existing = geomMap.get(cid);
  if (existing?.status === "ready" || existing?.status === "loading") return;

  geomMap.set(cid, { status: "loading" });
  const isBasic = (BASIC_SHARED_HUB_IDS as readonly string[]).includes(cid);
  void (async () => {
    try {
      const geometry: LineStringGeometry | null = isBasic
        ? getBasicHubCoursePayload(cid).geometry
        : (await fetchCourseRoutePayload(cid))?.geometry ?? null;
      if (!geometry?.coordinates?.length) {
        geomMap.set(cid, { status: "missing" });
      } else {
        geomMap.set(cid, { status: "ready", geometry });
      }
    } catch {
      geomMap.set(cid, { status: "missing" });
    }
    onReady();
  })();
}

/**
 * 퍼블릭·입문 허브 등 카탈로그 코스 activity aggregate.
 * 라이브·heat 후보 풀 분리 — live 최대 10 + heat 최대 10.
 */
export function usePublishedCoursesActivityMapOverlay(
  opts: UsePublishedCoursesActivityMapOverlayOpts,
): RouteActivityMapOverlay & {
  activityByPublicationId: ReadonlyMap<string, RouteActivitySnapshot | null>;
  overlayStats: PublishedCoursesActivityOverlayStats;
} {
  const { publicationIds, excludePublicationId, mapZoom, enabled, worldMapRenderEnabled = true, refreshNonce = 0, externalSync } = opts;
  const [activityByPublicationId, setActivityByPublicationId] = useState<
    ReadonlyMap<string, RouteActivitySnapshot | null>
  >(() => new Map());
  const [overlayCandidateIds, setOverlayCandidateIds] = useState<string[]>([]);
  const geomByCourseRef = useRef<Map<string, GeomEntry>>(new Map());
  const boundsByCourseRef = useRef<Map<string, BoundsEntry>>(new Map());
  const [geomByCourse, setGeomByCourse] = useState<ReadonlyMap<string, GeomEntry>>(() => new Map());
  const [boundsByCourse, setBoundsByCourse] = useState<ReadonlyMap<string, BoundsEntry>>(() => new Map());
  const bumpOverlay = useRef(() => {
    setGeomByCourse(new Map(geomByCourseRef.current));
    setBoundsByCourse(new Map(boundsByCourseRef.current));
  });

  const publicationIdsKey = useMemo(() => [...new Set(publicationIds)].sort().join(","), [publicationIds]);
  const useExternalSync = externalSync != null;
  const inactive = !enabled || publicationIds.length === 0;
  const [prevInactive, setPrevInactive] = useState(inactive);
  if (inactive !== prevInactive) {
    setPrevInactive(inactive);
    if (inactive) {
      setActivityByPublicationId(new Map());
      setOverlayCandidateIds([]);
      setGeomByCourse(new Map());
      setBoundsByCourse(new Map());
    }
  }
  useLayoutEffect(() => {
    if (!inactive) return;
    geomByCourseRef.current.clear();
    boundsByCourseRef.current.clear();
  }, [inactive]);

  const applyBatchMap = useCallback(
    (map: ReadonlyMap<string, RouteActivitySnapshot | null>) => {
      const exclude = excludePublicationId?.trim() ?? "";
      const candidateIds = worldMapRenderEnabled ? selectOverlayCandidateIds(map, exclude) : [];

      startTransition(() => {
        setActivityByPublicationId(map);
        setOverlayCandidateIds(candidateIds);
      });

      if (!worldMapRenderEnabled) {
        geomByCourseRef.current.clear();
        boundsByCourseRef.current.clear();
        bumpOverlay.current();
        return;
      }

      const keep = new Set(candidateIds);
      const geomMap = geomByCourseRef.current;
      const boundsMap = boundsByCourseRef.current;

      for (const key of [...geomMap.keys()]) {
        if (!keep.has(key)) geomMap.delete(key);
      }
      for (const key of [...boundsMap.keys()]) {
        if (!keep.has(key)) boundsMap.delete(key);
      }

      let kicked = false;
      for (const cid of candidateIds) {
        const row = map.get(cid);
        if (!row) continue;
        ensureBoundsLoaded(cid, row, boundsMap, () => bumpOverlay.current());
        ensureGeometryLoaded(cid, geomMap, () => bumpOverlay.current());
        kicked = true;
      }

      if (kicked) bumpOverlay.current();
    },
    [excludePublicationId, worldMapRenderEnabled],
  );

  useEffect(() => {
    bumpOverlay.current = () => {
      setGeomByCourse(new Map(geomByCourseRef.current));
      setBoundsByCourse(new Map(boundsByCourseRef.current));
    };
  });

  useEffect(() => {
    if (!useExternalSync || !enabled) return;
    applyBatchMap(externalSync.activityByPublicationId);
  }, [useExternalSync, enabled, externalSync?.syncEpoch, externalSync?.activityByPublicationId, applyBatchMap]);

  useEffect(() => {
    if (useExternalSync || !enabled || publicationIds.length === 0) {
      return;
    }

    let cancelled = false;

    const tick = async () => {
      const map = await fetchRouteActivitiesBatch(publicationIds, { refresh: false });
      if (cancelled) return;
      applyBatchMap(map);
    };

    void tick();
    return () => {
      cancelled = true;
    };
  }, [useExternalSync, enabled, publicationIdsKey, publicationIds, applyBatchMap]);

  useEffect(() => {
    if (useExternalSync) return;
    if (!enabled || refreshNonce === 0) return;
    let cancelled = false;
    void (async () => {
      const map = await fetchRouteActivitiesBatch(publicationIds, { refresh: true });
      if (cancelled) return;
      applyBatchMap(map);
    })();
    return () => {
      cancelled = true;
    };
  }, [useExternalSync, refreshNonce, enabled, publicationIdsKey, publicationIds, applyBatchMap]);

  const { overlay, overlayStats } = useMemo(() => {
    if (!worldMapRenderEnabled) {
      return {
        overlay: {
          pulseRoutes: [],
          heatRoutes: [],
          pulseDots: [],
          heatDots: [],
        } satisfies RouteActivityMapOverlay,
        overlayStats: {
          boundsReady: 0,
          geometryReady: 0,
          boundsLoading: 0,
          geometryLoading: 0,
          activityRows: 0,
          liveCandidates: 0,
          heatCandidates: 0,
          anchorMissing: 0,
        } satisfies PublishedCoursesActivityOverlayStats,
      };
    }

    const pulseRoutes: ActivityWorldMapRoute[] = [];
    const heatRoutes: ActivityWorldMapRoute[] = [];
    const pulseDots: ActivityWorldMapDot[] = [];
    const heatDots: ActivityWorldMapDot[] = [];

    const geomMap = geomByCourse;
    const boundsMap = boundsByCourse;

    let boundsReady = 0;
    let geometryReady = 0;
    let boundsLoading = 0;
    let geometryLoading = 0;
    let activityRows = 0;
    let liveCandidates = 0;
    let heatCandidates = 0;
    let anchorMissing = 0;

    for (const cid of overlayCandidateIds) {
      const row = activityByPublicationId.get(cid);
      if (!row) continue;
      if (isRouteActivityLive(row)) liveCandidates += 1;
      else if (isRouteActivityHeat(row)) heatCandidates += 1;
      if (isRouteActivityLive(row) || isRouteActivityHeat(row)) activityRows += 1;

      const b = boundsMap.get(cid);
      if (b?.status === "ready") boundsReady += 1;
      else if (b?.status === "loading") boundsLoading += 1;
      const g = geomMap.get(cid);
      if (g?.status === "ready") geometryReady += 1;
      else if (g?.status === "loading") geometryLoading += 1;

      let lngLat: LngLat | null = row.liveAnchorLngLat;
      if (!lngLat && b?.status === "ready") lngLat = b.lngLat;
      const routeGeometry = g?.status === "ready" ? g.geometry : null;
      if (!lngLat && routeGeometry) {
        lngLat = resolveActivityWorldDotLngLat(row, routeGeometry);
      }
      if (isRouteActivityLive(row) || isRouteActivityHeat(row)) {
        if (!lngLat) anchorMissing += 1;
      }

      if (lngLat) {
        if (isRouteActivityLive(row)) {
          pulseDots.push({
            publicationId: cid,
            lngLat,
            pulseLevel: row.pulseLevel > 0 ? row.pulseLevel : 1,
            kind: "pulse",
            traceStrength: ACTIVITY_TRACE_LIVE_STRENGTH,
          });
        } else if (isRouteActivityHeat(row)) {
          const traceStrength = resolveHeatTraceStrength(row.lastCompletedRideAtMs);
          heatDots.push({
            publicationId: cid,
            lngLat,
            pulseLevel: heatVisualWeight(row.recentRideCount7d),
            kind: "heat",
            recentRideCount7d: row.recentRideCount7d,
            traceStrength,
          });
        }
      }

      if (g?.status === "ready") {
        const line = decimateLineStringVertices(g.geometry, maxLineStringVerticesForMapZoom(mapZoom));
        if (isRouteActivityLive(row)) {
          pulseRoutes.push({
            publicationId: cid,
            geometry: line,
            kind: "pulse",
            traceStrength: ACTIVITY_TRACE_LIVE_STRENGTH,
          });
        } else if (isRouteActivityHeat(row)) {
          heatRoutes.push({
            publicationId: cid,
            geometry: line,
            kind: "heat",
            traceStrength: resolveHeatTraceStrength(row.lastCompletedRideAtMs),
          });
        }
      }
    }

    return {
      overlay: { pulseRoutes, heatRoutes, pulseDots, heatDots } satisfies RouteActivityMapOverlay,
      overlayStats: {
        boundsReady,
        geometryReady,
        boundsLoading,
        geometryLoading,
        activityRows,
        liveCandidates,
        heatCandidates,
        anchorMissing,
      } satisfies PublishedCoursesActivityOverlayStats,
    };
  }, [activityByPublicationId, overlayCandidateIds, mapZoom, geomByCourse, boundsByCourse, worldMapRenderEnabled]);

  return { ...overlay, activityByPublicationId, overlayStats };
}
