import { useRef } from "react";
import type { CalorieIntensityId } from "../../lib/ride/caloriesEstimate";
import { useDialogFocus } from "../ui/useDialogFocus";
import { useEscapeKeyClose } from "../ui/useEscapeKeyClose";
import { RideSettingsPanel } from "./RideSettingsPanel";
import "./RideSettingsSheet.css";
import { SettingsCloseIcon } from "../ui/SettingsCloseIcon";
import type { RideIntervalConfig } from "../../lib/ride/rideInterval";

type RideSettingsSheetProps = {
  open: boolean;
  onClose: () => void;
  rideTtsEnabled: boolean;
  onRideTtsEnabled: (enabled: boolean) => void;
  rideBgmEnabled: boolean;
  onRideBgmEnabled: (enabled: boolean) => void;
  rideCoachingBanner: boolean;
  onRideCoachingBanner: (enabled: boolean) => void;
  pacerEnabled: boolean;
  onPacerEnabled: (enabled: boolean) => void;
  rideBgmCatalogConfigured: boolean;
  rideElevationProfileLoading: boolean;
  calorieWeightKg?: number | null;
  onCalorieWeightKg?: (raw: string) => boolean | void;
  calorieIntensityId?: CalorieIntensityId | null;
  onCalorieIntensityId?: (id: CalorieIntensityId) => boolean | void;
  onEditProfile?: () => void;
  rideIntervalEnabled?: boolean;
  onRideIntervalEnabled?: (enabled: boolean) => void;
  rideIntervalConfig?: RideIntervalConfig;
  onOpenRideIntervalSettings?: () => void;
};

/** 주행·표시 설정 — MENU 와 분리된 하단 시트. 센서는 별도 케이던스 상세 설정이 소유. */
export function RideSettingsSheet(props: RideSettingsSheetProps) {
  const { onClose } = props;
  const panelRef = useRef<HTMLDivElement>(null);
  useDialogFocus(props.open, panelRef);
  useEscapeKeyClose(props.open, onClose);

  if (!props.open) return null;

  return (
    <div className="ride-settings-sheet settings-surface" role="dialog" aria-label="주행 설정">
      <button
        type="button"
        className="ride-settings-sheet__scrim"
        aria-label="닫기"
        title="닫기"
        onClick={props.onClose}
      />
      <div className="ride-settings-sheet__panel settings-surface__panel" ref={panelRef}>
        <div className="ride-settings-sheet__handle" aria-hidden />
        <div className="ride-settings-sheet__head settings-surface__head">
          <h2 className="ride-settings-sheet__title settings-surface__title">주행 설정</h2>
          <button
            type="button"
            className="ride-settings-sheet__close settings-surface__close"
            aria-label="주행 설정 닫기"
            title="닫기"
            onClick={props.onClose}
          >
            <SettingsCloseIcon />
          </button>
        </div>

        <RideSettingsPanel
          rideTtsEnabled={props.rideTtsEnabled}
          onRideTtsEnabled={props.onRideTtsEnabled}
          rideBgmEnabled={props.rideBgmEnabled}
          onRideBgmEnabled={props.onRideBgmEnabled}
          rideCoachingBanner={props.rideCoachingBanner}
          onRideCoachingBanner={props.onRideCoachingBanner}
          pacerEnabled={props.pacerEnabled}
          onPacerEnabled={props.onPacerEnabled}
          rideBgmCatalogConfigured={props.rideBgmCatalogConfigured}
          rideElevationProfileLoading={props.rideElevationProfileLoading}
          calorieWeightKg={props.calorieWeightKg}
          onCalorieWeightKg={props.onCalorieWeightKg}
          calorieIntensityId={props.calorieIntensityId}
          onCalorieIntensityId={props.onCalorieIntensityId}
          onEditProfile={props.onEditProfile}
          rideIntervalEnabled={props.rideIntervalEnabled}
          onRideIntervalEnabled={props.onRideIntervalEnabled}
          rideIntervalConfig={props.rideIntervalConfig}
          onOpenRideIntervalSettings={props.onOpenRideIntervalSettings}
        />
      </div>
    </div>
  );
}
