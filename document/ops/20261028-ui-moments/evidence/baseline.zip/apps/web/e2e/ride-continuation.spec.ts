import { test, expect, type Page } from './open-meteo-stub'
import fs from 'node:fs'
import path from 'node:path'
import { readGuestUid } from './readGuestUid'
import { stubMapboxStyle } from './mapbox-stub'
import { chooseColosseumIfNeeded, guestStart } from './rideEntryHelpers'

// 다음 주행·이어 달리기 e2e(RIDE-CONTINUE-1 §7.3).
// 「어제 멈춘 곳이 오늘 앱을 열었을 때 자동으로 다음 출발점이 된다」를 종료→재진입까지 고정한다.
//
// ⚠ 시나리오 ID 표기 규칙:
//   RC1–RC5 = 이어달리기 e2e 전용 (이름만 비슷할 뿐 §6 C1–C5 와 다른 시나리오)
//   RC13    = §6 C13 e2e 증거 (reload 없이 결과 닫기→다음 주행→Go)
//   CF-LIVE = CF conquestOnRideCreated 에뮬레이터 라이브 (R5/F3) — §6 C14 가 아님
//   §6 C1–C14 전체 매핑: document/archive/260910-RTW-0B-CLOSEOUT-C1-C14-matrix.md
//
// 셀렉터는 scripts/ride-verify/entry-contract.mjs 와 같은 계약을 쓴다 —
// 한쪽만 고치지 않는다(verify-selectors.mjs 가 앵커 실재를 지킨다).
//
// ⚠ Firebase 의존: 게스트 = 실제 signInAnonymously, 경로·Ride = 실제 Firestore.
// `npm run test:e2e:ride-continuation` 이 firebase emulators:exec 로 감싸 실행하며,
// 그 env(FIRESTORE_EMULATOR_HOST) 를 playwright.config 가 감지해 RIDE_VERIFY_LIVE=1 을 켠다.
// RIDE_VERIFY_LIVE=1 을 직접 켜 실 Firebase 에 붙이지 않는다.
const LIVE = process.env.RIDE_VERIFY_LIVE === '1'

const PROJECT_ID = 'boxcycle-dc2df'
const EMULATOR_HOST = process.env.FIRESTORE_EMULATOR_HOST ?? '127.0.0.1:8080'
const DOCS_URL = `http://${EMULATOR_HOST}/v1/projects/${PROJECT_ID}/databases/(default)/documents`

/** 결정적 fixture 경로 — 위도 37.5 를 따라 동쪽으로 뻗는 직선(약 1 km) */
const FIXTURE_POINTS = 11
const FIXTURE_STEP_LNG = 0.00113
const FIXTURE_LAT = 37.5
const FIXTURE_START_LNG = 127.02

function fixtureCoordinates(): [number, number][] {
  const out: [number, number][] = []
  for (let i = 0; i < FIXTURE_POINTS; i += 1) {
    out.push([FIXTURE_START_LNG + i * FIXTURE_STEP_LNG, FIXTURE_LAT])
  }
  return out
}

function haversineMeters(a: [number, number], b: [number, number]): number {
  const toRad = (d: number) => (d * Math.PI) / 180
  const R = 6371000
  const dLat = toRad(b[1] - a[1])
  const dLng = toRad(b[0] - a[0])
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a[1])) * Math.cos(toRad(b[1])) * Math.sin(dLng / 2) ** 2
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h))
}

function fixtureLengthMeters(): number {
  const coords = fixtureCoordinates()
  let sum = 0
  for (let i = 1; i < coords.length; i += 1) sum += haversineMeters(coords[i - 1], coords[i])
  return sum
}

const FIXTURE_LENGTH_M = fixtureLengthMeters()

/** U4 HUD 증거 스크린샷 — Playwright 가 정리해도 남는 고정 경로 */
const U4_HUD_EVIDENCE_PATH = path.resolve(
  process.env.RIDE_CONTINUATION_EVIDENCE_DIR ?? path.resolve(process.cwd(), '../../document/archive/ride-verify-evidence'),
  'u4-hud-resume-dual.png',
)

/** RC1 U6 증거 — 결과 시트를 닫은 직후(reload 없이) 「다음 주행」 카드가 뜬 화면
 *  ⚠ 이 상수는 이어달리기 e2e RC1 시나리오 전용이다 — 원문 §6 C1(서버 저장 응답)과 무관하다. */
const RC1_CARD_NO_RELOAD_EVIDENCE_PATH = path.resolve(
  process.env.RIDE_CONTINUATION_EVIDENCE_DIR ?? path.resolve(process.cwd(), '../../document/archive/ride-verify-evidence'),
  'c1-next-ride-card-no-reload.png',
)

/** RC1 U2·§3.4 증거 — 이어 달리기 준비 상태(완료/남은 구간 + 재개점 마커 + Go)
 *  ⚠ 이어달리기 e2e RC1 시나리오 전용 — 원문 §6 C1 과 무관하다. */
const RC1_RESUME_READY_EVIDENCE_PATH = path.resolve(
  process.env.RIDE_CONTINUATION_EVIDENCE_DIR ?? path.resolve(process.cwd(), '../../document/archive/ride-verify-evidence'),
  'c1-resume-ready-to-start.png',
)

/** 게스트 진입 카드 → 익명 인증 완료 */
async function enterAsGuest(page: Page) {
  await page.goto('/')
  await guestStart(page)
  await chooseColosseumIfNeeded(page, true)
  await expect(page.getByRole('dialog', { name: '어디에서 시작할까요?', exact: true })).toBeHidden()
}

/** 새로고침 뒤 위치 안내를 완료한 다음 지도 조작을 시작한다. */
async function reloadAtDefaultLocation(page: Page) {
  await page.reload()
  await chooseColosseumIfNeeded(page, true)
  await expect(page.getByRole('dialog', { name: '어디에서 시작할까요?', exact: true })).toBeHidden()
}

/** 결과판 내부 닫기만 누른다. 같은 aria-label의 배경 scrim은 선택하지 않는다. */
async function closeRideResult(page: Page) {
  const summary = page.getByRole('region', { name: '주행 결과', exact: true })
  await summary.locator('.ride-summary__close').click({ timeout: 15_000 })
  await expect(summary).toBeHidden({ timeout: 15_000 })
}

/**
 * 주행 입력 준비(Go 사전조건) + 체험 속도 최대치.
 * 자동 E2E 에는 BLE 장치가 없으므로 「센서 없음」를 명시적으로 고른다.
 * 속도를 올리는 건 시험 시간을 줄이기 위함이며, 주행 로직은 동일하다.
 */
async function prepareManualRideInput(page: Page, speedKmh = 50) {
  await page.getByRole('button', { name: /케이던스 센서/ }).click()
  const sheet = page.getByRole('dialog', { name: '케이던스 센서' })
  await expect(sheet).toBeVisible()
  await sheet.getByRole('button', { name: '센서 없음' }).click()
  const speedInput = sheet.getByRole('spinbutton', { name: '속도 km/h' })
  if (await speedInput.count()) {
    await speedInput.fill(String(speedKmh))
    await speedInput.blur()
  }
  await sheet.getByRole('button', { name: '센서 설정 닫기' }).click()
  await expect(sheet).toBeHidden()
}


function doubleArray(v: [number, number]) {
  return { arrayValue: { values: [{ doubleValue: v[0] }, { doubleValue: v[1] }] } }
}

/**
 * 결정적 SavedRoute 를 에뮬레이터에 심는다.
 * `Authorization: Bearer owner` 는 에뮬레이터에서 rules 를 우회하는 표준 방법이다.
 */
async function seedSavedRoute(input: {
  uid: string
  routeId: string
  name: string
  lastProgressRatio: number
  completed?: 0 | 1
}): Promise<void> {
  const coords = fixtureCoordinates()
  const nowIso = new Date().toISOString()
  const body = {
    fields: {
      userId: { stringValue: input.uid },
      name: { stringValue: input.name },
      profile: { stringValue: 'cycling' },
      startLngLat: doubleArray(coords[0]!),
      endLngLat: doubleArray(coords[coords.length - 1]!),
      geometryType: { stringValue: 'LineString' },
      geometryCoordsJson: { stringValue: JSON.stringify(coords) },
      distanceMeters: { doubleValue: FIXTURE_LENGTH_M },
      durationSec: { doubleValue: 300 },
      source: { stringValue: 'web' },
      createdAt: { timestampValue: nowIso },
      updatedAt: { timestampValue: nowIso },
      completed: { integerValue: String(input.completed ?? 0) },
      completedAt: { nullValue: null },
      expiresAt: { timestampValue: new Date(Date.now() + 86400000).toISOString() },
      lastRideId: { nullValue: null },
      lastProgressRatio: { doubleValue: input.lastProgressRatio },
    },
  }
  const res = await fetch(`${DOCS_URL}/savedRoutes?documentId=${input.routeId}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer owner' },
    body: JSON.stringify(body),
  })
  expect(res.ok, `SavedRoute seed 실패: ${res.status} ${await res.text()}`).toBe(true)
}

/** 다른 탭·기기가 진행률을 올린 상황을 흉내내는 out-of-band write */
async function forceSavedRouteProgress(routeId: string, ratio: number): Promise<void> {
  const res = await fetch(
    `${DOCS_URL}/savedRoutes/${routeId}?updateMask.fieldPaths=lastProgressRatio`,
    {
      method: 'PATCH',
      headers: { 'content-type': 'application/json', authorization: 'Bearer owner' },
      body: JSON.stringify({ fields: { lastProgressRatio: { doubleValue: ratio } } }),
    },
  )
  expect(res.ok, `진행률 out-of-band write 실패: ${res.status}`).toBe(true)
}

async function readSavedRoute(routeId: string): Promise<Record<string, unknown>> {
  const res = await fetch(`${DOCS_URL}/savedRoutes/${routeId}`, {
    headers: { authorization: 'Bearer owner' },
  })
  expect(res.ok, `SavedRoute 조회 실패: ${res.status}`).toBe(true)
  const json = (await res.json()) as { fields?: Record<string, unknown> }
  return json.fields ?? {}
}

/** rides/{rideId} 문서를 에뮬레이터에서 직접 읽는다. CF conquestResult 폴링에 사용. */
async function readRide(rideId: string): Promise<Record<string, unknown>> {
  const res = await fetch(`${DOCS_URL}/rides/${rideId}`, {
    headers: { authorization: 'Bearer owner' },
  })
  if (!res.ok) return {}
  const json = (await res.json()) as { fields?: Record<string, unknown> }
  return json.fields ?? {}
}

function fieldNumber(fields: Record<string, unknown>, key: string): number {
  const raw = fields[key] as { doubleValue?: number; integerValue?: string } | undefined
  if (raw?.doubleValue != null) return Number(raw.doubleValue)
  if (raw?.integerValue != null) return Number(raw.integerValue)
  return 0
}

/** 신규 좌표 필드가 없는 옛 Ride — legacy fallback 검증용 */
async function seedLegacyRide(uid: string, rideId: string): Promise<void> {
  const body = {
    fields: {
      userId: { stringValue: uid },
      trailId: { nullValue: null },
      profile: { stringValue: 'cycling' },
      startedAt: { nullValue: null },
      endedAt: { timestampValue: new Date(Date.now() - 86400000).toISOString() },
      elapsedSec: { doubleValue: 900 },
      distanceMeters: { doubleValue: 5200 },
      avgSpeedKmh: { doubleValue: 20.8 },
      caloriesEstimate: { doubleValue: 156 },
      routeDistanceMeters: { doubleValue: 5200 },
      routeDurationSec: { doubleValue: 900 },
      source: { stringValue: 'web' },
      status: { stringValue: 'completed' },
      createdAt: { timestampValue: new Date(Date.now() - 86400000).toISOString() },
      updatedAt: { timestampValue: new Date(Date.now() - 86400000).toISOString() },
      completionRatio: { doubleValue: 0.5 },
    },
  }
  const res = await fetch(`${DOCS_URL}/rides?documentId=${rideId}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: 'Bearer owner' },
    body: JSON.stringify(body),
  })
  expect(res.ok, `legacy ride seed 실패: ${res.status}`).toBe(true)
}

/** MENU → 「내 경로」 칩에서 fixture 를 불러온다(카드가 없는 최초 진입용 경로) */
async function openTrailMenu(page: Page) {
  // Trail 메뉴는 키보드·스크린리더용 고정 트리거다. 포인터 클릭은 실제 HUD가 위에
  // 겹치는 화면에서 막히므로, 제품이 보장하는 focus + Enter 계약으로 연다.
  const menu = page.getByRole('button', { name: 'Trail 메뉴' })
  await menu.focus()
  await expect(menu).toBeFocused({ timeout: 15_000 })
  await page.keyboard.press('Enter')
}

async function loadSavedRouteFromMenu(page: Page, routeName: string, action: '열기' | '이어 달리기' = '열기') {
  await openTrailMenu(page)
  // 2026-09-16: 탭 계층을 없애고 경로 출처 칩 한 줄로 합쳤다.
  // 통합 진입점은 기본으로 「내 경로」를 연다.
  await page.getByRole('button', { name: '경로 선택' }).click()
  const modal = page.getByRole('dialog', { name: '내 경로', exact: true })
  const row = modal.getByRole('option').filter({ hasText: routeName })
  await expect(row).toBeVisible({ timeout: 15_000 })
  await row.click()
  await modal.getByRole('toolbar', { name: '선택한 경로 작업', exact: true })
    .getByRole('button', { name: action, exact: true }).click()
  await expect(modal).toBeHidden()
  await expect(page.getByRole('button', { name: '주행 시작' })).toBeVisible({ timeout: 15_000 })
}

/**
 * HUD 「주행 누적 거리」 — 경로상 누적 km(재개 offset 시드 포함).
 *
 * 2026-09-17 컴팩트 재설계로 **세션 거리 표시가 HUD 에서 사라졌고**(offset 이 없으면 누적과
 * 항상 같은 숫자라 중복이었다), 남은 누적값의 aria-label 도 「누적 진행」 → 「주행 누적 거리」로
 * 바뀌었다. 세션 거리가 필요한 곳은 **주행 시작 시점의 누적을 기준선으로 잡아 빼서** 구한다.
 * 주행 전(route-preview)에는 표시되지 않으므로 -1 을 돌려 폴링이 조기 통과하지 않게 한다.
 */
async function readHudCumulativeKm(page: Page): Promise<number> {
  const cumulative = page.getByLabel('주행 누적 거리')
  if ((await cumulative.count()) === 0) return -1
  const text = await cumulative.first().innerText()
  const km = Number(text.trim().split('/')[0]?.replace(/[^\d.]/g, ''))
  return Number.isFinite(km) ? km : -1
}

/**
 * 목표 세션 거리까지 달린 뒤 종료한다.
 * 고정 sleep 대신 HUD 표시값을 폴링해 램핑·프레임 편차에 흔들리지 않게 한다.
 * `beforeEnd` — 종료 클릭 직전(주행 중 HUD 가 보일 때) 콜백.
 */
async function rideUntilSessionMeters(
  page: Page,
  targetMeters: number,
  beforeEnd?: () => Promise<void>,
) {
  const endButton = page.getByRole('button', { name: '주행 종료' })
  await expect(endButton).toBeVisible({ timeout: 30_000 })
  await expect(page.getByRole('group', { name: '주행 지표' })).toBeVisible({ timeout: 20_000 })
  // 세션 거리는 이제 HUD 에 없다 — 시작 시점 누적을 기준선으로 잡아 그만큼 더 달렸는지 본다.
  const baselineKm = await readHudCumulativeKm(page)
  expect(baselineKm, 'HUD 누적 거리를 읽지 못했다(기준선 없음 → 계측 불가)').toBeGreaterThanOrEqual(0)
  await expect
    .poll(async () => ((await readHudCumulativeKm(page)) - baselineKm) * 1000, {
      timeout: 180_000,
      intervals: [500],
      message: `세션 거리 ${targetMeters}m 에 도달하지 못했다(기준선 ${baselineKm}km)`,
    })
    .toBeGreaterThanOrEqual(targetMeters)
  if (beforeEnd) await beforeEnd()
  await endButton.click()
}

/**
 * 「다음 주행」 카드. 앵커 div(aria-label)·카드 group·숨기기 버튼이 모두 「다음 주행」을 포함하므로
 * 카드 본체(role=group)로 정확히 겨냥한다.
 */
const nextRideCard = (page: Page) => page.getByRole('group', { name: '다음 주행' })

/**
 * 결과 시트의 「끝점에서 새 경로」/「지금 새 경로 연결」 CTA 는 2026-09-17 컴팩트 재설계
 * (Chief 지시)로 시트에서 사라졌다 — 되살리지 않는다. 기능(handleStartRouteFromAnchor,
 * App.tsx)은 그대로 살아 있고, 진입점만 사용자 정보 시트 「최근 주행」 목록의
 * 「여기서 새 경로」(onExtendFromRide, App.tsx 2547행 부근)로 옮겨졌다 — 그 살아있는
 * 진입점을 그대로 쓴다. 목록은 endedAt 내림차순이라 맨 위 행이 방금 종료한 Ride 다.
 * 시트가 전체화면 scrim(z-index 25)으로 HUD 클릭을 막으므로 호출 전에 시트를 닫아 둔다.
 */
async function extendFromRecentRideRow(page: Page) {
  await page.getByRole('button', { name: '사용자 정보' }).click()
  const historyToggle = page.getByRole('button', { name: '마지막 주행' })
  await expect(historyToggle).toBeVisible({ timeout: 15_000 })
  await historyToggle.click()
  const latestRow = page.locator('#user-info-sheet-history-list .user-info-sheet__item').first()
  const extendBtn = latestRow.getByRole('button', { name: '여기서 새 경로' })
  await expect(extendBtn, '최근 주행 최신 행에 「여기서 새 경로」가 없다').toBeVisible({
    timeout: 15_000,
  })
  await extendBtn.click()
}

test.describe('다음 주행 · 이어 달리기', () => {
  test.skip(!LIVE, 'Firebase 에뮬레이터 필요 — npm run test:e2e:ride-continuation')
  // 실제로 경로를 달리는 시험이다(1 km ≈ 80초). 기본 30초 타임아웃으로는 부족하다.
  test.beforeEach(async ({ page }) => {
    test.setTimeout(300_000)
    page.setDefaultTimeout(15_000)
    // Approach B: Mapbox 스타일 URL 을 가로채 최소 유효 JSON 으로 대체.
    // fake pk 환경에서 map.on('load') 가 발화되어 mapLoaded=true 가 되게 한다.
    // Auth / Firestore / Functions 에뮬레이터에는 영향 없음.
    await stubMapboxStyle(page)
  })

  // ── RC1: 이어달리기 e2e — reload 포함 전체 흐름 (원문 §6 C1 과 무관) ──
  test('RC1 — 미완주 SavedRoute 를 종료→재진입→재개까지 이어 달린다', async ({ page }, testInfo) => {
    await enterAsGuest(page)
    const uid = await readGuestUid(page)
    const routeId = `fixture-rc1-${Date.now()}`
    await seedSavedRoute({ uid, routeId, name: 'RC1 이어달리기 픽스처', lastProgressRatio: 0 })

    await reloadAtDefaultLocation(page)
    await prepareManualRideInput(page)
    await loadSavedRouteFromMenu(page, 'RC1 이어달리기 픽스처')

    // 1차 주행 — 전체의 약 20% 지점까지
    await page.getByRole('button', { name: '주행 시작' }).click()
    await rideUntilSessionMeters(page, FIXTURE_LENGTH_M * 0.2)

    // 결과 시트: 전체 진행 0% → N%
    const summary = page.getByRole('region', { name: '주행 결과' })
    await expect(summary).toBeVisible({ timeout: 20_000 })
    // 컴팩트 재설계로 「전체 진행」 문구는 aria-label 로만 남고 화면 텍스트는 "N% → M%" 뿐이다.
    await expect(summary.getByLabel('전체 진행')).toContainText('0% →')
    // 「다음 출발점이 저장되었습니다」 문구는 컴팩트 재설계로 제거됐다(Chief 지시, 되살리지 않는다).
    // 같은 사실(anchor 저장)의 증거는 아래 U6 블록 — reload 없이 뜨는 「다음 주행」 카드로 확인한다.
    await closeRideResult(page)

    /*
     * U6 — **reload 없이** 결과를 닫는 즉시 카드가 나타나야 한다.
     * 실주행 수용 실패의 원인은 stage 충돌이었다: 방금 달린 Route 가 지도에 남아
     * `ready-to-start` 로 머물면 RouteDock 이 Go 를 다시 띄우고 카드는 숨는다.
     * 그래서 「Go 가 없다」까지 함께 단언해 회귀를 고정한다.
     */
    const cardNoReload = nextRideCard(page)
    await expect(cardNoReload).toBeVisible({ timeout: 15_000 })
    await expect(page.getByRole('button', { name: '주행 시작' })).toHaveCount(0)
    await expect(cardNoReload.getByRole('button', { name: /%에서 이어 달리기/ })).toBeVisible({
      timeout: 15_000,
    })
    fs.mkdirSync(path.dirname(RC1_CARD_NO_RELOAD_EVIDENCE_PATH), { recursive: true })
    await page.screenshot({ path: RC1_CARD_NO_RELOAD_EVIDENCE_PATH })
    await page.screenshot({ path: testInfo.outputPath('c1-next-ride-card-no-reload.png') })

    // Firestore 진행률 반영을 기다린 뒤 재진입한다(결과 시트는 로컬 record 낙관 표시라 더 빠르다)
    await expect
      .poll(async () => fieldNumber(await readSavedRoute(routeId), 'lastProgressRatio'), {
        timeout: 30_000,
        message: '1차 주행의 진행률이 서버에 반영되지 않았다',
      })
      .toBeGreaterThan(0)

    // 재진입 — 지도 위 「다음 주행」 카드가 자동으로 뜬다
    await reloadAtDefaultLocation(page)
    const card = nextRideCard(page)
    await expect(card).toBeVisible({ timeout: 30_000 })
    const resumeBtn = card.getByRole('button', { name: /%에서 이어 달리기/ })
    await expect(resumeBtn).toBeVisible()
    const resumeLabel = await resumeBtn.innerText()
    const resumePct = Number(resumeLabel.match(/(\d+)%/)?.[1])
    expect(resumePct, `재개 진행률이 20% 근처가 아니다: ${resumeLabel}`).toBeGreaterThanOrEqual(15)

    // CTA 는 ready-to-start 까지만 만든다 — 실제 시작은 기존 Go 게이트
    await resumeBtn.click()
    const start = page.getByRole('button', { name: '주행 시작' })
    await expect(start).toBeVisible({ timeout: 20_000 })
    await expect(page.getByText(`${resumePct}%부터`)).toBeVisible()
    // §3.4 — 완료 구간·남은 구간·재개점 마커가 함께 보이는 준비 화면을 증거로 남긴다.
    await expect(page.locator('.map-view__resume-marker')).toBeVisible({ timeout: 15_000 })
    await page.screenshot({ path: RC1_RESUME_READY_EVIDENCE_PATH })
    await page.screenshot({ path: testInfo.outputPath('c1-resume-ready-to-start.png') })

    // 입력 준비 후 Go — 재개 주행은 세션 구간만 인정된다
    await prepareManualRideInput(page)
    await expect(start).toBeEnabled()
    await start.click()
    await expect(page.getByRole('group', { name: '주행 지표' })).toBeVisible({ timeout: 20_000 })
    await expect(page.getByLabel('주행 누적 거리')).toBeVisible()
    // 세션 거리 별도 표기는 2026-09-17 에 폐기됐다(U4 이중 표기 뒤집음) — 되살아나면 잡는다.
    await expect(page.getByLabel('오늘 거리')).toHaveCount(0)
    const resumeOffsetM = FIXTURE_LENGTH_M * (resumePct / 100)
    // HUD 누적은 재개 지점(offset)부터 시작한다 — 이게 「이어 달리기」의 핵심 증거다.
    await expect
      .poll(async () => readHudCumulativeKm(page), {
        timeout: 15_000,
        message: '재개 직후 HUD 누적 위치가 offset 시드에 맞지 않다',
      })
      .toBeGreaterThanOrEqual((resumeOffsetM * 0.85) / 1000)
    // 재개 직후 「이번에 달린 거리」는 0 근처다 — 표시가 없으므로 누적 기준선으로 확인한다.
    const resumeBaselineKm = await readHudCumulativeKm(page)

    await rideUntilSessionMeters(page, FIXTURE_LENGTH_M * 0.17, async () => {
      const cumulativeKm = await readHudCumulativeKm(page)
      const sessionKm = cumulativeKm - resumeBaselineKm
      expect(cumulativeKm, '누적 위치가 세션 거리보다 작다').toBeGreaterThan(sessionKm)
      expect(resumeBaselineKm, '재개 기준선이 offset 시드에 못 미친다').toBeGreaterThanOrEqual(
        (resumeOffsetM * 0.85) / 1000,
      )
      fs.mkdirSync(path.dirname(U4_HUD_EVIDENCE_PATH), { recursive: true })
      await page.screenshot({ path: U4_HUD_EVIDENCE_PATH })
      await page.screenshot({ path: testInfo.outputPath('u4-hud-resume-dual.png') })
    })

    const summary2 = page.getByRole('region', { name: '주행 결과' })
    await expect(summary2).toBeVisible({ timeout: 20_000 })
    const progressText = await summary2.getByLabel('전체 진행').innerText()
    const [fromPct, toPct] = (progressText.match(/(\d+)%/g) ?? []).map((v) => Number(v.replace('%', '')))
    expect(fromPct, `이전 진행률이 재개 지점과 다르다: ${progressText}`).toBe(resumePct)
    expect(toPct, `누적 진행률이 늘지 않았다: ${progressText}`).toBeGreaterThan(resumePct)

    // 서버 문서도 누적 진행률로 올라간다.
    // 결과 시트는 로컬 record 로 낙관 표시되므로 Firestore 반영은 조금 뒤에 온다 — 폴링한다.
    await expect
      .poll(async () => fieldNumber(await readSavedRoute(routeId), 'lastProgressRatio'), {
        timeout: 30_000,
        message: '서버 진행률이 재개 지점보다 올라가지 않았다',
      })
      .toBeGreaterThan(resumePct / 100)
  })

  // ── RC2: 이어달리기 e2e — stale 낮은 진행률 write 방어 (원문 §6 C2 와 무관) ──
  test('RC2 — 늦은 낮은 진행률 write 가 높은 진행률을 되돌리지 않는다', async ({ page }) => {
    await enterAsGuest(page)
    const uid = await readGuestUid(page)
    const routeId = `fixture-rc2-${Date.now()}`
    // 앱이 20% 를 캐시한 상태에서 서버가 43% 로 올라간 상황을 만든다.
    await seedSavedRoute({ uid, routeId, name: 'RC2 stale 픽스처', lastProgressRatio: 0.2 })

    await reloadAtDefaultLocation(page)
    await prepareManualRideInput(page)
    await loadSavedRouteFromMenu(page, 'RC2 stale 픽스처', '이어 달리기')

    // 로드 이후 다른 탭이 43% 로 올린다(클라이언트는 여전히 20% 를 들고 있다)
    await forceSavedRouteProgress(routeId, 0.43)

    // 처음부터 달려 약 31% 에서 종료 → 클라이언트 요청값은 43% 보다 낮다
    await page.getByRole('button', { name: '이어 달리기 선택', exact: true }).click()
    await page.getByRole('radio', { name: /처음부터/ }).check()
    await page.getByRole('button', { name: '주행 시작' }).click()
    await rideUntilSessionMeters(page, FIXTURE_LENGTH_M * 0.31)
    await expect(page.getByRole('region', { name: '주행 결과' })).toBeVisible({ timeout: 20_000 })

    await expect
      .poll(async () => fieldNumber(await readSavedRoute(routeId), 'lastProgressRatio'), {
        timeout: 20_000,
        message: 'stale write 가 진행률을 되돌렸다',
      })
      .toBeGreaterThanOrEqual(0.43)

    await reloadAtDefaultLocation(page)
    const card = nextRideCard(page)
    await expect(card).toBeVisible({ timeout: 30_000 })
    await expect(card.getByRole('button', { name: /43%에서 이어 달리기/ })).toBeVisible()
  })

  // ── RC3: 이어달리기 e2e — 완주 후 새 Route 연결 (원문 §6 C3 와 무관) ──
  test('RC3 — 완주 끝점에서 새 Route 를 연결하고 이전 경로는 불변이다', async ({ page }) => {
    await enterAsGuest(page)
    const uid = await readGuestUid(page)
    const routeId = `fixture-rc3-${Date.now()}`
    await seedSavedRoute({ uid, routeId, name: 'RC3 완주 픽스처', lastProgressRatio: 0 })
    const before = await readSavedRoute(routeId)
    const geometryBefore = (before.geometryCoordsJson as { stringValue?: string })?.stringValue

    await reloadAtDefaultLocation(page)
    await prepareManualRideInput(page)
    await loadSavedRouteFromMenu(page, 'RC3 완주 픽스처')
    await page.getByRole('button', { name: '주행 시작' }).click()
    // 끝까지 달린다 — 경로 끝에 닿으면 도착 자동 종료가 결과 시트를 연다(버튼을 누르지 않는다).
    await expect(page.getByRole('button', { name: '주행 종료' })).toBeEnabled({ timeout: 30_000 })
    const summary = page.getByRole('region', { name: '주행 결과' })
    await expect(summary).toBeVisible({ timeout: 240_000 })
    /*
     * 완주 표시의 변천: 「경로를 완주했습니다」 문단 → 「완주」 배지 → **배지도 제거**
     * (2026-09-17 Chief: "사용자는 주행을 마치는 순간에 완주를 인식하고, 결과의 숫자로
     * 다시 확인한다"). 이제 완주의 증거는 **주행거리 = 총거리** 그 자체다.
     */
    const donePair = summary.getByLabel('주행 거리 / 경로 전체거리')
    await expect(donePair).toBeVisible({ timeout: 15_000 })
    // 2026-10-08 — 진행 블록으로 바뀌어 숫자는 data-* 로 읽는다
    const doneRidden = Number(await donePair.getAttribute('data-ridden-km'))
    const doneTotal = Number(await donePair.getAttribute('data-total-km'))
    const doneText = `${doneRidden} / ${doneTotal}`
    expect(doneTotal, `총거리를 읽지 못했다: ${doneText}`).toBeGreaterThan(0)
    expect(doneRidden, `완주인데 주행거리≠총거리: ${doneText}`).toBeCloseTo(doneTotal, 2)
    // 미완주 진행률 배지는 완주 시 뜨지 않는다
    await expect(summary.getByLabel('전체 진행')).toHaveCount(0)
    // 「끝점에서 새 경로」 버튼도 사라졌다(Chief 지시, 되살리지 않는다) — 살아있는 진입점
    // (사용자 정보 → 최근 주행 → 「여기서 새 경로」)으로 다시 겨눈다. 시트를 먼저 닫아야
    // 한다 — 전체화면 scrim 이 HUD 클릭을 막는다.
    await closeRideResult(page)
    await expect(summary).toBeHidden({ timeout: 15_000 })
    await extendFromRecentRideRow(page)

    // R1 §4: 새 경로 준비 전 주행바 Go는 없다. Chief 지시29로 추가된 팝업 재생은 비활성이다.
    await expect(page.locator('.ride-control-bar').getByRole('button', { name: '주행 시작', exact: true })).toHaveCount(0)
    const extendDock = page.locator('.map-view__pick-dock-panel, .map-view__pick-popup').last()
    await expect(extendDock).toBeVisible({ timeout: 15_000 })
    await expect(extendDock.getByRole('button', { name: '주행 시작', exact: true })).toBeDisabled()
    await expect(extendDock.getByRole('tab', { name: '거리·방향', exact: true })).toHaveAttribute('aria-selected', 'true')
    await expect(
      extendDock.locator('input[type="checkbox"][aria-label="거리와 방향으로 Route 찾기"]'),
    ).toBeChecked()

    // 이전 SavedRoute geometry 는 mutate 되지 않는다
    const after = await readSavedRoute(routeId)
    expect((after.geometryCoordsJson as { stringValue?: string })?.stringValue).toBe(geometryBefore)
    expect(fieldNumber(after, 'completed')).toBe(1)
  })

  // ── RC4: 이어달리기 e2e — ad-hoc 주행 후 다음 출발점 (원문 §6 C4·C5 와 무관) ──
  test('RC4 — ad-hoc 주행은 저장하지 않아도 다음 출발점이 남는다', async ({ page }) => {
    await enterAsGuest(page)
    await prepareManualRideInput(page)

    // 입문 코스는 SavedRoute 가 아니다 → 종료 시 ad-hoc 컨텍스트가 된다
    await openTrailMenu(page)
    await page.getByRole('button', { name: '경로 선택', exact: true }).click()
    await page.getByRole('button', { name: '입문', exact: true }).click()
    const modal = page.getByRole('dialog').filter({ has: page.locator('#oc-modal-title') })
    await expect(modal).toBeVisible()
    await modal.locator('button.oc-modal__item').first().click()

    await page.getByRole('button', { name: '주행 시작' }).click()
    // 입문 경로는 0.5 km 미만이라 도착 자동 종료가 먼저 온다 — 결과 시트를 기다린다.
    await expect(page.getByRole('button', { name: '주행 종료' })).toBeEnabled({ timeout: 30_000 })
    const summary = page.getByRole('region', { name: '주행 결과' })
    await expect(summary).toBeVisible({ timeout: 180_000 })
    // 「다음 출발점이 저장되었습니다」 문구는 컴팩트 재설계로 제거됐다(Chief 지시, 되살리지
    // 않는다) — 같은 사실은 아래 reload 후 「다음 주행」 카드 등장으로 이미 증명된다.
    // 저장하지 않고 닫는다 — 경고 없이 즉시 닫혀야 한다
    await summary.getByRole('button', { name: '저장 안 함' }).click()
    // 2026-09-27부터 저장 안 함 자체가 닫기까지 수행한다. 사라진 판을 다시 누르지 않는다.
    await expect(summary).toBeHidden({ timeout: 15_000 })

    await reloadAtDefaultLocation(page)
    const card = nextRideCard(page)
    await expect(card).toBeVisible({ timeout: 30_000 })
    await expect(card.getByRole('button', { name: '여기에서 계속' })).toBeVisible()
    await card.getByRole('button', { name: '여기에서 계속' }).click()
    const extendDock = page.locator('.map-view__pick-dock-panel, .map-view__pick-popup').last()
    await expect(extendDock).toBeVisible({ timeout: 15_000 })
    await expect(extendDock.getByRole('tab', { name: '거리·방향', exact: true })).toHaveAttribute('aria-selected', 'true')
    await expect(
      extendDock.locator('input[type="checkbox"][aria-label="거리와 방향으로 Route 찾기"]'),
    ).toBeChecked()
  })

  // ── RC5: 이어달리기 e2e — legacy Ride CTA 없음 (원문 §6 C5 와 무관) ──
  test('RC5 — legacy Ride 는 기록만 보이고 잘못된 CTA·Null Island 이동이 없다', async ({ page }) => {
    await enterAsGuest(page)
    const uid = await readGuestUid(page)
    await seedLegacyRide(uid, `legacy-${Date.now()}`)

    const pageErrors: string[] = []
    page.on('pageerror', (err) => pageErrors.push(String(err)))

    await reloadAtDefaultLocation(page)
    // 좌표도 Route 도 없는 Ride 뿐이므로 「다음 주행」 카드는 뜨지 않는다
    await expect(nextRideCard(page)).toHaveCount(0)

    // 기록 자체는 최근 주행 목록에 남는다.
    // 목록을 여는 토글의 화면 문구는 「마지막 주행」이다 — 「최근 주행」은 소스 주석에만 있고
    // 버튼 접근명이 아니다. 종전 셀렉터가 그 주석 표현을 쓰고 있어 이 시험은 **이미 깨져 있었다**
    // (2026-09-17 확인, 이번 컴팩트 재설계와 무관한 기존 결함).
    await page.getByRole('button', { name: '사용자 정보' }).click()
    const history = page.getByRole('button', { name: '마지막 주행' })
    await expect(history).toBeVisible({ timeout: 15_000 })
    await history.click()
    await expect(page.getByText('5.20 km').first()).toBeVisible({ timeout: 15_000 })
    // legacy 행에는 이어 달리기·새 경로 CTA 가 없다
    await expect(page.getByRole('button', { name: '이어 달리기' })).toHaveCount(0)
    await expect(page.getByRole('button', { name: '여기서 새 경로' })).toHaveCount(0)

    expect(pageErrors, `스크립트 예외: ${pageErrors.join(' | ')}`).toEqual([])
  })

  /**
   * RC13 — §6 C13 e2e: reload 없이 종료→카드→이어 달리기 Go 까지 완주한다.
   *
   * RC1 은 결과 시트를 닫은 뒤 **재진입(page.reload)**해 재개를 검증한다 (§6 C1 과 무관).
   * RC13 은 같은 세션에서 reload 없이 카드 → resume → 센서 준비 → Go → HUD 를 검증한다.
   * 핵심 가설: 첫 번째 reload 이후 mapLoaded=true 가 유지되므로
   *            resume-marker 가 reload 없이도 렌더링되어야 한다.
   */
  test('RC13 — reload 없이 종료→카드→이어 달리기 Go 까지 완주한다', async ({ page }) => {
    await enterAsGuest(page)
    const uid = await readGuestUid(page)
    const routeId = `fixture-rc13-${Date.now()}`
    await seedSavedRoute({ uid, routeId, name: 'RC13 이어달리기 픽스처', lastProgressRatio: 0 })

    // 첫 번째 reload: 씨드된 경로를 앱에 반영
    await reloadAtDefaultLocation(page)
    await prepareManualRideInput(page)
    await loadSavedRouteFromMenu(page, 'RC13 이어달리기 픽스처')

    // 1차 주행 — 전체의 약 20%
    await page.getByRole('button', { name: '주행 시작' }).click()
    await rideUntilSessionMeters(page, FIXTURE_LENGTH_M * 0.2)

    // 결과 시트 대기 및 닫기 (이 이후로 page.reload() 없음)
    const summary = page.getByRole('region', { name: '주행 결과' })
    await expect(summary).toBeVisible({ timeout: 20_000 })
    await closeRideResult(page)

    // reload 없이 「다음 주행」 카드가 즉시 나타나야 한다
    const card = nextRideCard(page)
    await expect(card).toBeVisible({ timeout: 15_000 })
    const resumeBtn = card.getByRole('button', { name: /%에서 이어 달리기/ })
    await expect(resumeBtn).toBeVisible()

    // reload 없이 resume CTA 클릭
    await resumeBtn.click()
    const start = page.getByRole('button', { name: '주행 시작' })
    await expect(start).toBeVisible({ timeout: 20_000 })

    // §3.4 — resume-marker 는 mapLoaded=true 가 유지될 때만 렌더된다.
    // reload 없이도 첫 load 이후 mapLoaded=true 가 유지되는 것을 확인한다.
    await expect(page.locator('.map-view__resume-marker')).toBeVisible({ timeout: 15_000 })

    // 센서 재준비 후 Go (reload 없이 두 번째 주행 시작)
    await prepareManualRideInput(page)
    await expect(start).toBeEnabled()
    await start.click()

    // HUD — 주행이 실제로 시작됐음을 확인
    await expect(page.getByRole('group', { name: '주행 지표' })).toBeVisible({ timeout: 20_000 })
    await expect(page.getByLabel('주행 누적 거리')).toBeVisible()

    // MIN_MEANINGFUL_RIDE_DISTANCE_METERS=100m 을 초과해야 discardRecord=false 가 된다.
    // 150m(≈ 10.8초 @50km/h)는 안전 여유분이 있어 결과 시트가 정상 출현한다.
    // rideUntilSessionMeters 는 종료 버튼 표시 대기를 포함한다.
    await rideUntilSessionMeters(page, 150)
    await expect(page.getByRole('region', { name: '주행 결과' })).toBeVisible({ timeout: 20_000 })
  })

  /**
   * CF-LIVE — CF conquestOnRideCreated 가 에뮬레이터에서 conquestResult 를 기록한다.
   * ⚠ 이어달리기 e2e CF-LIVE 시나리오(R5/F3 에뮬레이터 라이브) —
   *   원문 §6 C14(end between UI metric ticks → 종료 샘플 일관성)와는 전혀 다른 항목이다.
   *   §6 C14 = N2 end-sample 증거(ride-result-n2-persistence.test.ts)로 커버됨.
   *
   * 「단위 테스트 injection」과의 구분:
   *   - 앱이 실 Firestore 에뮬레이터에 rides 문서를 생성하는 프로덕션 경로를 사용한다.
   *   - 정복 페이로드(conquest.cells)는 클라이언트 `buildConquestCellsFromRoute` 가 계산한다.
   *   - CF `conquestOnRideCreated` 가 Functions 에뮬레이터에서 트리거되어 `conquestResult` 를 기록한다.
   *   - 테스트는 직접 conquestResult 를 주입하거나 fake PASS 를 만들지 않는다.
   *
   * BLOCK 조건:
   *   (1) rides/{id}.conquest 페이로드가 없으면 CF 는 skip 함 — 클라이언트 conquest 계산 실패 의심.
   *   (2) 60초 내 conquestResult 미출현 — Functions 에뮬레이터 미기동 또는 CF 오류.
   *   두 경우 모두 정확한 오류와 로그를 남기고 FAIL 처리한다.
   */
  test('CF-LIVE — CF conquestOnRideCreated 가 에뮬레이터에서 conquestResult 를 기록한다', async ({ page }) => {
    await enterAsGuest(page)
    const uid = await readGuestUid(page)
    const routeId = `fixture-cf-live-${Date.now()}`
    await seedSavedRoute({ uid, routeId, name: 'CF-LIVE 정복 픽스처', lastProgressRatio: 0 })

    await reloadAtDefaultLocation(page)
    await prepareManualRideInput(page)
    await loadSavedRouteFromMenu(page, 'CF-LIVE 정복 픽스처')

    // 30% 주행 — conquest 셀이 충분히 생성되도록(~300m, 약 10개 z20 셀 예상)
    await page.getByRole('button', { name: '주행 시작' }).click()
    await rideUntilSessionMeters(page, FIXTURE_LENGTH_M * 0.3)

    const summary = page.getByRole('region', { name: '주행 결과' })
    await expect(summary).toBeVisible({ timeout: 20_000 })

    // ── 1. savedRoutes.lastRideId 폴링 ──────────────────────────────────────
    // 앱이 rides/{id} 를 Firestore 에 생성했음을 확인 (프로덕션 경로)
    let serverRideId: string | null = null
    await expect
      .poll(
        async () => {
          const fields = await readSavedRoute(routeId)
          const raw = fields.lastRideId as { stringValue?: string; nullValue?: null } | undefined
          const id = raw?.stringValue ?? null
          if (id) serverRideId = id
          return id
        },
        {
          timeout: 30_000,
          message:
            'savedRoutes.lastRideId 가 30초 내에 설정되지 않았다— ' +
            'ride Firestore 저장 실패 또는 progress update 실패 의심',
        },
      )
      .not.toBeNull()

    console.log(`[CF-LIVE] serverRideId confirmed: ${serverRideId}`)

    // ── 2. rides/{serverRideId}.conquest 페이로드 확인 (CF 전제조건) ─────────
    // conquest 가 없으면 CF 는 즉시 return — fake PASS 방지용 조기 실패
    const rideFields = await readRide(serverRideId!)
    const conquestField = rideFields.conquest as
      | { mapValue?: unknown }
      | { nullValue?: null }
      | undefined
    if (!conquestField || !('mapValue' in conquestField)) {
      const presentKeys = Object.keys(rideFields).join(', ')
        throw new Error(
          `BLOCK: rides/${serverRideId} 에 conquest 페이로드 없음 — ` +
          `buildConquestCellsFromRoute 가 셀을 생성하지 못했거나 Firestore 저장 누락.\n` +
          `존재하는 필드: [${presentKeys}]`,
        )    }
    console.log(`[CF-LIVE] conquest payload confirmed in rides/${serverRideId}`)

    // ── 3. CF conquestOnRideCreated → rides/{id}.conquestResult 폴링 ─────────
    // Functions 에뮬레이터가 Firestore 트리거를 받아 결과를 기록할 때까지 최대 60초 대기
    // Firestore REST API: 정수 → integerValue, 실수 → doubleValue
    type FirestoreNum = { doubleValue?: number; integerValue?: string }
    type ConquestResultFields = {
      newMeters?: FirestoreNum
      newCells?: FirestoreNum
      creditedMeters?: FirestoreNum
      tier?: { stringValue?: string }
      day?: { stringValue?: string }
    }
    let conquestResultFields: ConquestResultFields | null = null

    await expect
      .poll(
        async () => {
          const fields = await readRide(serverRideId!)
          const result = fields.conquestResult as
            | { mapValue?: { fields?: ConquestResultFields }; nullValue?: null }
            | undefined
          if (result && 'mapValue' in result && result.mapValue?.fields) {
            conquestResultFields = result.mapValue.fields
            return result
          }
          return null
        },
        {
          timeout: 60_000,
          intervals: [1000],
          message:
            `BLOCK: CF conquestOnRideCreated 가 rides/${serverRideId}.conquestResult 를 ` +
            `60초 내에 기록하지 않았다. Functions 에뮬레이터 미기동 또는 CF 오류 의심.`,
        },
      )
      .not.toBeNull()

    // ── 4. conquestResult 내용 검증 ──────────────────────────────────────────
    console.log(`[CF-LIVE] PASS — CF conquestResult: ${JSON.stringify(conquestResultFields)}`)
    expect(conquestResultFields).not.toBeNull()
    // CF 는 정수 미터를 Firestore integerValue 로 저장한다 — fieldNumber 로 양쪽 처리
    const newMeters = fieldNumber(conquestResultFields as Record<string, unknown>, 'newMeters')
    expect(newMeters, 'conquestResult.newMeters 가 없다').toBeGreaterThan(0)
    // tier: 't0'(no-sensor) 또는 't1'(cadence)
    expect(['t0', 't1']).toContain(conquestResultFields!.tier?.stringValue)
  })
})
