import { expect, test, type Page } from '@playwright/test';
import fs from 'node:fs/promises';
import path from 'node:path';

const preview = '/scripts/ui-800x360/preview.html';
const key = 'spinatlas.rideInterval.config.v1';
const editor = (page: Page) => page.getByRole('dialog', {name:'인터벌 운동 설정',exact:true});
const settings = (page: Page) => page.getByRole('dialog', {name:'주행 설정',exact:true});
test.use({viewport:{width:699,height:273},reducedMotion:'reduce'});

async function openEditor(page: Page) {
  await settings(page).getByRole('button',{name:'운동 설정',exact:true}).click();
  await expect(editor(page)).toBeVisible();
  await expect(settings(page)).toHaveCount(0);
}
async function openFromRide(page: Page) {
  await page.getByRole('button',{name:'Trail 메뉴',exact:true}).focus();
  await page.keyboard.press('Enter');
  await page.getByRole('button',{name:'주행 설정',exact:true}).click();
  await openEditor(page);
}
async function configure(page: Page, high: string, low: string, repeats: string) {
  await editor(page).getByRole('spinbutton',{name:'고강도 시간 초',exact:true}).fill(high);
  await editor(page).getByRole('spinbutton',{name:'저강도 시간 초',exact:true}).fill(low);
  await editor(page).getByRole('spinbutton',{name:'반복 수',exact:true}).fill(repeats);
}

test('8종 프리셋은 총시간을 갱신하고 적용한 선택만 주행 설정에 반영한다', async ({page}) => {
  await page.goto(`${preview}?state=settings`);
  await openEditor(page);
  const select=editor(page).getByRole('combobox',{name:'운동 프리셋'});
  await expect(select.locator('option')).toHaveCount(9);
  const options=await select.locator('option').evaluateAll(nodes=>nodes.map(node=>(node as HTMLOptionElement).value));
  const totals=['15:00','17:30','18:00','18:00','22:00','20:00','22:00','25:00'];
  for(let index=0;index<8;index++){
    await select.selectOption(options[index]);
    await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText(totals[index]);
  }
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await expect(settings(page)).toContainText('90초 / 60초 ×6회 · 총 25:00');
  await openEditor(page);
  await expect(select).toHaveValue('90-60-6');
  await configure(page,'45','60','6');
  await expect(select).toHaveValue('custom');
  await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText('20:30');
  await page.keyboard.press('Escape');
  await expect(settings(page)).toContainText('90초 / 60초 ×6회 · 총 25:00');
});

test('직접 설정한 시간·반복이 실제 단계 전환과 완료에 쓰인다', async ({page}) => {
  await page.clock.install();
  await page.goto(`${preview}?state=settings`);
  await settings(page).getByRole('switch',{name:/^인터벌/}).check();
  await openEditor(page);
  await configure(page,'45','60','6');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await settings(page).getByRole('button',{name:'주행 설정 닫기',exact:true}).click();
  await page.getByRole('button',{name:'주행 시작',exact:true}).click();
  await page.clock.fastForward(300_000);
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('운동');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('45');
  await expect(page.locator('.ride-interval-hud__repeat')).toHaveText('1 / 6');
  await page.clock.fastForward(45_000);
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('회복');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('1:00');
  await page.clock.fastForward(60_000);
  await expect(page.locator('.ride-interval-hud__repeat')).toHaveText('2 / 6');
  await page.clock.fastForward(825_000);
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('완료');
  await expect(page.getByRole('button',{name:'일시정지',exact:true})).toBeVisible();
});

test('진행 중 초안·취소·같은 설정은 운동을 바꾸지 않고 변경 적용만 준비부터 재시작한다', async ({page}) => {
  await page.clock.install();
  await page.goto(`${preview}?state=riding&interval&intervalMs=426000`);
  await openFromRide(page);
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('운동');
  await openEditor(page);
  await configure(page,'45','60','6');
  await expect(editor(page)).toContainText('적용하면 처음부터 다시 시작해요');
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('운동');
  await editor(page).getByRole('button',{name:'인터벌 운동 설정 닫기',exact:true}).click();
  await expect(settings(page)).toContainText('30초 / 30초 ×5회');
  await openEditor(page);
  await configure(page,'45','60','6');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('준비');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('5:00');
  await settings(page).getByRole('button',{name:'주행 설정 닫기',exact:true}).click();
  await page.getByRole('button',{name:'일시정지',exact:true}).click();
  await openFromRide(page);
  await configure(page,'20','40','8');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await page.clock.fastForward(60_000);
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('일시정지');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('5:00');
});

test('입력 오류는 적용을 차단하고 취소하면 저장값을 보존한다', async ({page}) => {
  await page.goto(`${preview}?state=settings`);
  await openEditor(page);
  const input=editor(page).getByRole('spinbutton',{name:'고강도 시간 초',exact:true});
  for(const invalid of ['', '0', '4', '601', '7.5']){
    await input.fill(invalid);
    await expect(editor(page).getByRole('button',{name:'설정 적용',exact:true})).toBeDisabled();
    await expect(editor(page).getByRole('alert')).toBeVisible();
  }
  await configure(page,'7','11','0');
  await expect(editor(page).getByRole('button',{name:'설정 적용',exact:true})).toBeDisabled();
  await configure(page,'7','11','31');
  await expect(editor(page).getByRole('button',{name:'설정 적용',exact:true})).toBeDisabled();
  await configure(page,'7','11','3');
  await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText('10:54');
  await expect(editor(page).getByRole('button',{name:'설정 적용',exact:true})).toBeEnabled();
  await page.keyboard.press('Escape');
  expect(await page.evaluate(storageKey=>localStorage.getItem(storageKey),key)).toBeNull();
});

test('설정은 새로고침 후 복원되고 인터벌 사용은 자동으로 켜지지 않는다', async ({page}) => {
  await page.goto(`${preview}?state=settings&persistInterval`);
  await openEditor(page);
  await configure(page,'45','60','6');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await page.reload();
  await expect(settings(page)).toContainText('45초 / 60초 ×6회 · 총 20:30');
  await expect(settings(page).getByRole('switch',{name:/^인터벌/})).not.toBeChecked();
});

test('저장 데이터 파손·저장소 접근 불가에서도 기본값과 메모리 설정이 동작한다', async ({page}) => {
  await page.addInitScript(storageKey=>localStorage.setItem(storageKey,'{"highSec":"oops"}'),key);
  await page.goto(`${preview}?state=settings&persistInterval`);
  await expect(settings(page)).toContainText('30초 / 30초 ×5회 · 총 15:00');
  await page.addInitScript(()=>Object.defineProperty(window,'localStorage',{get(){throw new Error('blocked');},configurable:true}));
  await page.reload();
  await openEditor(page);
  await configure(page,'20','40','8');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await expect(settings(page)).toContainText('20초 / 40초 ×8회 · 총 18:00');
});

test('주행 중 설정 복원용 저장소 읽기는 매 프레임 반복하지 않는다', async ({page}) => {
  await page.clock.install();
  await page.addInitScript(storageKey=>{
    const original=Storage.prototype.getItem;
    const counts: Record<string,number>={reads:0};
    Object.assign(window,{intervalConfigReadCounts:counts});
    Storage.prototype.getItem=function(name:string){if(name===storageKey)counts.reads++;return original.call(this,name);};
  },key);
  await page.goto(`${preview}?state=riding&interval&persistInterval`);
  const reads=()=>page.evaluate(()=>((window as unknown as {intervalConfigReadCounts:{reads:number}}).intervalConfigReadCounts.reads));
  const initial=await reads();
  expect(initial).toBeGreaterThan(0);
  await page.clock.runFor(3000);
  expect(await reads()).toBe(initial);
});

test('준비·마무리는 기본 5분에서 버튼·키보드로 30초씩 증감한다',async({page})=>{
  await page.goto(`${preview}?state=settings`);
  await openEditor(page);
  for(const label of ['준비','마무리']){
    const input=editor(page).getByRole('spinbutton',{name:`${label} 시간 초`,exact:true});
    await expect(input).toHaveValue('300');
    await editor(page).getByRole('button',{name:`${label} 30초 늘리기`,exact:true}).click();
    await expect(input).toHaveValue('330');
    await editor(page).getByRole('button',{name:`${label} 30초 줄이기`,exact:true}).click();
    await expect(input).toHaveValue('300');
    await input.focus();await input.press('ArrowDown');
    await expect(input).toHaveValue('270');
    await input.press('ArrowUp');
    await expect(input).toHaveValue('300');
    await input.fill('0');await editor(page).getByRole('button',{name:`${label} 30초 줄이기`,exact:true}).click();
    await expect(input).toHaveValue('0');
    await input.fill('1800');await editor(page).getByRole('button',{name:`${label} 30초 늘리기`,exact:true}).click();
    await expect(input).toHaveValue('1800');
  }
});

test('준비·마무리 설정과 총시간을 저장하고 해당 시간대로 단계가 전환된다',async({page})=>{
  await page.clock.install();
  await page.goto(`${preview}?state=settings&persistInterval`);
  await openEditor(page);
  await configure(page,'7','11','3');
  await editor(page).getByRole('spinbutton',{name:'준비 시간 초',exact:true}).fill('15');
  await editor(page).getByRole('spinbutton',{name:'마무리 시간 초',exact:true}).fill('20');
  await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText('1:29');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await page.reload();
  await expect(settings(page)).toContainText('준비 15초 · 마무리 20초');
  await settings(page).getByRole('switch',{name:/^인터벌/}).check();
  await settings(page).getByRole('button',{name:'주행 설정 닫기',exact:true}).click();
  await page.getByRole('button',{name:'주행 시작',exact:true}).click();
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('15');
  await page.clock.fastForward(15_000);
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('운동');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('7');
  await page.clock.fastForward(54_000);
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('마무리');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('20');
  await page.clock.fastForward(20_000);
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('완료');
});

test('준비·마무리 0초는 건너뛰고 잘못된 시간은 적용을 막는다',async({page})=>{
  await page.clock.install();
  await page.goto(`${preview}?state=settings`);
  await settings(page).getByRole('switch',{name:/^인터벌/}).check();
  await openEditor(page);
  const warmup=editor(page).getByRole('spinbutton',{name:'준비 시간 초',exact:true});
  for(const raw of ['', '-1', '1801', '1.5']){
    await warmup.fill(raw);
    await expect(editor(page).getByRole('button',{name:'설정 적용',exact:true})).toBeDisabled();
  }
  await warmup.fill('0');
  await editor(page).getByRole('spinbutton',{name:'마무리 시간 초',exact:true}).fill('0');
  await configure(page,'7','11','3');
  await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText('0:54');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await expect(settings(page)).toContainText('준비 없음 · 마무리 없음');
  await settings(page).getByRole('button',{name:'주행 설정 닫기',exact:true}).click();
  await page.getByRole('button',{name:'주행 시작',exact:true}).click();
  await expect(page.locator('.ride-interval-hud__phase')).toHaveText('운동');
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('7');
  await page.clock.fastForward(54_000);
  await expect(page.locator('.ride-interval-hud__time')).toHaveText('완료');
});

test('기존 세 필드 저장값의 운동은 보존하고 준비·마무리는 5분으로 복원한다',async({page})=>{
  await page.goto(`${preview}?state=settings&persistInterval`);
  await page.evaluate(storageKey=>localStorage.setItem(storageKey,JSON.stringify({highSec:45,lowSec:60,repeats:6})),key);
  await page.reload();
  await expect(settings(page)).toContainText('45초 / 60초 ×6회 · 총 20:30');
  await expect(settings(page)).toContainText('준비 5분 · 마무리 5분');
  await openEditor(page);
  await expect(editor(page).getByRole('spinbutton',{name:'준비 시간 초',exact:true})).toHaveValue('300');
  await expect(editor(page).getByRole('spinbutton',{name:'마무리 시간 초',exact:true})).toHaveValue('300');
  await editor(page).getByRole('spinbutton',{name:'준비 시간 초',exact:true}).fill('0');
  await editor(page).getByRole('spinbutton',{name:'마무리 시간 초',exact:true}).fill('60');
  await editor(page).getByRole('button',{name:'설정 적용',exact:true}).click();
  await page.reload();
  await expect(settings(page)).toContainText('45초 / 60초 ×6회 · 총 11:30');
  await expect(settings(page)).toContainText('준비 없음 · 마무리 1분');
});

test.describe('지도 가림 최소화',()=>{
  test.use({hasTouch:true,isMobile:true});
  for(const size of [{width:699,height:273},{width:667,height:300},{width:800,height:360},{width:320,height:568}]){
    test(`내용에 맞춘 창 ${size.width}×${size.height}`,async({page})=>{
      await page.setViewportSize(size);
      await page.goto(`${preview}?state=settings`);
      await expect(settings(page)).toBeVisible();
      await page.locator('.ride-settings-sheet__panel').evaluate(el=>Promise.all(el.getAnimations().map(animation=>animation.finished.catch(()=>{}))));
      const parent=await page.locator('.ride-settings-sheet__panel').evaluate(el=>{
        const box=el.getBoundingClientRect();
        const children=[...el.querySelectorAll('button,input,label')].map(child=>child.getBoundingClientRect());
        return {width:box.width,height:box.height,inside:box.left>=0&&box.right<=innerWidth&&box.top>=0&&box.bottom<=innerHeight,childrenInside:children.every(child=>child.left>=box.left&&child.right<=box.right)};
      });
      expect(parent.width).toBeLessThanOrEqual(360);
      expect(parent.inside).toBe(true);
      expect(parent.childrenInside).toBe(true);
      if(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR){await fs.mkdir(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR,{recursive:true});await page.screenshot({path:path.join(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR,`ride-settings-${size.width}x${size.height}.png`)});await fs.writeFile(path.join(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR,`ride-settings-${size.width}x${size.height}.metrics.json`),JSON.stringify(parent,null,2));}
      await openEditor(page);
      const geometry=await page.locator('.ride-interval-settings__panel').evaluate(el=>{
        const box=el.getBoundingClientRect();
        const children=[...el.querySelectorAll('button,input,select,label,.ride-interval-settings__summary')].map(child=>child.getBoundingClientRect());
        const fields=el.querySelector('.ride-interval-settings__fields')!.getBoundingClientRect();
        const summary=el.querySelector('.ride-interval-settings__summary')!.getBoundingClientRect();
        const targets=[...el.querySelectorAll('button,input,select')].map(target=>target.getBoundingClientRect());
        return {width:box.width,height:box.height,overflow:el.scrollHeight>el.clientHeight+1,inside:box.left>=0&&box.top>=0&&box.right<=innerWidth&&box.bottom<=innerHeight,childrenInside:children.every(child=>child.left>=box.left&&child.right<=box.right),overlap:fields.left<summary.right&&fields.right>summary.left&&fields.top<summary.bottom&&fields.bottom>summary.top,cover:box.width*box.height/(innerWidth*innerHeight),minTargetWidth:Math.min(...targets.map(target=>target.width)),minTargetHeight:Math.min(...targets.map(target=>target.height))};
      });
      expect(geometry.width).toBeLessThanOrEqual(480);
      expect(geometry.inside).toBe(true);
      expect(geometry.childrenInside).toBe(true);
      expect(geometry.overflow).toBe(false);
      expect(geometry.overlap).toBe(false);
      expect(geometry.minTargetWidth).toBeGreaterThanOrEqual(44);
      expect(geometry.minTargetHeight).toBeGreaterThanOrEqual(44);
      if(size.width>440){expect(geometry.height).toBeLessThanOrEqual(248);expect(geometry.cover).toBeLessThan(.65);}
      if(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR){await fs.mkdir(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR,{recursive:true});await page.screenshot({path:path.join(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR,`settings-${size.width}x${size.height}.png`)});await fs.writeFile(path.join(process.env.INTERVAL_SETTINGS_EVIDENCE_DIR,`settings-${size.width}x${size.height}.metrics.json`),JSON.stringify(geometry,null,2));}
      await configure(page,'600','600','30');
      await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText('610:00');
      const large=await page.locator('.ride-interval-settings__summary').evaluate(el=>{
        const box=el.getBoundingClientRect(),total=el.querySelector('strong')!.getBoundingClientRect();
        const marks=[...el.querySelectorAll('.ride-interval-settings__timeline span')].map(mark=>mark.getBoundingClientRect());
        return total.right<=box.right+1&&marks.every(mark=>mark.right<=box.right+1);
      });
      expect(large).toBe(true);
      await editor(page).getByRole('spinbutton',{name:'준비 시간 초',exact:true}).fill('1800');
      await editor(page).getByRole('spinbutton',{name:'마무리 시간 초',exact:true}).fill('1800');
      await expect(editor(page).locator('.ride-interval-settings__total strong')).toHaveText('660:00');
    });
  }
});
