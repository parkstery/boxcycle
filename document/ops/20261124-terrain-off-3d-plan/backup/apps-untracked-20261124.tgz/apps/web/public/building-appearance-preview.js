/* Development-only building appearance comparison, enabled by ?buildingpreview=1. */
const panel = document.createElement('section');
panel.id = 'building-appearance-preview';
panel.innerHTML = `<div class="building-preview-head"><button type="button" class="building-preview-drag" aria-label="건물 외관 비교 창 이동">⠿ 이동</button><strong>건물 외관 비교</strong><span id="building-preview-fps">FPS 대기</span></div><details open><summary>선택 펼치기 / 접기</summary>
  <p>색상과 벽면을 주행 중 바꿔 보세요.</p>
  <label>지형 3D <input type="checkbox" id="building-preview-terrain"></label>
  <p class="building-preview-note" id="building-preview-terrain-status">지형 상태 확인 중</p>
  <label>3D 건물 <input type="checkbox" id="building-preview-buildings" checked></label>
  <p class="building-preview-note">3D 객체 자동 거리 제한 해제</p>
  <label>원거리 안개 <input type="checkbox" id="building-preview-fog"></label>
  <label>안개 범위 <input type="range" id="building-preview-distance" min="0.5" max="20" step="0.5" value="10"></label>
  <p class="building-preview-note">안개 범위: <span id="building-preview-distance-value">기본</span> · 상대값, 미터 아님. 전체 화면에 적용됩니다.</p>
  <label>건물 색상 <input type="color" id="building-preview-color" value="#cbbeb0"></label>
  <div class="building-colors">
    <button data-color="#cbbeb0">모래</button><button data-color="#e7d8c5">크림</button>
    <button data-color="#b7c7d2">청회색</button><button data-color="#d5b2a1">살구</button>
    <button data-color="#bdc6b3">세이지</button><button data-color="#d6d6d2">밝은 회색</button>
  </div>
  <label>벽면 <select id="building-preview-surface">
    <option value="standard">Standard 기본 외관</option>
    <option value="windows">창문 패턴</option><option value="brick">벽돌 패턴</option>
    <option value="stone">석재 패턴</option>
  </select></label>
  <button id="building-preview-reset">기본으로 복원</button>
  <p class="building-preview-note">패턴은 기본 3D 건물 위에 비교용으로 표시됩니다.</p>
  <output>지도 준비 중…</output></details>`;
const style = document.createElement('style');
style.textContent = `#building-appearance-preview{position:fixed;z-index:9999;right:12px;top:62px;width:230px;max-height:calc(100dvh - 75px);overflow:auto;background:#fffffff2;color:#182839;border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 4px 18px #0003;font:13px system-ui;padding:10px}#building-appearance-preview summary{cursor:pointer;font-weight:700}#building-appearance-preview p{margin:8px 0;line-height:1.35}#building-appearance-preview label{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:9px 0}#building-appearance-preview select{max-width:145px}#building-appearance-preview button,#building-appearance-preview select{cursor:pointer;padding:4px 7px;border:1px solid #cad5e2;border-radius:5px;background:white}#building-appearance-preview input{width:45px;height:28px}.building-colors{display:flex;flex-wrap:wrap;gap:4px}.building-preview-note{font-size:11px;color:#536578}#building-appearance-preview output{display:block;font-size:11px;color:#24549a}`;
style.textContent += `.building-preview-head{display:flex;align-items:center;gap:6px;margin-bottom:8px}.building-preview-head strong{flex:1}.building-preview-head #building-preview-fps{white-space:nowrap;font-weight:700;color:#1451ad}.building-preview-head .building-preview-drag{cursor:grab;touch-action:none;user-select:none;padding:4px}`;
document.head.append(style);
document.body.append(panel);
const colorInput = panel.querySelector('#building-preview-color');
const surfaceInput = panel.querySelector('#building-preview-surface');
const terrainInput = panel.querySelector('#building-preview-terrain');
const buildingsInput = panel.querySelector('#building-preview-buildings');
const fogInput = panel.querySelector('#building-preview-fog');
const distanceInput = panel.querySelector('#building-preview-distance');
const distanceValue = panel.querySelector('#building-preview-distance-value');
const status = panel.querySelector('output');
const sourceId = 'spinatlas-preview-building-source';
const layerId = 'spinatlas-preview-building-pattern';
let selectedColor = null;
let map = null;
let lastStyle = null;
let pending = false;
let originalFog;
let fogPending = false;
let frameTimes = [];
const fpsOutput = panel.querySelector('#building-preview-fps');
const dragHandle = panel.querySelector('.building-preview-drag');
let drag = null;
dragHandle.addEventListener('pointerdown', event => {
  if (event.button !== 0) return;
  const rect = panel.getBoundingClientRect();
  drag = { id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top };
  dragHandle.setPointerCapture(event.pointerId);
  event.preventDefault();
});
dragHandle.addEventListener('pointermove', event => {
  if (!drag || drag.id !== event.pointerId) return;
  panel.style.right = 'auto';
  panel.style.left = `${Math.max(0, Math.min(window.innerWidth - panel.offsetWidth, event.clientX - drag.dx))}px`;
  panel.style.top = `${Math.max(0, Math.min(window.innerHeight - 36, event.clientY - drag.dy))}px`;
});
for (const eventName of ['pointerup', 'pointercancel', 'lostpointercapture']) dragHandle.addEventListener(eventName, () => { drag = null; });
function noteFrame() {
  const now = performance.now();
  frameTimes.push(now);
  while (frameTimes.length && frameTimes[0] < now - 2000) frameTimes.shift();
}
function pattern(kind) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = selectedColor || '#cbbeb0'; ctx.fillRect(0, 0, 128, 128);
  if (kind === 'windows') {
    ctx.fillStyle = '#65808c';
    for (let y = 7; y < 128; y += 32) for (let x = 8; x < 128; x += 32) ctx.fillRect(x, y, 18, 20);
  } else if (kind === 'brick') {
    ctx.strokeStyle = '#765d53'; ctx.lineWidth = 2;
    for (let y = 0; y < 128; y += 16) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(128, y); ctx.stroke();
      for (let x = (y / 16 % 2) * 16; x < 128; x += 32) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 16); ctx.stroke(); }
    }
  } else {
    ctx.strokeStyle = '#8b8981'; ctx.lineWidth = 3;
    for (let y = 0; y < 128; y += 32) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(128, y); ctx.stroke();
      for (let x = (y / 32 % 2) * 32; x < 128; x += 64) { ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y + 32); ctx.stroke(); }
    }
  }
  return ctx.getImageData(0, 0, 128, 128);
}
function apply() {
  if (!map || !map.isStyleLoaded()) { pending = true; return; }
  const imported = map.getStyle()?.imports?.some(item => item.id === 'basemap');
  if (!imported) { status.textContent = 'Standard 낮 지도를 선택하세요.'; return; }
  try {
    const surface = surfaceInput.value;
    const textured = buildingsInput.checked && ['windows', 'brick', 'stone'].includes(surface);
    if (map.getLayer(layerId)) map.removeLayer(layerId);
    if (map.hasImage('spinatlas-preview-building-image')) map.removeImage('spinatlas-preview-building-image');
    map.setConfigProperty('basemap', 'colorBuildings', selectedColor || null);
    map.setConfigProperty('basemap', 'show3dObjects', true);
    map.setConfigProperty('basemap', 'show3dBuildings', buildingsInput.checked);
    map.setConfigProperty('basemap', 'show3dFacades', true);
    map.setConfigProperty('basemap', 'show3dLandmarks', buildingsInput.checked);
    map.setConfigProperty('basemap', 'show3dTrees', true);
    if (textured) {
      if (!map.getSource(sourceId)) map.addSource(sourceId, { type: 'vector', url: 'mapbox://mapbox.mapbox-streets-v8' });
      map.addImage('spinatlas-preview-building-image', pattern(surface), { pixelRatio: 2 });
      map.addLayer({ id: layerId, type: 'fill-extrusion', source: sourceId, 'source-layer': 'building', minzoom: 15,
        filter: ['==', ['get', 'extrude'], 'true'],
        paint: { 'fill-extrusion-pattern': 'spinatlas-preview-building-image', 'fill-extrusion-height': ['coalesce', ['get', 'height'], 0], 'fill-extrusion-base': ['coalesce', ['get', 'min_height'], 0], 'fill-extrusion-opacity': 1, 'fill-extrusion-cutoff-fade-range': 0 } });
    }
    status.textContent = '적용됨 · 지도 이동 후에도 유지';
    pending = false;
  } catch (error) { status.textContent = `적용 대기: ${error.message}`; }
}
function applyFog() {
  if (!map || !map.isStyleLoaded()) { fogPending = true; return; }
  try {
    if (originalFog === undefined) originalFog = map.getFog() ?? null;
    const value = Number(distanceInput.value);
    if (fogInput.checked) {
      map.setFog({ ...(originalFog || {}), range: [-0.5, value] });
      distanceValue.textContent = String(value);
    } else {
      map.setFog(originalFog);
      distanceValue.textContent = '기본';
    }
    fogPending = false;
  } catch (error) { status.textContent = `안개 적용 대기: ${error.message}`; }
}
panel.addEventListener('click', event => {
  const choice = event.target.closest('[data-color]');
  if (choice) { selectedColor = choice.dataset.color; colorInput.value = selectedColor; apply(); }
  if (event.target.id === 'building-preview-reset') { selectedColor = null; colorInput.value = '#cbbeb0'; surfaceInput.value = 'standard'; apply(); }
});
colorInput.addEventListener('input', () => { selectedColor = colorInput.value; apply(); });
surfaceInput.addEventListener('change', apply);
buildingsInput.addEventListener('change', apply);
terrainInput.addEventListener('change', () => {
  window.dispatchEvent(new CustomEvent('spinatlas:building-preview-terrain', { detail: terrainInput.checked }));
});
fogInput.addEventListener('change', applyFog);
distanceInput.addEventListener('input', () => { fogInput.checked = true; applyFog(); });
const timer = setInterval(() => {
  const candidate = window.__RTW_MAP__;
  if (!candidate) return;
  if (map !== candidate) { if (map) map.off('render', noteFrame); map = candidate; frameTimes = []; map.on('render', noteFrame); lastStyle = null; originalFog = undefined; map.on('style.load', () => { lastStyle = map.style; originalFog = undefined; apply(); if (fogInput.checked) applyFog(); }); }
  if (map.isStyleLoaded() && lastStyle !== map.style) { lastStyle = map.style; apply(); }
  if (map.isStyleLoaded() && lastStyle === map.style) {
    const textured = buildingsInput.checked && ['windows', 'brick', 'stone'].includes(surfaceInput.value);
    if (pending || Boolean(map.getLayer(layerId)) !== textured || map.getConfigProperty('basemap', 'show3dBuildings') !== buildingsInput.checked || map.getConfigProperty('basemap', 'show3dTrees') !== true) apply();
    if (fogPending) applyFog();
    const terrain = map.getTerrain();
    if (Boolean(terrain) !== terrainInput.checked) {
      window.dispatchEvent(new CustomEvent('spinatlas:building-preview-terrain', { detail: terrainInput.checked }));
    }
    panel.querySelector('#building-preview-terrain-status').textContent = terrainInput.checked
      ? (!terrain ? '지형 켜는 중' : Number(terrain.exaggeration) === 0 ? '지형 보호: 자동 평면' : '지형 켜짐')
      : (terrain ? '지형 끄는 중' : '지형 꺼짐');
  }
  const now = performance.now();
  frameTimes = frameTimes.filter(time => time >= now - 2000);
  fpsOutput.textContent = frameTimes.length > 1 ? `${((frameTimes.length - 1) * 1000 / (frameTimes.at(-1) - frameTimes[0])).toFixed(1)} FPS` : 'FPS 대기';
}, 500);
window.addEventListener('pagehide', () => { clearInterval(timer); }, { once: true });
