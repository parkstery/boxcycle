/** Isolated 5218 preview only. Ordinary builds ignore every event. */
export const CAMERA_POSE_EVENT = "spinatlas:camera-pose-preview";
export type CameraPosePreview = { enabled: boolean; heightM: number; pitchDeg: number };
let config: CameraPosePreview = { enabled: false, heightM: 3, pitchDeg: 75 };
let lastAt = -Infinity;
const enabled = () => import.meta.env.VITE_RIDE_3D_PREVIEW === "1";
export function getCameraPosePreview(): CameraPosePreview | null {
  return enabled() && config.enabled ? { ...config } : null;
}
export function publishCameraPosePreview(actual: Record<string, unknown>, at: number, force = false): void {
  if (!enabled() || typeof window === "undefined" || (!force && at - lastAt < 200)) return;
  lastAt = at;
  (window as Window & { __rideCameraPosePreview?: unknown }).__rideCameraPosePreview = {
    requested: { ...config }, active: false, ...actual, atMs: at,
  };
}
if (enabled() && typeof window !== "undefined") {
  window.addEventListener(CAMERA_POSE_EVENT, event => {
    const next = (event as CustomEvent<CameraPosePreview>).detail;
    if (!next || typeof next.enabled !== "boolean" || !Number.isFinite(next.heightM) || !Number.isFinite(next.pitchDeg)) return;
    config = { enabled: next.enabled, heightM: Math.min(200, Math.max(3, next.heightM)),
      pitchDeg: Math.min(85, Math.max(0, next.pitchDeg)) };
    lastAt = -Infinity;
    publishCameraPosePreview({ status: next.enabled ? "카메라2·지형 ON 적용 대기" : "기본 추적" }, 0, true);
  });
  publishCameraPosePreview({ status: "기본 추적" }, 0, true);
}
