/** Independent rendering controls, available only in the isolated manual preview. */
export const RIDE_3D_PREVIEW_EVENT = "spinatlas:ride-3d-preview";
let selection = 3;

export function getRide3DPreviewSnapshot(): number {
  return import.meta.env.VITE_RIDE_3D_PREVIEW === "1" ? selection : -1;
}

export function getRide3DPreview(): { terrain: boolean; buildings: boolean } | null {
  const value = getRide3DPreviewSnapshot();
  return value < 0 ? null : { terrain: Boolean(value & 1), buildings: Boolean(value & 2) };
}

export function subscribeRide3DPreview(changed: () => void): () => void {
  if (getRide3DPreviewSnapshot() < 0 || typeof window === "undefined") return () => {};
  const listener = (event: Event) => {
    const detail = (event as CustomEvent<unknown>).detail;
    if (typeof detail !== "number" || !Number.isInteger(detail) || detail < 0 || detail > 3) return;
    if (selection === detail) return;
    selection = detail;
    changed();
  };
  window.addEventListener(RIDE_3D_PREVIEW_EVENT, listener);
  return () => window.removeEventListener(RIDE_3D_PREVIEW_EVENT, listener);
}
