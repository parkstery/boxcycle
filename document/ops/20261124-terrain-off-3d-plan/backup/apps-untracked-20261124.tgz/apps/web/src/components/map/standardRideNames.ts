import type { Map as MapboxMap, FilterSpecification } from "mapbox-gl";

/** Standard suppresses road names at steep pitch. Supplement its names for close ride views. */
export function addStandardRideNames(map: MapboxMap): void {
  const source = "boxcycle-standard-ride-names";
  if (!map.getSource(source)) map.addSource(source, { type: "vector", url: "mapbox://mapbox.mapbox-streets-v8" });
  const highPitch: FilterSpecification = ["all", ["has", "name"], [">", ["pitch"], 55]];
  if (!map.getLayer("boxcycle-standard-road-names")) map.addLayer({
    id: "boxcycle-standard-road-names", type: "symbol", source, "source-layer": "road", slot: "top", minzoom: 15,
    filter: highPitch,
    layout: { "symbol-placement": "line", "text-field": ["coalesce", ["get", "name_en"], ["get", "name"]],
      "text-font": ["DIN Pro Medium", "Arial Unicode MS Regular"], "text-size": 15,
      "text-pitch-alignment": "viewport", "text-rotation-alignment": "map", "text-padding": 3 },
    paint: { "text-color": "#273442", "text-halo-color": "#ffffff", "text-halo-width": 2 },
  });
  if (!map.getLayer("boxcycle-standard-place-names")) map.addLayer({
    id: "boxcycle-standard-place-names", type: "symbol", source, "source-layer": "poi_label", slot: "top", minzoom: 15,
    filter: highPitch,
    layout: { "text-field": ["coalesce", ["get", "name_en"], ["get", "name"]],
      "text-font": ["DIN Pro Medium", "Arial Unicode MS Regular"], "text-size": 14,
      "text-pitch-alignment": "viewport", "text-offset": [0, -0.8], "text-padding": 4 },
    paint: { "text-color": "#273442", "text-halo-color": "#ffffff", "text-halo-width": 2 },
  });
}
