import type { Map as MapboxMap } from "mapbox-gl";

/** Preview-only: continuous translation with a small angular/zoom deadband. */
export const CAMERA_TOLERANCE_EVENT = "spinatlas:camera-tolerance";
type Jump = { center: [number, number]; bearing: number; pitch: number; zoom: number;
  riderLngLat: [number, number]; t: number; terrainCameraSlot?: number | null; terrainScreenAnchor?: number };
type State = { at: number; bearing: number; pitch: number; zoom: number; aimPitch?: number };
let mode: "baseline" | "tolerant" = "baseline";
let states = new WeakMap<object, State>();
let counters = { frames: 0, limitedFrames: 0, bearingLimited: 0, pitchLimited: 0, zoomLimited: 0,
  terrainAimLimited: 0, safetyAimExact: 0 };
let lastPublishAt = -Infinity;
let lastActive = false;

export function deadbandValue(previous: number, target: number, tolerance: number): number {
  const error = target - previous;
  return Math.abs(error) <= tolerance ? previous : target - Math.sign(error) * tolerance;
}
export function deadbandBearing(previous: number, target: number, tolerance: number): number {
  const error = ((target - previous + 540) % 360) - 180;
  return previous + (Math.abs(error) <= tolerance ? 0 : error - Math.sign(error) * tolerance);
}
const enabled = () => import.meta.env.VITE_RIDE_3D_PREVIEW === "1";
function publish(extra: Record<string, unknown> = {}): void {
  if (!enabled() || typeof window === "undefined") return;
  (window as Window & { __rideCameraTolerancePreview?: unknown }).__rideCameraTolerancePreview = {
    mode, active: lastActive, ...counters, bearingToleranceDeg: 1.5, nominalPitchToleranceDeg: 0.8,
    zoomTolerance: 0.025, aimScreenFraction: 0.04, ...extra,
  };
}
if (enabled() && typeof window !== "undefined" && typeof window.addEventListener === "function") {
  window.addEventListener(CAMERA_TOLERANCE_EVENT, event => {
    const next = (event as CustomEvent<unknown>).detail;
    if (next !== "baseline" && next !== "tolerant") return;
    mode = next; states = new WeakMap(); lastActive = false; lastPublishAt = -Infinity;
    counters = { frames: 0, limitedFrames: 0, bearingLimited: 0, pitchLimited: 0, zoomLimited: 0,
      terrainAimLimited: 0, safetyAimExact: 0 };
    publish();
  });
  publish();
}

export function filterPreviewFollowJump<T extends Jump>(map: MapboxMap, jump: T): T {
  if (!enabled()) return jump;
  counters.frames++;
  lastActive = mode === "tolerant" && jump.terrainCameraSlot === 2
    && Boolean(map.getTerrain() && Number(map.getTerrain()?.exaggeration) > 0);
  if (!lastActive) { states.delete(map); return jump; }
  const previous = states.get(map);
  const bearingError = previous ? Math.abs(((jump.bearing - previous.bearing + 540) % 360) - 180) : Infinity;
  const reset = !previous || jump.t < previous.at || jump.t - previous.at > 1500
    || bearingError > 20 || Math.abs(jump.pitch - previous.pitch) > 6 || Math.abs(jump.zoom - previous.zoom) > 0.15;
  if (reset) {
    states.set(map, { at: jump.t, bearing: jump.bearing, pitch: jump.pitch, zoom: jump.zoom });
    return jump;
  }
  const bearing = deadbandBearing(previous.bearing, jump.bearing, 1.5);
  const pitch = deadbandValue(previous.pitch, jump.pitch, 0.8);
  const zoom = deadbandValue(previous.zoom, jump.zoom, 0.025);
  if (bearing !== jump.bearing) counters.bearingLimited++;
  if (pitch !== jump.pitch) counters.pitchLimited++;
  if (zoom !== jump.zoom) counters.zoomLimited++;
  if (bearing !== jump.bearing || pitch !== jump.pitch || zoom !== jump.zoom) counters.limitedFrames++;
  states.set(map, { ...previous, at: jump.t, bearing, pitch, zoom });
  return { ...jump, bearing, pitch, zoom };
}

/** Only orientation is relaxed. Camera height and every terrain safety query stay exact. */
export function filterPreviewTerrainAim(map: MapboxMap, desiredPitch: number, slot: number | null | undefined,
  fovDeg: number, needsImmediateRise: boolean): number {
  if (!enabled() || mode !== "tolerant" || slot !== 2) return desiredPitch;
  const state = states.get(map);
  if (!state) return desiredPitch;
  const tolerance = Math.atan(0.08 * Math.tan(fovDeg * Math.PI / 360)) * 180 / Math.PI;
  const pitch = needsImmediateRise || state.aimPitch === undefined ? desiredPitch
    : deadbandValue(state.aimPitch, desiredPitch, tolerance);
  if (needsImmediateRise) counters.safetyAimExact++;
  if (pitch !== desiredPitch) counters.terrainAimLimited++;
  state.aimPitch = pitch;
  return pitch;
}

export function publishPreviewFollow(map: MapboxMap, jump: Jump): void {
  if (!enabled() || jump.t - lastPublishAt < 200) return;
  lastPublishAt = jump.t;
  let riderScreen: unknown = null;
  try {
    const point = map.project(jump.riderLngLat), canvas = map.getCanvas();
    riderScreen = { x: point.x / canvas.clientWidth, y: point.y / canvas.clientHeight,
      anchorY: jump.terrainScreenAnchor ?? 0.6 };
  } catch { /* diagnostics must not alter follow */ }
  publish({ slot: jump.terrainCameraSlot ?? null, riderScreen, atMs: jump.t,
    appliedBearing: map.getBearing(), appliedPitch: map.getPitch(), appliedZoom: map.getZoom() });
}
